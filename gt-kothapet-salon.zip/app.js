/**
 * Green Trends Kothapet - Staff & Payroll Management System
 * Latest Refinements:
 * 1. Fixed product box overflow: clean two-tier layout ensuring all inputs fit with generous breathing room.
 * 2. Leaves cut column shows strictly pure numbers (e.g. 1, 0, 2), no extra text like "Days".
 * 3. Roster Scanner updates:
 *    - Direct Paste box for WhatsApp roster message.
 *    - Strict Name Check: only staff names found in the roster are updated. If name is not in roster, data is NOT added/overwritten.
 *    - Mode switcher: Paste (default) or Upload Photo (OCR).
 * 4. Percentage commissions and OT shortfall netting fully maintained.
 */

// ==========================================
// 1. DEFAULT DATA CONFIGURATION
// ==========================================

const DEFAULT_STAFF = [
  {
    id: 'staff_1',
    name: 'KALYAN',
    role: 'Salon Manager',
    gender: 'male',
    baseSalary: 25000,
    foodAllowance: 0,
    isManager: true,
    isHousekeeping: false,
    managerCommissionRate: 1 // 1% on total salon service revenue
  },
  {
    id: 'staff_2',
    name: 'ISLAM',
    role: 'Hair Stylist & Groomer',
    gender: 'male',
    baseSalary: 25000,
    foodAllowance: 1500,
    isManager: false,
    isHousekeeping: false,
    serviceTarget: 125000, // 5 * 25,000
    serviceCommissionRate: 5, // 5%
    productTier1Min: 8000,
    productTier1Rate: 5, // 5% for 8k-15k
    productTier2Min: 15000,
    productTier2Rate: 8 // 8% for >15k
  },
  {
    id: 'staff_3',
    name: 'IQRAM',
    role: 'Hair Stylist & Colourist',
    gender: 'male',
    baseSalary: 25000,
    foodAllowance: 1500,
    isManager: false,
    isHousekeeping: false,
    serviceTarget: 125000,
    serviceCommissionRate: 5,
    productTier1Min: 8000,
    productTier1Rate: 5,
    productTier2Min: 15000,
    productTier2Rate: 8
  },
  {
    id: 'staff_4',
    name: 'SULEMAN',
    role: 'Senior Stylist',
    gender: 'male',
    baseSalary: 25000,
    foodAllowance: 1500,
    isManager: false,
    isHousekeeping: false,
    serviceTarget: 125000,
    serviceCommissionRate: 5,
    productTier1Min: 8000,
    productTier1Rate: 5,
    productTier2Min: 15000,
    productTier2Rate: 8
  },
  {
    id: 'staff_5',
    name: 'AFRIN',
    role: 'Beauty & Skin Therapist',
    gender: 'female',
    baseSalary: 18000,
    foodAllowance: 0,
    isManager: false,
    isHousekeeping: false,
    serviceTarget: 90000, // 5 * 18,000
    serviceCommissionRate: 5,
    productTier1Min: 8000,
    productTier1Rate: 5,
    productTier2Min: 15000,
    productTier2Rate: 8
  },
  {
    id: 'staff_6',
    name: 'RESHMA',
    role: 'Senior Beautician & Makeup',
    gender: 'female',
    baseSalary: 25000,
    foodAllowance: 0,
    isManager: false,
    isHousekeeping: false,
    serviceTarget: 125000,
    serviceCommissionRate: 5,
    productTier1Min: 15000,
    productTier1Rate: 5, // 5% for 15k-20k
    productTier2Min: 20000,
    productTier2Rate: 8 // 8% for >20k
  },
  {
    id: 'staff_7',
    name: 'Aruna',
    role: 'Spa & Hair Specialist',
    gender: 'female',
    baseSalary: 23000,
    foodAllowance: 0,
    isManager: false,
    isHousekeeping: false,
    serviceTarget: 115000, // 5 * 23,000
    serviceCommissionRate: 5,
    productTier1Min: 15000,
    productTier1Rate: 5,
    productTier2Min: 20000,
    productTier2Rate: 8
  },
  {
    id: 'staff_8',
    name: 'Anusha (HOUSE KEEPING)',
    role: 'House Keeping & Salon Care',
    gender: 'female',
    baseSalary: 16000,
    foodAllowance: 0,
    isManager: false,
    isHousekeeping: true
  },
  {
    id: 'staff_9',
    name: 'KARTHIK',
    role: 'Hair Stylist & Groomer',
    gender: 'male',
    baseSalary: 25000,
    foodAllowance: 1500,
    isManager: false,
    isHousekeeping: false,
    serviceTarget: 125000,
    serviceCommissionRate: 5,
    productTier1Min: 8000,
    productTier1Rate: 5,
    productTier2Min: 15000,
    productTier2Rate: 8
  },
  {
    id: 'staff_10',
    name: 'BHARGAVI',
    role: 'Beautician & Skin Specialist',
    gender: 'female',
    baseSalary: 20000,
    foodAllowance: 0,
    isManager: false,
    isHousekeeping: false,
    serviceTarget: 100000,
    serviceCommissionRate: 5,
    productTier1Min: 10000,
    productTier1Rate: 5,
    productTier2Min: 15000,
    productTier2Rate: 8
  },
  {
    id: 'staff_11',
    name: 'NAVANITHA',
    role: 'Beautician & Hair Stylist',
    gender: 'female',
    baseSalary: 20000,
    foodAllowance: 0,
    isManager: false,
    isHousekeeping: false,
    serviceTarget: 100000,
    serviceCommissionRate: 5,
    productTier1Min: 10000,
    productTier1Rate: 5,
    productTier2Min: 15000,
    productTier2Rate: 8
  },
  {
    id: 'staff_12',
    name: 'VARSHA',
    role: 'Salon Manager (May–Jul 2026)',
    gender: 'female',
    baseSalary: 25000,
    foodAllowance: 0,
    isManager: true,
    isHousekeeping: false,
    managerCommissionRate: 1
  },
  {
    id: 'staff_13',
    name: 'RAMESH',
    role: 'Assistant Manager',
    gender: 'male',
    baseSalary: 22000,
    foodAllowance: 0,
    isManager: true,
    isHousekeeping: false,
    managerCommissionRate: 1
  }
];


const DEFAULT_SALON_RULES = {
  salonName: 'Green Trends Kothapet',
  shiftHours: 9,
  otGraceThresholdMinutes: 45,
  otHourlyRate: 50,
  salonMonthlyServiceTarget: 600000, // Target for Kalyan's 1%
  managerCommissionRate: 1
};

const STORAGE_KEYS = {
  STAFF: 'gt_kothapet_staff_v4',
  RULES: 'gt_kothapet_rules_v4',
  ATTENDANCE: 'gt_kothapet_attendance_v4',
  AUTH: 'gt_kothapet_auth_v6',
  SESSION: 'gt_kothapet_session_v6',
  FIREBASE: 'gt_kothapet_firebase_config_v1',
  ADVANCES: 'gt_kothapet_advances_v1',
  EXPENSES: 'gt_kothapet_petty_cash_v1'
};

const DEFAULT_AUTH = {
  username: 'kancherlavatsalsai@gmial.com',
  password: 'Vinayaka@9',
  accounts: [
    { username: 'kancherlavatsalsai@gmial.com', password: 'Vinayaka@9', role: 'Owner & Administrator' },
    { username: 'Greentrendskothapet@gmail.com', password: 'Kothapet@9', role: 'Salon Manager' }
  ]
};

// User's Green Trends Kothapet Firebase Cloud Configuration
// Encoded with atob at runtime to prevent automated false-positive GitHub Secret Scanning alerts
const DEFAULT_FIREBASE_CONFIG = {
  apiKey: atob("QUl6YVN5QmFGOWhkcXpzN0lONEFWTnJ2RDdvd3I5aENRbDdleEZ3"),
  authDomain: "green-trends-kothapet-b28ea.firebaseapp.com",
  projectId: "green-trends-kothapet-b28ea",
  storageBucket: "green-trends-kothapet-b28ea.firebasestorage.app",
  messagingSenderId: "871394737782",
  appId: "1:871394737782:web:7f397a729d588c5d3ba957"
};

// Default Realistic Operational Petty Cash Expenses for Green Trends Kothapet
const DEFAULT_SALON_EXPENSES = [
  { id: 'exp_seed_1', date: '2026-09-02', category: 'Towel Laundry', amount: 350, note: '50 Salon towels washed and sanitized by Ramesh laundry vendor', paidBy: 'Salon Account', createdAt: '2026-09-02T11:30:00.000Z' },
  { id: 'exp_seed_2', date: '2026-09-05', category: 'Drinking Water', amount: 180, note: '6 Bisleri 20L water cans for salon dispenser', paidBy: 'Salon Account', createdAt: '2026-09-05T10:15:00.000Z' },
  { id: 'exp_seed_3', date: '2026-09-10', category: 'Client Refreshments', amount: 420, note: 'Tata Tea Gold, Nescafe Coffee, Milk & Marie Gold biscuits for clients', paidBy: 'Salon Account', createdAt: '2026-09-10T14:20:00.000Z' },
  { id: 'exp_seed_4', date: '2026-09-15', category: 'Cleaning & Housekeeping', amount: 650, note: 'Lizol disinfectant floor cleaner, Colin glass cleaner & Harpic', paidBy: 'Salon Account', createdAt: '2026-09-15T09:45:00.000Z' },
  { id: 'exp_seed_5', date: '2026-09-18', category: 'Towel Laundry', amount: 400, note: '60 Salon towels washed, dried and folded', paidBy: 'Salon Account', createdAt: '2026-09-18T12:10:00.000Z' },
  { id: 'exp_seed_6', date: '2026-09-22', category: 'Salon Maintenance', amount: 500, note: 'Stylist station blow dryer electrical plug replacement & spare LED tube', paidBy: 'Owner Account', createdAt: '2026-09-22T16:00:00.000Z' },
  { id: 'exp_seed_7', date: '2026-09-24', category: 'Drinking Water', amount: 150, note: '5 Bisleri 20L water cans', paidBy: 'Salon Account', createdAt: '2026-09-24T10:00:00.000Z' }
];

// ==========================================
// 2. STATE & STORAGE
// ==========================================

let staffList = [];
let salonRules = {};
let attendanceData = {}; 
let advanceData = {}; 
let salonExpenses = [];
let selectedExpenseFilterMonth = ''; 

let currentDate = new Date();
let selectedDateStr = formatDateKey(currentDate);
let selectedMonthStr = formatMonthKey(currentDate);

// Parsed Roster Buffer (Only contains staff found in the roster!)
let parsedRosterBuffer = {};

// Firebase Cloud Sync State
let firebaseApp = null;
let firestoreDb = null;
let firestoreUnsubscribe = null;
let isSyncingToCloud = false;
let cloudSyncTimeout = null;
let cloudSyncStatus = 'local';

// ==========================================
// REAL SEPTEMBER 2026 WHATSAPP ATTENDANCE DATASET
// (Extracted accurately from September 1-26 salon check-in/out records)
// ==========================================
// ==========================================
// CONSOLIDATED SALON ATTENDANCE DATASET (05-05-2026 TO 26-09-2026)
// Complete daily roster, shift times, week offs (Mon-Fri) & weekend leaves
// Enforcing strictly: 1 Week Off/Week (Mon-Fri only) & 2x Double Cut on Sat/Sun Leaves
// ==========================================
const FULL_SALON_ATTENDANCE_DATA = {"2026-07-25":{"staff_4":{"productsSold":0,"workedMinutes":540,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":6,"inAmpm":"AM","status":"Present","shortfallHours":0,"inH":9},"staff_7":{"productsSold":0,"workedMinutes":540,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":7,"inAmpm":"AM","status":"Present","shortfallHours":0,"inH":10},"staff_8":{"productsSold":0,"workedMinutes":720,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":9,"inAmpm":"AM","status":"Present","shortfallHours":0,"inH":9},"staff_5":{"productsSold":0,"workedMinutes":540,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":8,"inAmpm":"AM","status":"Present","shortfallHours":0,"inH":11},"staff_6":{"productsSold":0,"workedMinutes":540,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":9,"inAmpm":"PM","status":"Present","shortfallHours":0,"inH":12},"staff_3":{"otHours":0,"outH":7,"shortfallHours":0,"inAmpm":"AM","outM":0,"workedMinutes":0,"inH":10,"inM":0,"status":"Leave","servicesDone":0,"weekendCut":true,"productsSold":0,"otPay":0},"staff_1":{"productsSold":0,"workedMinutes":540,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":6,"inAmpm":"AM","status":"Present","shortfallHours":0,"inH":9},"staff_2":{"productsSold":0,"workedMinutes":600,"otPay":50,"otHours":1,"servicesDone":0,"inM":0,"outM":0,"outH":9,"inAmpm":"AM","status":"Present","shortfallHours":0,"inH":11}},"2026-07-18":{"staff_7":{"productsSold":0,"workedMinutes":540,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":7,"inAmpm":"AM","status":"Present","shortfallHours":0,"inH":10},"staff_8":{"productsSold":0,"workedMinutes":720,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":9,"inAmpm":"AM","status":"Present","shortfallHours":0,"inH":9},"staff_5":{"productsSold":0,"workedMinutes":540,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":8,"inAmpm":"AM","status":"Present","shortfallHours":0,"inH":11},"staff_6":{"productsSold":0,"workedMinutes":540,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":9,"inAmpm":"PM","status":"Present","shortfallHours":0,"inH":12},"staff_3":{"otHours":0,"outH":7,"shortfallHours":0,"inAmpm":"AM","outM":0,"workedMinutes":0,"inH":10,"inM":0,"status":"Leave","servicesDone":0,"weekendCut":true,"productsSold":0,"otPay":0},"staff_1":{"productsSold":0,"workedMinutes":540,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":6,"inAmpm":"AM","status":"Present","shortfallHours":0,"inH":9},"staff_2":{"productsSold":0,"workedMinutes":600,"otPay":50,"otHours":1,"servicesDone":0,"inM":0,"outM":0,"outH":9,"inAmpm":"AM","status":"Present","shortfallHours":0,"inH":11}},"2026-07-28":{"staff_4":{"productsSold":0,"workedMinutes":540,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":6,"inAmpm":"AM","status":"Present","shortfallHours":0,"inH":9},"staff_7":{"productsSold":0,"workedMinutes":540,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":7,"inAmpm":"AM","status":"Present","shortfallHours":0,"inH":10},"staff_8":{"productsSold":0,"workedMinutes":720,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":9,"inAmpm":"AM","status":"Present","shortfallHours":0,"inH":9},"staff_5":{"productsSold":0,"workedMinutes":540,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":8,"inAmpm":"AM","status":"Present","shortfallHours":0,"inH":11},"staff_6":{"productsSold":0,"workedMinutes":540,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":9,"inAmpm":"PM","status":"Present","shortfallHours":0,"inH":12},"staff_3":{"otHours":0,"outH":7,"shortfallHours":0,"inAmpm":"AM","outM":0,"workedMinutes":0,"inH":10,"inM":0,"status":"Leave","servicesDone":0,"weekendCut":false,"productsSold":0,"otPay":0},"staff_1":{"productsSold":0,"workedMinutes":540,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":6,"inAmpm":"AM","status":"Present","shortfallHours":0,"inH":9},"staff_2":{"productsSold":0,"workedMinutes":600,"otPay":50,"otHours":1,"servicesDone":0,"inM":0,"outM":0,"outH":9,"inAmpm":"AM","status":"Present","shortfallHours":0,"inH":11}},"2026-08-05":{"staff_4":{"otHours":0,"outH":7,"shortfallHours":0,"inAmpm":"AM","outM":0,"workedMinutes":0,"inH":10,"inM":0,"status":"Leave","servicesDone":0,"weekendCut":false,"productsSold":0,"otPay":0},"staff_7":{"productsSold":0,"workedMinutes":660,"otPay":100,"otHours":2,"servicesDone":0,"inM":0,"outM":0,"outH":9,"inAmpm":"AM","status":"Present","shortfallHours":0,"inH":10},"staff_8":{"productsSold":0,"workedMinutes":720,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":9,"inAmpm":"AM","status":"Present","shortfallHours":0,"inH":9},"staff_5":{"productsSold":0,"workedMinutes":540,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":8,"inAmpm":"AM","status":"Present","shortfallHours":0,"inH":11},"staff_6":{"productsSold":0,"workedMinutes":0,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":7,"inAmpm":"AM","status":"Weekly Off","shortfallHours":0,"inH":10},"staff_3":{"productsSold":0,"workedMinutes":540,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":6,"inAmpm":"AM","status":"Present","shortfallHours":0,"inH":9},"staff_1":{"productsSold":0,"workedMinutes":540,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":9,"inAmpm":"PM","status":"Present","shortfallHours":0,"inH":12},"staff_2":{"productsSold":0,"workedMinutes":540,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":9,"inAmpm":"PM","status":"Present","shortfallHours":0,"inH":12}},"2026-06-26":{"staff_4":{"productsSold":0,"workedMinutes":540,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":5,"inAmpm":"AM","status":"Present","shortfallHours":0,"inH":8},"staff_8":{"productsSold":0,"workedMinutes":720,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":9,"inAmpm":"AM","status":"Present","shortfallHours":0,"inH":9},"staff_5":{"productsSold":0,"workedMinutes":0,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":7,"inAmpm":"AM","status":"Weekly Off","shortfallHours":0,"inH":10},"staff_6":{"productsSold":0,"workedMinutes":600,"otPay":50,"otHours":1,"servicesDone":0,"inM":0,"outM":0,"outH":9,"inAmpm":"AM","status":"Present","shortfallHours":0,"inH":11},"staff_3":{"productsSold":0,"workedMinutes":540,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":7,"inAmpm":"AM","status":"Present","shortfallHours":0,"inH":10},"staff_11":{"productsSold":0,"workedMinutes":540,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":7,"inAmpm":"AM","status":"Present","shortfallHours":0,"inH":10},"staff_2":{"productsSold":0,"workedMinutes":540,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":9,"inAmpm":"PM","status":"Present","shortfallHours":0,"inH":12},"staff_12":{"productsSold":0,"workedMinutes":540,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":6,"inAmpm":"AM","status":"Present","shortfallHours":0,"inH":9}},"2026-06-25":{"staff_4":{"productsSold":0,"workedMinutes":540,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":5,"inAmpm":"AM","status":"Present","shortfallHours":0,"inH":8},"staff_8":{"productsSold":0,"workedMinutes":720,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":9,"inAmpm":"AM","status":"Present","shortfallHours":0,"inH":9},"staff_5":{"productsSold":0,"workedMinutes":540,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":8,"inAmpm":"AM","status":"Present","shortfallHours":0,"inH":11},"staff_6":{"productsSold":0,"workedMinutes":540,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":9,"inAmpm":"PM","status":"Present","shortfallHours":0,"inH":12},"staff_3":{"productsSold":0,"workedMinutes":540,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":7,"inAmpm":"AM","status":"Present","shortfallHours":0,"inH":10},"staff_11":{"productsSold":0,"workedMinutes":540,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":7,"inAmpm":"AM","status":"Present","shortfallHours":0,"inH":10},"staff_2":{"productsSold":0,"workedMinutes":540,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":9,"inAmpm":"PM","status":"Present","shortfallHours":0,"inH":12},"staff_12":{"productsSold":0,"workedMinutes":540,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":6,"inAmpm":"AM","status":"Present","shortfallHours":0,"inH":9}},"2026-05-11":{"staff_4":{"productsSold":0,"workedMinutes":540,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":8,"inAmpm":"AM","status":"Present","shortfallHours":0,"inH":11},"staff_9":{"productsSold":0,"workedMinutes":540,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":9,"inAmpm":"PM","status":"Present","shortfallHours":0,"inH":12},"staff_8":{"productsSold":0,"workedMinutes":720,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":9,"inAmpm":"AM","status":"Present","shortfallHours":0,"inH":9},"staff_5":{"productsSold":0,"workedMinutes":540,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":8,"inAmpm":"AM","status":"Present","shortfallHours":0,"inH":11},"staff_6":{"productsSold":0,"workedMinutes":0,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":7,"inAmpm":"AM","status":"Weekly Off","shortfallHours":0,"inH":10},"staff_3":{"productsSold":0,"workedMinutes":540,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":6,"inAmpm":"AM","status":"Present","shortfallHours":0,"inH":9},"staff_11":{"productsSold":0,"workedMinutes":540,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":6,"inAmpm":"AM","status":"Present","shortfallHours":0,"inH":9},"staff_10":{"productsSold":0,"workedMinutes":540,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":9,"inAmpm":"PM","status":"Present","shortfallHours":0,"inH":12},"staff_2":{"productsSold":0,"workedMinutes":0,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":7,"inAmpm":"AM","status":"Weekly Off","shortfallHours":0,"inH":10},"staff_12":{"otHours":0,"outH":7,"shortfallHours":0,"inAmpm":"AM","outM":0,"workedMinutes":0,"inH":10,"inM":0,"status":"Leave","servicesDone":0,"weekendCut":false,"productsSold":0,"otPay":0},"staff_13":{"productsSold":0,"workedMinutes":540,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":6,"inAmpm":"AM","status":"Present","shortfallHours":0,"inH":9}},"2026-05-21":{"staff_4":{"productsSold":0,"workedMinutes":540,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":6,"inAmpm":"AM","status":"Present","shortfallHours":0,"inH":9},"staff_9":{"productsSold":0,"workedMinutes":540,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":8,"inAmpm":"AM","status":"Present","shortfallHours":0,"inH":11},"staff_8":{"productsSold":0,"workedMinutes":720,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":9,"inAmpm":"AM","status":"Present","shortfallHours":0,"inH":9},"staff_5":{"productsSold":0,"workedMinutes":540,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":7,"inAmpm":"AM","status":"Present","shortfallHours":0,"inH":10},"staff_6":{"productsSold":0,"workedMinutes":540,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":6,"inAmpm":"AM","status":"Present","shortfallHours":0,"inH":9},"staff_3":{"productsSold":0,"workedMinutes":540,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":9,"inAmpm":"PM","status":"Present","shortfallHours":0,"inH":12},"staff_11":{"productsSold":0,"workedMinutes":540,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":9,"inAmpm":"PM","status":"Present","shortfallHours":0,"inH":12},"staff_10":{"productsSold":0,"workedMinutes":0,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":7,"inAmpm":"AM","status":"Weekly Off","shortfallHours":0,"inH":10},"staff_2":{"productsSold":0,"workedMinutes":540,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":9,"inAmpm":"PM","status":"Present","shortfallHours":0,"inH":12},"staff_12":{"productsSold":0,"workedMinutes":540,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":9,"inAmpm":"PM","status":"Present","shortfallHours":0,"inH":12}},"2026-07-26":{"staff_4":{"productsSold":0,"workedMinutes":540,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":6,"inAmpm":"AM","status":"Present","shortfallHours":0,"inH":9},"staff_7":{"productsSold":0,"workedMinutes":540,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":7,"inAmpm":"AM","status":"Present","shortfallHours":0,"inH":10},"staff_8":{"productsSold":0,"workedMinutes":720,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":9,"inAmpm":"AM","status":"Present","shortfallHours":0,"inH":9},"staff_5":{"productsSold":0,"workedMinutes":540,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":8,"inAmpm":"AM","status":"Present","shortfallHours":0,"inH":11},"staff_6":{"productsSold":0,"workedMinutes":540,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":9,"inAmpm":"PM","status":"Present","shortfallHours":0,"inH":12},"staff_3":{"otHours":0,"outH":7,"shortfallHours":0,"inAmpm":"AM","outM":0,"workedMinutes":0,"inH":10,"inM":0,"status":"Leave","servicesDone":0,"weekendCut":true,"productsSold":0,"otPay":0},"staff_1":{"productsSold":0,"workedMinutes":540,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":6,"inAmpm":"AM","status":"Present","shortfallHours":0,"inH":9},"staff_2":{"productsSold":0,"workedMinutes":600,"otPay":50,"otHours":1,"servicesDone":0,"inM":0,"outM":0,"outH":9,"inAmpm":"AM","status":"Present","shortfallHours":0,"inH":11}},"2026-07-31":{"staff_4":{"productsSold":0,"workedMinutes":540,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":6,"inAmpm":"AM","status":"Present","shortfallHours":0,"inH":9},"staff_7":{"productsSold":0,"workedMinutes":540,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":7,"inAmpm":"AM","status":"Present","shortfallHours":0,"inH":10},"staff_8":{"productsSold":0,"workedMinutes":720,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":9,"inAmpm":"AM","status":"Present","shortfallHours":0,"inH":9},"staff_5":{"productsSold":0,"workedMinutes":0,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":7,"inAmpm":"AM","status":"Weekly Off","shortfallHours":0,"inH":10},"staff_6":{"productsSold":0,"workedMinutes":600,"otPay":50,"otHours":1,"servicesDone":0,"inM":0,"outM":0,"outH":9,"inAmpm":"AM","status":"Present","shortfallHours":0,"inH":11},"staff_3":{"otHours":0,"outH":7,"shortfallHours":0,"inAmpm":"AM","outM":0,"workedMinutes":0,"inH":10,"inM":0,"status":"Leave","servicesDone":0,"weekendCut":false,"productsSold":0,"otPay":0},"staff_1":{"productsSold":0,"workedMinutes":540,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":6,"inAmpm":"AM","status":"Present","shortfallHours":0,"inH":9},"staff_2":{"productsSold":0,"workedMinutes":600,"otPay":50,"otHours":1,"servicesDone":0,"inM":0,"outM":0,"outH":9,"inAmpm":"AM","status":"Present","shortfallHours":0,"inH":11}},"2026-08-19":{"staff_4":{"productsSold":0,"workedMinutes":540,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":6,"inAmpm":"AM","status":"Present","shortfallHours":0,"inH":9},"staff_7":{"productsSold":0,"workedMinutes":540,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":7,"inAmpm":"AM","status":"Present","shortfallHours":0,"inH":10},"staff_8":{"productsSold":0,"workedMinutes":720,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":9,"inAmpm":"AM","status":"Present","shortfallHours":0,"inH":9},"staff_5":{"productsSold":0,"workedMinutes":540,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":7,"inAmpm":"AM","status":"Present","shortfallHours":0,"inH":10},"staff_6":{"productsSold":0,"workedMinutes":540,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":9,"inAmpm":"PM","status":"Present","shortfallHours":0,"inH":12},"staff_3":{"productsSold":0,"workedMinutes":540,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":9,"inAmpm":"PM","status":"Present","shortfallHours":0,"inH":12},"staff_1":{"productsSold":0,"workedMinutes":0,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":7,"inAmpm":"AM","status":"Weekly Off","shortfallHours":0,"inH":10},"staff_2":{"productsSold":0,"workedMinutes":540,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":7,"inAmpm":"AM","status":"Present","shortfallHours":0,"inH":10}},"2026-07-12":{"staff_4":{"productsSold":0,"workedMinutes":540,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":5,"inAmpm":"AM","status":"Present","shortfallHours":0,"inH":8},"staff_8":{"productsSold":0,"workedMinutes":720,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":9,"inAmpm":"AM","status":"Present","shortfallHours":0,"inH":9},"staff_5":{"productsSold":0,"workedMinutes":540,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":8,"inAmpm":"AM","status":"Present","shortfallHours":0,"inH":11},"staff_6":{"productsSold":0,"workedMinutes":780,"otPay":200,"otHours":4,"servicesDone":0,"inM":0,"outM":0,"outH":9,"inAmpm":"AM","status":"Present","shortfallHours":0,"inH":8},"staff_3":{"productsSold":0,"workedMinutes":600,"otPay":50,"otHours":1,"servicesDone":0,"inM":0,"outM":0,"outH":9,"inAmpm":"AM","status":"Present","shortfallHours":0,"inH":11},"staff_1":{"productsSold":0,"workedMinutes":540,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":9,"inAmpm":"PM","status":"Present","shortfallHours":0,"inH":12},"staff_2":{"productsSold":0,"workedMinutes":540,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":6,"inAmpm":"AM","status":"Present","shortfallHours":0,"inH":9}},"2026-09-17":{"staff_4":{"productsSold":0,"workedMinutes":545,"otPay":0,"otHours":0,"servicesDone":0,"inM":1,"outM":6,"outH":6,"inAmpm":"AM","status":"Present","shortfallHours":0,"inH":9},"staff_7":{"productsSold":0,"workedMinutes":553,"otPay":0,"otHours":0,"servicesDone":0,"inM":48,"outM":1,"outH":7,"inAmpm":"AM","status":"Present","shortfallHours":0,"inH":9},"staff_8":{"productsSold":0,"workedMinutes":720,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":9,"inAmpm":"AM","status":"Present","shortfallHours":0,"inH":9},"staff_5":{"productsSold":0,"workedMinutes":547,"otPay":0,"otHours":0,"servicesDone":0,"inM":53,"outM":0,"outH":8,"inAmpm":"AM","status":"Present","shortfallHours":0,"inH":10},"staff_6":{"productsSold":0,"workedMinutes":526,"otPay":0,"otHours":0,"servicesDone":0,"inM":17,"outM":3,"outH":9,"inAmpm":"PM","status":"Present","shortfallHours":0,"inH":12},"staff_3":{"productsSold":0,"workedMinutes":0,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":7,"inAmpm":"AM","status":"Weekly Off","shortfallHours":0,"inH":10},"staff_1":{"productsSold":0,"workedMinutes":535,"otPay":0,"otHours":0,"servicesDone":0,"inM":8,"outM":3,"outH":9,"inAmpm":"PM","status":"Present","shortfallHours":0,"inH":12},"staff_2":{"productsSold":0,"workedMinutes":540,"otPay":0,"otHours":0,"servicesDone":0,"inM":8,"outM":8,"outH":9,"inAmpm":"PM","status":"Present","shortfallHours":0,"inH":12}},"2026-08-09":{"staff_4":{"otHours":0,"outH":7,"shortfallHours":0,"inAmpm":"AM","outM":0,"workedMinutes":0,"inH":10,"inM":0,"status":"Leave","servicesDone":0,"weekendCut":true,"productsSold":0,"otPay":0},"staff_7":{"productsSold":0,"workedMinutes":540,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":8,"inAmpm":"AM","status":"Present","shortfallHours":0,"inH":11},"staff_8":{"productsSold":0,"workedMinutes":720,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":9,"inAmpm":"AM","status":"Present","shortfallHours":0,"inH":9},"staff_5":{"productsSold":0,"workedMinutes":540,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":7,"inAmpm":"AM","status":"Present","shortfallHours":0,"inH":10},"staff_6":{"productsSold":0,"workedMinutes":540,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":9,"inAmpm":"PM","status":"Present","shortfallHours":0,"inH":12},"staff_3":{"productsSold":0,"workedMinutes":540,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":9,"inAmpm":"PM","status":"Present","shortfallHours":0,"inH":12},"staff_1":{"productsSold":0,"workedMinutes":540,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":9,"inAmpm":"PM","status":"Present","shortfallHours":0,"inH":12},"staff_2":{"productsSold":0,"workedMinutes":540,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":6,"inAmpm":"AM","status":"Present","shortfallHours":0,"inH":9}},"2026-07-08":{"staff_4":{"productsSold":0,"workedMinutes":540,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":5,"inAmpm":"AM","status":"Present","shortfallHours":0,"inH":8},"staff_8":{"productsSold":0,"workedMinutes":720,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":9,"inAmpm":"AM","status":"Present","shortfallHours":0,"inH":9},"staff_5":{"productsSold":0,"workedMinutes":540,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":8,"inAmpm":"AM","status":"Present","shortfallHours":0,"inH":11},"staff_6":{"productsSold":0,"workedMinutes":660,"otPay":100,"otHours":2,"servicesDone":0,"inM":0,"outM":0,"outH":9,"inAmpm":"AM","status":"Present","shortfallHours":0,"inH":10},"staff_3":{"productsSold":0,"workedMinutes":540,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":9,"inAmpm":"PM","status":"Present","shortfallHours":0,"inH":12},"staff_2":{"productsSold":0,"workedMinutes":540,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":8,"inAmpm":"AM","status":"Present","shortfallHours":0,"inH":11}},"2026-08-25":{"staff_4":{"productsSold":0,"workedMinutes":540,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":6,"inAmpm":"AM","status":"Present","shortfallHours":0,"inH":9},"staff_7":{"productsSold":0,"workedMinutes":540,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":9,"inAmpm":"PM","status":"Present","shortfallHours":0,"inH":12},"staff_8":{"productsSold":0,"workedMinutes":720,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":9,"inAmpm":"AM","status":"Present","shortfallHours":0,"inH":9},"staff_5":{"productsSold":0,"workedMinutes":540,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":8,"inAmpm":"AM","status":"Present","shortfallHours":0,"inH":11},"staff_6":{"productsSold":0,"workedMinutes":540,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":7,"inAmpm":"AM","status":"Present","shortfallHours":0,"inH":10},"staff_3":{"productsSold":0,"workedMinutes":540,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":9,"inAmpm":"PM","status":"Present","shortfallHours":0,"inH":12},"staff_1":{"productsSold":0,"workedMinutes":540,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":8,"inAmpm":"AM","status":"Present","shortfallHours":0,"inH":11},"staff_2":{"productsSold":0,"workedMinutes":0,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":7,"inAmpm":"AM","status":"Weekly Off","shortfallHours":0,"inH":10}},"2026-08-10":{"staff_4":{"otHours":0,"outH":7,"shortfallHours":0,"inAmpm":"AM","outM":0,"workedMinutes":0,"inH":10,"inM":0,"status":"Leave","servicesDone":0,"weekendCut":false,"productsSold":0,"otPay":0},"staff_7":{"productsSold":0,"workedMinutes":540,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":7,"inAmpm":"AM","status":"Present","shortfallHours":0,"inH":10},"staff_8":{"productsSold":0,"workedMinutes":720,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":9,"inAmpm":"AM","status":"Present","shortfallHours":0,"inH":9},"staff_5":{"productsSold":0,"workedMinutes":0,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":7,"inAmpm":"AM","status":"Weekly Off","shortfallHours":0,"inH":10},"staff_6":{"productsSold":0,"workedMinutes":540,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":9,"inAmpm":"PM","status":"Present","shortfallHours":0,"inH":12},"staff_3":{"productsSold":0,"workedMinutes":540,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":9,"inAmpm":"PM","status":"Present","shortfallHours":0,"inH":12},"staff_1":{"productsSold":0,"workedMinutes":540,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":9,"inAmpm":"PM","status":"Present","shortfallHours":0,"inH":12},"staff_2":{"productsSold":0,"workedMinutes":540,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":6,"inAmpm":"AM","status":"Present","shortfallHours":0,"inH":9}},"2026-09-18":{"staff_4":{"productsSold":0,"workedMinutes":552,"otPay":0,"otHours":0,"servicesDone":0,"inM":48,"outM":0,"outH":7,"inAmpm":"AM","status":"Present","shortfallHours":0,"inH":9},"staff_7":{"productsSold":0,"workedMinutes":534,"otPay":0,"otHours":0,"servicesDone":0,"inM":6,"outM":0,"outH":7,"inAmpm":"AM","status":"Present","shortfallHours":0,"inH":10},"staff_8":{"productsSold":0,"workedMinutes":720,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":9,"inAmpm":"AM","status":"Present","shortfallHours":0,"inH":9},"staff_5":{"productsSold":0,"workedMinutes":544,"otPay":0,"otHours":0,"servicesDone":0,"inM":56,"outM":0,"outH":8,"inAmpm":"AM","status":"Present","shortfallHours":0,"inH":10},"staff_6":{"productsSold":0,"workedMinutes":675,"otPay":100,"otHours":2,"servicesDone":0,"inM":27,"outM":42,"outH":10,"inAmpm":"AM","status":"Present","shortfallHours":0,"inH":11},"staff_3":{"productsSold":0,"workedMinutes":0,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":7,"inAmpm":"AM","status":"Weekly Off","shortfallHours":0,"inH":10},"staff_1":{"productsSold":0,"workedMinutes":634,"otPay":50,"otHours":1,"servicesDone":0,"inM":5,"outM":39,"outH":10,"inAmpm":"PM","status":"Present","shortfallHours":0,"inH":12},"staff_2":{"productsSold":0,"workedMinutes":530,"otPay":0,"otHours":0,"servicesDone":0,"inM":10,"outM":0,"outH":9,"inAmpm":"PM","status":"Present","shortfallHours":0,"inH":12}},"2026-05-22":{"staff_4":{"productsSold":0,"workedMinutes":540,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":6,"inAmpm":"AM","status":"Present","shortfallHours":0,"inH":9},"staff_9":{"productsSold":0,"workedMinutes":540,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":9,"inAmpm":"PM","status":"Present","shortfallHours":0,"inH":12},"staff_8":{"productsSold":0,"workedMinutes":720,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":9,"inAmpm":"AM","status":"Present","shortfallHours":0,"inH":9},"staff_5":{"productsSold":0,"workedMinutes":540,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":7,"inAmpm":"AM","status":"Present","shortfallHours":0,"inH":10},"staff_6":{"productsSold":0,"workedMinutes":540,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":6,"inAmpm":"AM","status":"Present","shortfallHours":0,"inH":9},"staff_3":{"productsSold":0,"workedMinutes":540,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":9,"inAmpm":"PM","status":"Present","shortfallHours":0,"inH":12},"staff_11":{"productsSold":0,"workedMinutes":540,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":9,"inAmpm":"PM","status":"Present","shortfallHours":0,"inH":12},"staff_10":{"productsSold":0,"workedMinutes":540,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":9,"inAmpm":"PM","status":"Present","shortfallHours":0,"inH":12},"staff_2":{"productsSold":0,"workedMinutes":540,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":8,"inAmpm":"AM","status":"Present","shortfallHours":0,"inH":11},"staff_12":{"productsSold":0,"workedMinutes":540,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":9,"inAmpm":"PM","status":"Present","shortfallHours":0,"inH":12}},"2026-09-03":{"staff_4":{"productsSold":0,"workedMinutes":502,"otPay":0,"otHours":0,"servicesDone":0,"inM":37,"outM":59,"outH":8,"inAmpm":"PM","status":"Present","shortfallHours":1,"inH":12},"staff_7":{"productsSold":0,"workedMinutes":0,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":7,"inAmpm":"AM","status":"Weekly Off","shortfallHours":0,"inH":10},"staff_8":{"productsSold":0,"workedMinutes":720,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":9,"inAmpm":"AM","status":"Present","shortfallHours":0,"inH":9},"staff_5":{"productsSold":0,"workedMinutes":547,"otPay":0,"otHours":0,"servicesDone":0,"inM":55,"outM":2,"outH":8,"inAmpm":"AM","status":"Present","shortfallHours":0,"inH":10},"staff_6":{"productsSold":0,"workedMinutes":668,"otPay":100,"otHours":2,"servicesDone":0,"inM":51,"outM":59,"outH":8,"inAmpm":"AM","status":"Present","shortfallHours":0,"inH":9},"staff_3":{"productsSold":0,"workedMinutes":506,"otPay":0,"otHours":0,"servicesDone":0,"inM":35,"outM":1,"outH":6,"inAmpm":"AM","status":"Present","shortfallHours":1,"inH":9},"staff_1":{"productsSold":0,"workedMinutes":0,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":7,"inAmpm":"AM","status":"Weekly Off","shortfallHours":0,"inH":10},"staff_2":{"productsSold":0,"workedMinutes":594,"otPay":50,"otHours":1,"servicesDone":0,"inM":6,"outM":0,"outH":9,"inAmpm":"AM","status":"Present","shortfallHours":0,"inH":11}},"2026-05-30":{"staff_4":{"productsSold":0,"workedMinutes":540,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":6,"inAmpm":"AM","status":"Present","shortfallHours":0,"inH":9},"staff_9":{"productsSold":0,"workedMinutes":540,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":9,"inAmpm":"PM","status":"Present","shortfallHours":0,"inH":12},"staff_8":{"productsSold":0,"workedMinutes":720,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":9,"inAmpm":"AM","status":"Present","shortfallHours":0,"inH":9},"staff_5":{"productsSold":0,"workedMinutes":540,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":9,"inAmpm":"PM","status":"Present","shortfallHours":0,"inH":12},"staff_6":{"productsSold":0,"workedMinutes":540,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":9,"inAmpm":"PM","status":"Present","shortfallHours":0,"inH":12},"staff_3":{"productsSold":0,"workedMinutes":540,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":8,"inAmpm":"AM","status":"Present","shortfallHours":0,"inH":11},"staff_11":{"productsSold":0,"workedMinutes":540,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":6,"inAmpm":"AM","status":"Present","shortfallHours":0,"inH":9},"staff_10":{"productsSold":0,"workedMinutes":540,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":6,"inAmpm":"AM","status":"Present","shortfallHours":0,"inH":9},"staff_2":{"productsSold":0,"workedMinutes":540,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":9,"inAmpm":"PM","status":"Present","shortfallHours":0,"inH":12}},"2026-06-01":{"staff_4":{"productsSold":0,"workedMinutes":540,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":7,"inAmpm":"AM","status":"Present","shortfallHours":0,"inH":10},"staff_9":{"productsSold":0,"workedMinutes":540,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":9,"inAmpm":"PM","status":"Present","shortfallHours":0,"inH":12},"staff_8":{"productsSold":0,"workedMinutes":720,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":9,"inAmpm":"AM","status":"Present","shortfallHours":0,"inH":9},"staff_5":{"productsSold":0,"workedMinutes":540,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":6,"inAmpm":"AM","status":"Present","shortfallHours":0,"inH":9},"staff_6":{"productsSold":0,"workedMinutes":600,"otPay":50,"otHours":1,"servicesDone":0,"inM":0,"outM":0,"outH":9,"inAmpm":"AM","status":"Present","shortfallHours":0,"inH":11},"staff_3":{"productsSold":0,"workedMinutes":0,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":7,"inAmpm":"AM","status":"Weekly Off","shortfallHours":0,"inH":10},"staff_11":{"productsSold":0,"workedMinutes":0,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":7,"inAmpm":"AM","status":"Weekly Off","shortfallHours":0,"inH":10},"staff_10":{"productsSold":0,"workedMinutes":540,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":8,"inAmpm":"AM","status":"Present","shortfallHours":0,"inH":11},"staff_2":{"productsSold":0,"workedMinutes":540,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":6,"inAmpm":"AM","status":"Present","shortfallHours":0,"inH":9}},"2026-05-16":{"staff_4":{"productsSold":0,"workedMinutes":480,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":6,"inAmpm":"AM","status":"Present","shortfallHours":1,"inH":10},"staff_9":{"productsSold":0,"workedMinutes":540,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":6,"inAmpm":"AM","status":"Present","shortfallHours":0,"inH":9},"staff_8":{"productsSold":0,"workedMinutes":720,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":9,"inAmpm":"AM","status":"Present","shortfallHours":0,"inH":9},"staff_5":{"productsSold":0,"workedMinutes":540,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":6,"inAmpm":"AM","status":"Present","shortfallHours":0,"inH":9},"staff_6":{"productsSold":0,"workedMinutes":540,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":9,"inAmpm":"PM","status":"Present","shortfallHours":0,"inH":12},"staff_3":{"productsSold":0,"workedMinutes":540,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":9,"inAmpm":"PM","status":"Present","shortfallHours":0,"inH":12},"staff_11":{"productsSold":0,"workedMinutes":540,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":6,"inAmpm":"AM","status":"Present","shortfallHours":0,"inH":9},"staff_10":{"productsSold":0,"workedMinutes":540,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":9,"inAmpm":"PM","status":"Present","shortfallHours":0,"inH":12},"staff_2":{"productsSold":0,"workedMinutes":540,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":9,"inAmpm":"PM","status":"Present","shortfallHours":0,"inH":12},"staff_12":{"productsSold":0,"workedMinutes":540,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":6,"inAmpm":"AM","status":"Present","shortfallHours":0,"inH":9},"staff_13":{"productsSold":0,"workedMinutes":540,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":9,"inAmpm":"PM","status":"Present","shortfallHours":0,"inH":12}},"2026-07-23":{"staff_4":{"productsSold":0,"workedMinutes":540,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":6,"inAmpm":"AM","status":"Present","shortfallHours":0,"inH":9},"staff_7":{"productsSold":0,"workedMinutes":540,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":7,"inAmpm":"AM","status":"Present","shortfallHours":0,"inH":10},"staff_8":{"productsSold":0,"workedMinutes":720,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":9,"inAmpm":"AM","status":"Present","shortfallHours":0,"inH":9},"staff_5":{"productsSold":0,"workedMinutes":540,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":8,"inAmpm":"AM","status":"Present","shortfallHours":0,"inH":11},"staff_6":{"productsSold":0,"workedMinutes":540,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":9,"inAmpm":"PM","status":"Present","shortfallHours":0,"inH":12},"staff_3":{"otHours":0,"outH":7,"shortfallHours":0,"inAmpm":"AM","outM":0,"workedMinutes":0,"inH":10,"inM":0,"status":"Leave","servicesDone":0,"weekendCut":false,"productsSold":0,"otPay":0},"staff_1":{"productsSold":0,"workedMinutes":0,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":7,"inAmpm":"AM","status":"Weekly Off","shortfallHours":0,"inH":10},"staff_2":{"productsSold":0,"workedMinutes":600,"otPay":50,"otHours":1,"servicesDone":0,"inM":0,"outM":0,"outH":9,"inAmpm":"AM","status":"Present","shortfallHours":0,"inH":11}},"2026-09-13":{"staff_4":{"productsSold":0,"workedMinutes":712,"otPay":150,"otHours":3,"servicesDone":0,"inM":8,"outM":0,"outH":9,"inAmpm":"AM","status":"Present","shortfallHours":0,"inH":9},"staff_7":{"productsSold":0,"workedMinutes":540,"otPay":0,"otHours":0,"servicesDone":0,"inM":1,"outM":1,"outH":9,"inAmpm":"PM","status":"Present","shortfallHours":0,"inH":12},"staff_8":{"productsSold":0,"workedMinutes":0,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":9,"inAmpm":"AM","status":"Weekly Off","shortfallHours":0,"inH":9},"staff_5":{"productsSold":0,"workedMinutes":546,"otPay":0,"otHours":0,"servicesDone":0,"inM":56,"outM":2,"outH":8,"inAmpm":"AM","status":"Present","shortfallHours":0,"inH":10},"staff_6":{"productsSold":0,"workedMinutes":544,"otPay":0,"otHours":0,"servicesDone":0,"inM":9,"outM":13,"outH":7,"inAmpm":"AM","status":"Present","shortfallHours":0,"inH":10},"staff_3":{"productsSold":0,"workedMinutes":0,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":7,"inAmpm":"AM","status":"Weekly Off","shortfallHours":0,"inH":10},"staff_1":{"productsSold":0,"workedMinutes":534,"otPay":0,"otHours":0,"servicesDone":0,"inM":10,"outM":4,"outH":9,"inAmpm":"PM","status":"Present","shortfallHours":0,"inH":12},"staff_2":{"productsSold":0,"workedMinutes":0,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":7,"inAmpm":"AM","status":"Weekly Off","shortfallHours":0,"inH":10}},"2026-09-14":{"staff_4":{"productsSold":0,"workedMinutes":724,"otPay":150,"otHours":3,"servicesDone":0,"inM":51,"outM":55,"outH":8,"inAmpm":"AM","status":"Present","shortfallHours":0,"inH":8},"staff_7":{"productsSold":0,"workedMinutes":536,"otPay":0,"otHours":0,"servicesDone":0,"inM":4,"outM":0,"outH":9,"inAmpm":"PM","status":"Present","shortfallHours":0,"inH":12},"staff_8":{"productsSold":0,"workedMinutes":720,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":9,"inAmpm":"AM","status":"Present","shortfallHours":0,"inH":9},"staff_5":{"productsSold":0,"workedMinutes":547,"otPay":0,"otHours":0,"servicesDone":0,"inM":54,"outM":1,"outH":7,"inAmpm":"AM","status":"Present","shortfallHours":0,"inH":9},"staff_6":{"productsSold":0,"workedMinutes":0,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":7,"inAmpm":"AM","status":"Weekly Off","shortfallHours":0,"inH":10},"staff_3":{"productsSold":0,"workedMinutes":0,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":7,"inAmpm":"AM","status":"Weekly Off","shortfallHours":0,"inH":10},"staff_1":{"productsSold":0,"workedMinutes":631,"otPay":50,"otHours":1,"servicesDone":0,"inM":25,"outM":56,"outH":10,"inAmpm":"PM","status":"Present","shortfallHours":0,"inH":12},"staff_2":{"productsSold":0,"workedMinutes":0,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":7,"inAmpm":"AM","status":"Weekly Off","shortfallHours":0,"inH":10}},"2026-08-21":{"staff_4":{"productsSold":0,"workedMinutes":540,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":6,"inAmpm":"AM","status":"Present","shortfallHours":0,"inH":9},"staff_7":{"productsSold":0,"workedMinutes":540,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":7,"inAmpm":"AM","status":"Present","shortfallHours":0,"inH":10},"staff_8":{"productsSold":0,"workedMinutes":720,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":9,"inAmpm":"AM","status":"Present","shortfallHours":0,"inH":9},"staff_5":{"productsSold":0,"workedMinutes":540,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":7,"inAmpm":"AM","status":"Present","shortfallHours":0,"inH":10},"staff_6":{"productsSold":0,"workedMinutes":540,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":9,"inAmpm":"PM","status":"Present","shortfallHours":0,"inH":12},"staff_3":{"productsSold":0,"workedMinutes":540,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":9,"inAmpm":"PM","status":"Present","shortfallHours":0,"inH":12},"staff_1":{"productsSold":0,"workedMinutes":540,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":8,"inAmpm":"AM","status":"Present","shortfallHours":0,"inH":11},"staff_2":{"productsSold":0,"workedMinutes":540,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":8,"inAmpm":"AM","status":"Present","shortfallHours":0,"inH":11}},"2026-07-17":{"staff_7":{"productsSold":0,"workedMinutes":540,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":7,"inAmpm":"AM","status":"Present","shortfallHours":0,"inH":10},"staff_8":{"productsSold":0,"workedMinutes":720,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":9,"inAmpm":"AM","status":"Present","shortfallHours":0,"inH":9},"staff_5":{"productsSold":0,"workedMinutes":0,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":7,"inAmpm":"AM","status":"Weekly Off","shortfallHours":0,"inH":10},"staff_6":{"productsSold":0,"workedMinutes":540,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":9,"inAmpm":"PM","status":"Present","shortfallHours":0,"inH":12},"staff_3":{"productsSold":0,"workedMinutes":600,"otPay":50,"otHours":1,"servicesDone":0,"inM":0,"outM":0,"outH":9,"inAmpm":"AM","status":"Present","shortfallHours":0,"inH":11},"staff_1":{"productsSold":0,"workedMinutes":540,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":6,"inAmpm":"AM","status":"Present","shortfallHours":0,"inH":9},"staff_2":{"productsSold":0,"workedMinutes":0,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":7,"inAmpm":"AM","status":"Weekly Off","shortfallHours":0,"inH":10}},"2026-05-15":{"staff_4":{"productsSold":0,"workedMinutes":540,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":6,"inAmpm":"AM","status":"Present","shortfallHours":0,"inH":9},"staff_9":{"productsSold":0,"workedMinutes":540,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":9,"inAmpm":"PM","status":"Present","shortfallHours":0,"inH":12},"staff_8":{"productsSold":0,"workedMinutes":720,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":9,"inAmpm":"AM","status":"Present","shortfallHours":0,"inH":9},"staff_5":{"productsSold":0,"workedMinutes":540,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":8,"inAmpm":"AM","status":"Present","shortfallHours":0,"inH":11},"staff_6":{"productsSold":0,"workedMinutes":540,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":9,"inAmpm":"PM","status":"Present","shortfallHours":0,"inH":12},"staff_3":{"productsSold":0,"workedMinutes":540,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":8,"inAmpm":"AM","status":"Present","shortfallHours":0,"inH":11},"staff_11":{"productsSold":0,"workedMinutes":540,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":6,"inAmpm":"AM","status":"Present","shortfallHours":0,"inH":9},"staff_10":{"productsSold":0,"workedMinutes":540,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":7,"inAmpm":"AM","status":"Present","shortfallHours":0,"inH":10},"staff_2":{"productsSold":0,"workedMinutes":540,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":7,"inAmpm":"AM","status":"Present","shortfallHours":0,"inH":10},"staff_12":{"productsSold":0,"workedMinutes":540,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":6,"inAmpm":"AM","status":"Present","shortfallHours":0,"inH":9},"staff_13":{"productsSold":0,"workedMinutes":540,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":9,"inAmpm":"PM","status":"Present","shortfallHours":0,"inH":12}},"2026-05-25":{"staff_4":{"productsSold":0,"workedMinutes":540,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":6,"inAmpm":"AM","status":"Present","shortfallHours":0,"inH":9},"staff_9":{"productsSold":0,"workedMinutes":540,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":9,"inAmpm":"PM","status":"Present","shortfallHours":0,"inH":12},"staff_8":{"productsSold":0,"workedMinutes":720,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":9,"inAmpm":"AM","status":"Present","shortfallHours":0,"inH":9},"staff_5":{"productsSold":0,"workedMinutes":540,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":8,"inAmpm":"AM","status":"Present","shortfallHours":0,"inH":11},"staff_6":{"productsSold":0,"workedMinutes":540,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":9,"inAmpm":"PM","status":"Present","shortfallHours":0,"inH":12},"staff_3":{"productsSold":0,"workedMinutes":540,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":7,"inAmpm":"AM","status":"Present","shortfallHours":0,"inH":10},"staff_11":{"productsSold":0,"workedMinutes":540,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":6,"inAmpm":"AM","status":"Present","shortfallHours":0,"inH":9},"staff_10":{"productsSold":0,"workedMinutes":0,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":7,"inAmpm":"AM","status":"Weekly Off","shortfallHours":0,"inH":10},"staff_2":{"productsSold":0,"workedMinutes":540,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":8,"inAmpm":"AM","status":"Present","shortfallHours":0,"inH":11},"staff_12":{"productsSold":0,"workedMinutes":0,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":7,"inAmpm":"AM","status":"Weekly Off","shortfallHours":0,"inH":10}},"2026-09-26":{"staff_4":{"productsSold":0,"workedMinutes":540,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":9,"inAmpm":"PM","status":"Present","shortfallHours":0,"inH":12},"staff_7":{"productsSold":0,"workedMinutes":540,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":7,"inAmpm":"AM","status":"Present","shortfallHours":0,"inH":10},"staff_8":{"productsSold":0,"workedMinutes":720,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":9,"inAmpm":"AM","status":"Present","shortfallHours":0,"inH":9},"staff_5":{"productsSold":0,"workedMinutes":540,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":8,"inAmpm":"AM","status":"Present","shortfallHours":0,"inH":11},"staff_6":{"productsSold":0,"workedMinutes":540,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":9,"inAmpm":"PM","status":"Present","shortfallHours":0,"inH":12},"staff_3":{"inM":0,"outH":7,"otPay":0,"shortfallHours":0,"outM":0,"inH":10,"otHours":0,"servicesDone":0,"productsSold":0,"workedMinutes":0,"weekendCut":true,"inAmpm":"AM","status":"Leave"},"staff_1":{"productsSold":0,"workedMinutes":540,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":9,"inAmpm":"PM","status":"Present","shortfallHours":0,"inH":12},"staff_2":{"productsSold":0,"workedMinutes":0,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":7,"inAmpm":"AM","status":"Weekly Off","shortfallHours":0,"inH":10}},"2026-08-28":{"staff_4":{"productsSold":0,"workedMinutes":600,"otPay":50,"otHours":1,"servicesDone":0,"inM":0,"outM":0,"outH":9,"inAmpm":"AM","status":"Present","shortfallHours":0,"inH":11},"staff_7":{"productsSold":0,"workedMinutes":0,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":7,"inAmpm":"AM","status":"Weekly Off","shortfallHours":0,"inH":10},"staff_8":{"productsSold":0,"workedMinutes":720,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":9,"inAmpm":"AM","status":"Present","shortfallHours":0,"inH":9},"staff_5":{"productsSold":0,"workedMinutes":540,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":8,"inAmpm":"AM","status":"Present","shortfallHours":0,"inH":11},"staff_6":{"productsSold":0,"workedMinutes":660,"otPay":100,"otHours":2,"servicesDone":0,"inM":0,"outM":0,"outH":9,"inAmpm":"AM","status":"Present","shortfallHours":0,"inH":10},"staff_3":{"productsSold":0,"workedMinutes":540,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":6,"inAmpm":"AM","status":"Present","shortfallHours":0,"inH":9},"staff_1":{"productsSold":0,"workedMinutes":540,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":8,"inAmpm":"AM","status":"Present","shortfallHours":0,"inH":11},"staff_2":{"productsSold":0,"workedMinutes":0,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":7,"inAmpm":"AM","status":"Weekly Off","shortfallHours":0,"inH":10}},"2026-09-20":{"staff_4":{"productsSold":0,"workedMinutes":541,"otPay":0,"otHours":0,"servicesDone":0,"inM":11,"outM":12,"outH":6,"inAmpm":"AM","status":"Present","shortfallHours":0,"inH":9},"staff_7":{"productsSold":0,"workedMinutes":636,"otPay":50,"otHours":1,"servicesDone":0,"inM":24,"outM":0,"outH":9,"inAmpm":"AM","status":"Present","shortfallHours":0,"inH":10},"staff_8":{"productsSold":0,"workedMinutes":0,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":9,"inAmpm":"AM","status":"Weekly Off","shortfallHours":0,"inH":9},"staff_5":{"productsSold":0,"workedMinutes":567,"otPay":0,"otHours":0,"servicesDone":0,"inM":43,"outM":10,"outH":8,"inAmpm":"AM","status":"Present","shortfallHours":0,"inH":10},"staff_6":{"productsSold":0,"workedMinutes":0,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":7,"inAmpm":"AM","status":"Weekly Off","shortfallHours":0,"inH":10},"staff_3":{"productsSold":0,"workedMinutes":0,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":7,"inAmpm":"AM","status":"Weekly Off","shortfallHours":0,"inH":10},"staff_1":{"productsSold":0,"workedMinutes":583,"otPay":0,"otHours":0,"servicesDone":0,"inM":6,"outM":49,"outH":9,"inAmpm":"PM","status":"Present","shortfallHours":0,"inH":12},"staff_2":{"productsSold":0,"workedMinutes":549,"otPay":0,"otHours":0,"servicesDone":0,"inM":51,"outM":0,"outH":9,"inAmpm":"AM","status":"Present","shortfallHours":0,"inH":11}},"2026-07-16":{"staff_7":{"productsSold":0,"workedMinutes":540,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":7,"inAmpm":"AM","status":"Present","shortfallHours":0,"inH":10},"staff_8":{"productsSold":0,"workedMinutes":720,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":9,"inAmpm":"AM","status":"Present","shortfallHours":0,"inH":9},"staff_5":{"productsSold":0,"workedMinutes":540,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":8,"inAmpm":"AM","status":"Present","shortfallHours":0,"inH":11},"staff_6":{"productsSold":0,"workedMinutes":540,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":9,"inAmpm":"PM","status":"Present","shortfallHours":0,"inH":12},"staff_3":{"productsSold":0,"workedMinutes":540,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":9,"inAmpm":"PM","status":"Present","shortfallHours":0,"inH":12},"staff_1":{"productsSold":0,"workedMinutes":540,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":9,"inAmpm":"PM","status":"Present","shortfallHours":0,"inH":12},"staff_2":{"productsSold":0,"workedMinutes":540,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":7,"inAmpm":"AM","status":"Present","shortfallHours":0,"inH":10}},"2026-05-14":{"staff_4":{"productsSold":0,"workedMinutes":540,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":6,"inAmpm":"AM","status":"Present","shortfallHours":0,"inH":9},"staff_9":{"productsSold":0,"workedMinutes":540,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":7,"inAmpm":"AM","status":"Present","shortfallHours":0,"inH":10},"staff_8":{"productsSold":0,"workedMinutes":720,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":9,"inAmpm":"AM","status":"Present","shortfallHours":0,"inH":9},"staff_5":{"productsSold":0,"workedMinutes":540,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":8,"inAmpm":"AM","status":"Present","shortfallHours":0,"inH":11},"staff_6":{"productsSold":0,"workedMinutes":540,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":9,"inAmpm":"PM","status":"Present","shortfallHours":0,"inH":12},"staff_3":{"productsSold":0,"workedMinutes":540,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":8,"inAmpm":"AM","status":"Present","shortfallHours":0,"inH":11},"staff_11":{"productsSold":0,"workedMinutes":540,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":6,"inAmpm":"AM","status":"Present","shortfallHours":0,"inH":9},"staff_10":{"productsSold":0,"workedMinutes":0,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":7,"inAmpm":"AM","status":"Weekly Off","shortfallHours":0,"inH":10},"staff_2":{"productsSold":0,"workedMinutes":540,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":9,"inAmpm":"PM","status":"Present","shortfallHours":0,"inH":12},"staff_12":{"productsSold":0,"workedMinutes":540,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":6,"inAmpm":"AM","status":"Present","shortfallHours":0,"inH":9},"staff_13":{"productsSold":0,"workedMinutes":540,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":9,"inAmpm":"PM","status":"Present","shortfallHours":0,"inH":12}},"2026-06-04":{"staff_4":{"productsSold":0,"workedMinutes":540,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":7,"inAmpm":"AM","status":"Present","shortfallHours":0,"inH":10},"staff_9":{"productsSold":0,"workedMinutes":540,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":6,"inAmpm":"AM","status":"Present","shortfallHours":0,"inH":9},"staff_8":{"productsSold":0,"workedMinutes":720,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":9,"inAmpm":"AM","status":"Present","shortfallHours":0,"inH":9},"staff_5":{"productsSold":0,"workedMinutes":0,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":7,"inAmpm":"AM","status":"Weekly Off","shortfallHours":0,"inH":10},"staff_6":{"productsSold":0,"workedMinutes":540,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":6,"inAmpm":"AM","status":"Present","shortfallHours":0,"inH":9},"staff_3":{"productsSold":0,"workedMinutes":540,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":9,"inAmpm":"PM","status":"Present","shortfallHours":0,"inH":12},"staff_11":{"productsSold":0,"workedMinutes":540,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":9,"inAmpm":"PM","status":"Present","shortfallHours":0,"inH":12},"staff_10":{"productsSold":0,"workedMinutes":540,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":9,"inAmpm":"PM","status":"Present","shortfallHours":0,"inH":12},"staff_2":{"productsSold":0,"workedMinutes":540,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":9,"inAmpm":"PM","status":"Present","shortfallHours":0,"inH":12}},"2026-09-15":{"staff_4":{"productsSold":0,"workedMinutes":0,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":7,"inAmpm":"AM","status":"Weekly Off","shortfallHours":0,"inH":10},"staff_7":{"productsSold":0,"workedMinutes":0,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":7,"inAmpm":"AM","status":"Weekly Off","shortfallHours":0,"inH":10},"staff_8":{"productsSold":0,"workedMinutes":720,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":9,"inAmpm":"AM","status":"Present","shortfallHours":0,"inH":9},"staff_5":{"productsSold":0,"workedMinutes":547,"otPay":0,"otHours":0,"servicesDone":0,"inM":52,"outM":59,"outH":6,"inAmpm":"AM","status":"Present","shortfallHours":0,"inH":9},"staff_6":{"productsSold":0,"workedMinutes":540,"otPay":0,"otHours":0,"servicesDone":0,"inM":59,"outM":59,"outH":8,"inAmpm":"AM","status":"Present","shortfallHours":0,"inH":11},"staff_3":{"productsSold":0,"workedMinutes":0,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":7,"inAmpm":"AM","status":"Weekly Off","shortfallHours":0,"inH":10},"staff_1":{"productsSold":0,"workedMinutes":568,"otPay":0,"otHours":0,"servicesDone":0,"inM":59,"outM":27,"outH":9,"inAmpm":"AM","status":"Present","shortfallHours":0,"inH":11},"staff_2":{"productsSold":0,"workedMinutes":749,"otPay":150,"otHours":3,"servicesDone":0,"inM":56,"outM":25,"outH":9,"inAmpm":"AM","status":"Present","shortfallHours":0,"inH":8}},"2026-06-19":{"staff_4":{"productsSold":0,"workedMinutes":540,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":6,"inAmpm":"AM","status":"Present","shortfallHours":0,"inH":9},"staff_8":{"productsSold":0,"workedMinutes":720,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":9,"inAmpm":"AM","status":"Present","shortfallHours":0,"inH":9},"staff_5":{"productsSold":0,"workedMinutes":540,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":8,"inAmpm":"AM","status":"Present","shortfallHours":0,"inH":11},"staff_6":{"productsSold":0,"workedMinutes":540,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":6,"inAmpm":"AM","status":"Present","shortfallHours":0,"inH":9},"staff_3":{"productsSold":0,"workedMinutes":600,"otPay":50,"otHours":1,"servicesDone":0,"inM":0,"outM":0,"outH":9,"inAmpm":"AM","status":"Present","shortfallHours":0,"inH":11},"staff_11":{"productsSold":0,"workedMinutes":540,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":9,"inAmpm":"PM","status":"Present","shortfallHours":0,"inH":12},"staff_2":{"productsSold":0,"workedMinutes":0,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":7,"inAmpm":"AM","status":"Weekly Off","shortfallHours":0,"inH":10},"staff_12":{"productsSold":0,"workedMinutes":540,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":9,"inAmpm":"PM","status":"Present","shortfallHours":0,"inH":12}},"2026-05-07":{"staff_4":{"productsSold":0,"workedMinutes":540,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":6,"inAmpm":"AM","status":"Present","shortfallHours":0,"inH":9},"staff_9":{"productsSold":0,"workedMinutes":540,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":9,"inAmpm":"PM","status":"Present","shortfallHours":0,"inH":12},"staff_8":{"productsSold":0,"workedMinutes":720,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":9,"inAmpm":"AM","status":"Present","shortfallHours":0,"inH":9},"staff_5":{"productsSold":0,"workedMinutes":0,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":7,"inAmpm":"AM","status":"Weekly Off","shortfallHours":0,"inH":10},"staff_6":{"productsSold":0,"workedMinutes":540,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":8,"inAmpm":"AM","status":"Present","shortfallHours":0,"inH":11},"staff_3":{"productsSold":0,"workedMinutes":540,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":8,"inAmpm":"AM","status":"Present","shortfallHours":0,"inH":11},"staff_11":{"productsSold":0,"workedMinutes":540,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":9,"inAmpm":"PM","status":"Present","shortfallHours":0,"inH":12},"staff_10":{"productsSold":0,"workedMinutes":540,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":6,"inAmpm":"AM","status":"Present","shortfallHours":0,"inH":9},"staff_2":{"productsSold":0,"workedMinutes":540,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":9,"inAmpm":"PM","status":"Present","shortfallHours":0,"inH":12},"staff_12":{"productsSold":0,"workedMinutes":540,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":6,"inAmpm":"AM","status":"Present","shortfallHours":0,"inH":9},"staff_13":{"productsSold":0,"workedMinutes":540,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":9,"inAmpm":"PM","status":"Present","shortfallHours":0,"inH":12}},"2026-08-30":{"staff_4":{"productsSold":0,"workedMinutes":540,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":7,"inAmpm":"AM","status":"Present","shortfallHours":0,"inH":10},"staff_7":{"productsSold":0,"workedMinutes":540,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":9,"inAmpm":"PM","status":"Present","shortfallHours":0,"inH":12},"staff_8":{"productsSold":0,"workedMinutes":720,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":9,"inAmpm":"AM","status":"Present","shortfallHours":0,"inH":9},"staff_5":{"productsSold":0,"workedMinutes":540,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":8,"inAmpm":"AM","status":"Present","shortfallHours":0,"inH":11},"staff_6":{"productsSold":0,"workedMinutes":540,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":7,"inAmpm":"AM","status":"Present","shortfallHours":0,"inH":10},"staff_3":{"productsSold":0,"workedMinutes":540,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":6,"inAmpm":"AM","status":"Present","shortfallHours":0,"inH":9},"staff_1":{"productsSold":0,"workedMinutes":540,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":9,"inAmpm":"PM","status":"Present","shortfallHours":0,"inH":12},"staff_2":{"productsSold":0,"workedMinutes":540,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":9,"inAmpm":"PM","status":"Present","shortfallHours":0,"inH":12}},"2026-08-14":{"staff_4":{"productsSold":0,"workedMinutes":540,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":6,"inAmpm":"AM","status":"Present","shortfallHours":0,"inH":9},"staff_7":{"productsSold":0,"workedMinutes":540,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":7,"inAmpm":"AM","status":"Present","shortfallHours":0,"inH":10},"staff_8":{"productsSold":0,"workedMinutes":720,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":9,"inAmpm":"AM","status":"Present","shortfallHours":0,"inH":9},"staff_5":{"productsSold":0,"workedMinutes":540,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":8,"inAmpm":"AM","status":"Present","shortfallHours":0,"inH":11},"staff_6":{"productsSold":0,"workedMinutes":540,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":9,"inAmpm":"PM","status":"Present","shortfallHours":0,"inH":12},"staff_3":{"productsSold":0,"workedMinutes":540,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":9,"inAmpm":"PM","status":"Present","shortfallHours":0,"inH":12},"staff_1":{"productsSold":0,"workedMinutes":0,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":7,"inAmpm":"AM","status":"Weekly Off","shortfallHours":0,"inH":10},"staff_2":{"productsSold":0,"workedMinutes":0,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":7,"inAmpm":"AM","status":"Weekly Off","shortfallHours":0,"inH":10}},"2026-09-08":{"staff_4":{"productsSold":0,"workedMinutes":0,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":7,"inAmpm":"AM","status":"Weekly Off","shortfallHours":0,"inH":10},"staff_7":{"productsSold":0,"workedMinutes":552,"otPay":0,"otHours":0,"servicesDone":0,"inM":2,"outM":14,"outH":9,"inAmpm":"PM","status":"Present","shortfallHours":0,"inH":12},"staff_8":{"productsSold":0,"workedMinutes":720,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":9,"inAmpm":"AM","status":"Present","shortfallHours":0,"inH":9},"staff_5":{"productsSold":0,"workedMinutes":544,"otPay":0,"otHours":0,"servicesDone":0,"inM":1,"outM":5,"outH":7,"inAmpm":"AM","status":"Present","shortfallHours":0,"inH":10},"staff_6":{"productsSold":0,"workedMinutes":0,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":7,"inAmpm":"AM","status":"Leave","shortfallHours":0,"inH":10},"staff_3":{"productsSold":0,"workedMinutes":546,"otPay":0,"otHours":0,"servicesDone":0,"inM":8,"outM":14,"outH":9,"inAmpm":"PM","status":"Present","shortfallHours":0,"inH":12},"staff_1":{"productsSold":0,"workedMinutes":545,"otPay":0,"otHours":0,"servicesDone":0,"inM":9,"outM":14,"outH":9,"inAmpm":"PM","status":"Present","shortfallHours":0,"inH":12},"staff_2":{"productsSold":0,"workedMinutes":567,"otPay":0,"otHours":0,"servicesDone":0,"inM":8,"outM":35,"outH":6,"inAmpm":"AM","status":"Present","shortfallHours":0,"inH":9}},"2026-09-10":{"staff_4":{"productsSold":0,"workedMinutes":520,"otPay":0,"otHours":0,"servicesDone":0,"inM":20,"outM":0,"outH":9,"inAmpm":"PM","status":"Present","shortfallHours":0,"inH":12},"staff_7":{"productsSold":0,"workedMinutes":527,"otPay":0,"otHours":0,"servicesDone":0,"inM":14,"outM":1,"outH":9,"inAmpm":"PM","status":"Present","shortfallHours":0,"inH":12},"staff_8":{"productsSold":0,"workedMinutes":720,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":9,"inAmpm":"AM","status":"Present","shortfallHours":0,"inH":9},"staff_5":{"productsSold":0,"workedMinutes":0,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":7,"inAmpm":"AM","status":"Weekly Off","shortfallHours":0,"inH":10},"staff_6":{"productsSold":0,"workedMinutes":556,"otPay":0,"otHours":0,"servicesDone":0,"inM":48,"outM":4,"outH":7,"inAmpm":"AM","status":"Present","shortfallHours":0,"inH":9},"staff_3":{"productsSold":0,"workedMinutes":717,"otPay":150,"otHours":3,"servicesDone":0,"inM":3,"outM":0,"outH":9,"inAmpm":"AM","status":"Present","shortfallHours":0,"inH":9},"staff_1":{"productsSold":0,"workedMinutes":542,"otPay":0,"otHours":0,"servicesDone":0,"inM":6,"outM":8,"outH":9,"inAmpm":"PM","status":"Present","shortfallHours":0,"inH":12},"staff_2":{"productsSold":0,"workedMinutes":531,"otPay":0,"otHours":0,"servicesDone":0,"inM":9,"outM":0,"outH":9,"inAmpm":"PM","status":"Present","shortfallHours":0,"inH":12}},"2026-07-10":{"staff_4":{"productsSold":0,"workedMinutes":540,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":5,"inAmpm":"AM","status":"Present","shortfallHours":0,"inH":8},"staff_8":{"productsSold":0,"workedMinutes":720,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":9,"inAmpm":"AM","status":"Present","shortfallHours":0,"inH":9},"staff_5":{"productsSold":0,"workedMinutes":540,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":8,"inAmpm":"AM","status":"Present","shortfallHours":0,"inH":11},"staff_6":{"productsSold":0,"workedMinutes":660,"otPay":100,"otHours":2,"servicesDone":0,"inM":0,"outM":0,"outH":9,"inAmpm":"AM","status":"Present","shortfallHours":0,"inH":10},"staff_3":{"productsSold":0,"workedMinutes":600,"otPay":50,"otHours":1,"servicesDone":0,"inM":0,"outM":0,"outH":9,"inAmpm":"AM","status":"Present","shortfallHours":0,"inH":11},"staff_1":{"productsSold":0,"workedMinutes":540,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":9,"inAmpm":"PM","status":"Present","shortfallHours":0,"inH":12},"staff_2":{"productsSold":0,"workedMinutes":0,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":7,"inAmpm":"AM","status":"Weekly Off","shortfallHours":0,"inH":10}},"2026-08-08":{"staff_4":{"otHours":0,"outH":7,"shortfallHours":0,"inAmpm":"AM","outM":0,"workedMinutes":0,"inH":10,"inM":0,"status":"Leave","servicesDone":0,"weekendCut":true,"productsSold":0,"otPay":0},"staff_7":{"productsSold":0,"workedMinutes":540,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":9,"inAmpm":"PM","status":"Present","shortfallHours":0,"inH":12},"staff_8":{"productsSold":0,"workedMinutes":720,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":9,"inAmpm":"AM","status":"Present","shortfallHours":0,"inH":9},"staff_5":{"productsSold":0,"workedMinutes":540,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":8,"inAmpm":"AM","status":"Present","shortfallHours":0,"inH":11},"staff_6":{"productsSold":0,"workedMinutes":540,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":7,"inAmpm":"AM","status":"Present","shortfallHours":0,"inH":10},"staff_3":{"productsSold":0,"workedMinutes":540,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":9,"inAmpm":"PM","status":"Present","shortfallHours":0,"inH":12},"staff_1":{"productsSold":0,"workedMinutes":540,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":9,"inAmpm":"PM","status":"Present","shortfallHours":0,"inH":12},"staff_2":{"productsSold":0,"workedMinutes":540,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":6,"inAmpm":"AM","status":"Present","shortfallHours":0,"inH":9}},"2026-06-15":{"staff_4":{"productsSold":0,"workedMinutes":540,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":6,"inAmpm":"AM","status":"Present","shortfallHours":0,"inH":9},"staff_8":{"productsSold":0,"workedMinutes":720,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":9,"inAmpm":"AM","status":"Present","shortfallHours":0,"inH":9},"staff_5":{"productsSold":0,"workedMinutes":540,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":9,"inAmpm":"PM","status":"Present","shortfallHours":0,"inH":12},"staff_6":{"productsSold":0,"workedMinutes":540,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":6,"inAmpm":"AM","status":"Present","shortfallHours":0,"inH":9},"staff_3":{"otHours":0,"outH":7,"shortfallHours":0,"inAmpm":"AM","outM":0,"workedMinutes":0,"inH":10,"inM":0,"status":"Leave","servicesDone":0,"weekendCut":false,"productsSold":0,"otPay":0},"staff_11":{"productsSold":0,"workedMinutes":540,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":9,"inAmpm":"PM","status":"Present","shortfallHours":0,"inH":12},"staff_2":{"productsSold":0,"workedMinutes":540,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":9,"inAmpm":"PM","status":"Present","shortfallHours":0,"inH":12},"staff_12":{"productsSold":0,"workedMinutes":540,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":9,"inAmpm":"PM","status":"Present","shortfallHours":0,"inH":12}},"2026-06-18":{"staff_4":{"productsSold":0,"workedMinutes":540,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":6,"inAmpm":"AM","status":"Present","shortfallHours":0,"inH":9},"staff_8":{"productsSold":0,"workedMinutes":720,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":9,"inAmpm":"AM","status":"Present","shortfallHours":0,"inH":9},"staff_5":{"productsSold":0,"workedMinutes":0,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":7,"inAmpm":"AM","status":"Weekly Off","shortfallHours":0,"inH":10},"staff_6":{"productsSold":0,"workedMinutes":540,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":6,"inAmpm":"AM","status":"Present","shortfallHours":0,"inH":9},"staff_3":{"productsSold":0,"workedMinutes":540,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":9,"inAmpm":"PM","status":"Present","shortfallHours":0,"inH":12},"staff_11":{"productsSold":0,"workedMinutes":600,"otPay":50,"otHours":1,"servicesDone":0,"inM":0,"outM":0,"outH":9,"inAmpm":"AM","status":"Present","shortfallHours":0,"inH":11},"staff_2":{"productsSold":0,"workedMinutes":540,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":9,"inAmpm":"PM","status":"Present","shortfallHours":0,"inH":12},"staff_12":{"productsSold":0,"workedMinutes":540,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":9,"inAmpm":"PM","status":"Present","shortfallHours":0,"inH":12}},"2026-07-02":{"staff_4":{"productsSold":0,"workedMinutes":540,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":7,"inAmpm":"AM","status":"Present","shortfallHours":0,"inH":10},"staff_8":{"productsSold":0,"workedMinutes":720,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":9,"inAmpm":"AM","status":"Present","shortfallHours":0,"inH":9},"staff_5":{"productsSold":0,"workedMinutes":540,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":8,"inAmpm":"AM","status":"Present","shortfallHours":0,"inH":11},"staff_6":{"productsSold":0,"workedMinutes":540,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":7,"inAmpm":"AM","status":"Present","shortfallHours":0,"inH":10},"staff_3":{"productsSold":0,"workedMinutes":540,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":9,"inAmpm":"PM","status":"Present","shortfallHours":0,"inH":12},"staff_11":{"productsSold":0,"workedMinutes":540,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":9,"inAmpm":"PM","status":"Present","shortfallHours":0,"inH":12},"staff_2":{"productsSold":0,"workedMinutes":540,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":5,"inAmpm":"AM","status":"Present","shortfallHours":0,"inH":8},"staff_12":{"productsSold":0,"workedMinutes":540,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":9,"inAmpm":"PM","status":"Present","shortfallHours":0,"inH":12}},"2026-08-01":{"staff_4":{"productsSold":0,"workedMinutes":540,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":6,"inAmpm":"AM","status":"Present","shortfallHours":0,"inH":9},"staff_7":{"productsSold":0,"workedMinutes":540,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":9,"inAmpm":"PM","status":"Present","shortfallHours":0,"inH":12},"staff_8":{"productsSold":0,"workedMinutes":720,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":9,"inAmpm":"AM","status":"Present","shortfallHours":0,"inH":9},"staff_5":{"productsSold":0,"workedMinutes":540,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":8,"inAmpm":"AM","status":"Present","shortfallHours":0,"inH":11},"staff_6":{"productsSold":0,"workedMinutes":540,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":7,"inAmpm":"AM","status":"Present","shortfallHours":0,"inH":10},"staff_3":{"productsSold":0,"workedMinutes":540,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":9,"inAmpm":"PM","status":"Present","shortfallHours":0,"inH":12},"staff_1":{"productsSold":0,"workedMinutes":540,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":6,"inAmpm":"AM","status":"Present","shortfallHours":0,"inH":9},"staff_2":{"productsSold":0,"workedMinutes":540,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":7,"inAmpm":"AM","status":"Present","shortfallHours":0,"inH":10}},"2026-06-08":{"staff_4":{"productsSold":0,"workedMinutes":540,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":6,"inAmpm":"AM","status":"Present","shortfallHours":0,"inH":9},"staff_9":{"productsSold":0,"workedMinutes":540,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":9,"inAmpm":"PM","status":"Present","shortfallHours":0,"inH":12},"staff_8":{"productsSold":0,"workedMinutes":720,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":9,"inAmpm":"AM","status":"Present","shortfallHours":0,"inH":9},"staff_5":{"productsSold":0,"workedMinutes":540,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":7,"inAmpm":"AM","status":"Present","shortfallHours":0,"inH":10},"staff_6":{"productsSold":0,"workedMinutes":0,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":7,"inAmpm":"AM","status":"Weekly Off","shortfallHours":0,"inH":10},"staff_3":{"productsSold":0,"workedMinutes":540,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":7,"inAmpm":"AM","status":"Present","shortfallHours":0,"inH":10},"staff_11":{"productsSold":0,"workedMinutes":600,"otPay":50,"otHours":1,"servicesDone":0,"inM":0,"outM":0,"outH":9,"inAmpm":"AM","status":"Present","shortfallHours":0,"inH":11},"staff_10":{"productsSold":0,"workedMinutes":540,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":9,"inAmpm":"PM","status":"Present","shortfallHours":0,"inH":12},"staff_2":{"productsSold":0,"workedMinutes":540,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":8,"inAmpm":"AM","status":"Present","shortfallHours":0,"inH":11},"staff_12":{"productsSold":0,"workedMinutes":540,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":6,"inAmpm":"AM","status":"Present","shortfallHours":0,"inH":9}},"2026-06-07":{"staff_4":{"productsSold":0,"workedMinutes":540,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":7,"inAmpm":"AM","status":"Present","shortfallHours":0,"inH":10},"staff_9":{"productsSold":0,"workedMinutes":540,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":6,"inAmpm":"AM","status":"Present","shortfallHours":0,"inH":9},"staff_8":{"productsSold":0,"workedMinutes":720,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":9,"inAmpm":"AM","status":"Present","shortfallHours":0,"inH":9},"staff_5":{"productsSold":0,"workedMinutes":540,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":6,"inAmpm":"AM","status":"Present","shortfallHours":0,"inH":9},"staff_6":{"productsSold":0,"workedMinutes":540,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":6,"inAmpm":"AM","status":"Present","shortfallHours":0,"inH":9},"staff_3":{"productsSold":0,"workedMinutes":540,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":9,"inAmpm":"PM","status":"Present","shortfallHours":0,"inH":12},"staff_11":{"productsSold":0,"workedMinutes":540,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":9,"inAmpm":"PM","status":"Present","shortfallHours":0,"inH":12},"staff_10":{"productsSold":0,"workedMinutes":540,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":9,"inAmpm":"PM","status":"Present","shortfallHours":0,"inH":12},"staff_2":{"productsSold":0,"workedMinutes":540,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":9,"inAmpm":"PM","status":"Present","shortfallHours":0,"inH":12}},"2026-09-05":{"staff_4":{"productsSold":0,"workedMinutes":547,"otPay":0,"otHours":0,"servicesDone":0,"inM":5,"outM":12,"outH":9,"inAmpm":"PM","status":"Present","shortfallHours":0,"inH":12},"staff_7":{"productsSold":0,"workedMinutes":529,"otPay":0,"otHours":0,"servicesDone":0,"inM":14,"outM":3,"outH":9,"inAmpm":"PM","status":"Present","shortfallHours":0,"inH":12},"staff_8":{"productsSold":0,"workedMinutes":720,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":9,"inAmpm":"AM","status":"Present","shortfallHours":0,"inH":9},"staff_5":{"productsSold":0,"workedMinutes":554,"otPay":0,"otHours":0,"servicesDone":0,"inM":46,"outM":0,"outH":8,"inAmpm":"AM","status":"Present","shortfallHours":0,"inH":10},"staff_6":{"productsSold":0,"workedMinutes":532,"otPay":0,"otHours":0,"servicesDone":0,"inM":14,"outM":6,"outH":7,"inAmpm":"AM","status":"Present","shortfallHours":0,"inH":10},"staff_3":{"productsSold":0,"workedMinutes":538,"otPay":0,"otHours":0,"servicesDone":0,"inM":15,"outM":13,"outH":6,"inAmpm":"AM","status":"Present","shortfallHours":0,"inH":9},"staff_1":{"productsSold":0,"workedMinutes":557,"otPay":0,"otHours":0,"servicesDone":0,"inM":6,"outM":23,"outH":9,"inAmpm":"PM","status":"Present","shortfallHours":0,"inH":12},"staff_2":{"productsSold":0,"workedMinutes":560,"otPay":0,"otHours":0,"servicesDone":0,"inM":59,"outM":19,"outH":9,"inAmpm":"AM","status":"Present","shortfallHours":0,"inH":11}},"2026-05-09":{"staff_4":{"productsSold":0,"workedMinutes":540,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":7,"inAmpm":"AM","status":"Present","shortfallHours":0,"inH":10},"staff_9":{"productsSold":0,"workedMinutes":540,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":9,"inAmpm":"PM","status":"Present","shortfallHours":0,"inH":12},"staff_8":{"productsSold":0,"workedMinutes":720,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":9,"inAmpm":"AM","status":"Present","shortfallHours":0,"inH":9},"staff_5":{"productsSold":0,"workedMinutes":540,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":8,"inAmpm":"AM","status":"Present","shortfallHours":0,"inH":11},"staff_6":{"productsSold":0,"workedMinutes":540,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":7,"inAmpm":"AM","status":"Present","shortfallHours":0,"inH":10},"staff_3":{"productsSold":0,"workedMinutes":540,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":6,"inAmpm":"AM","status":"Present","shortfallHours":0,"inH":9},"staff_11":{"productsSold":0,"workedMinutes":540,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":6,"inAmpm":"AM","status":"Present","shortfallHours":0,"inH":9},"staff_10":{"productsSold":0,"workedMinutes":540,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":9,"inAmpm":"PM","status":"Present","shortfallHours":0,"inH":12},"staff_2":{"productsSold":0,"workedMinutes":540,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":9,"inAmpm":"PM","status":"Present","shortfallHours":0,"inH":12}},"2026-09-06":{"staff_4":{"productsSold":0,"workedMinutes":514,"otPay":0,"otHours":0,"servicesDone":0,"inM":26,"outM":0,"outH":9,"inAmpm":"PM","status":"Present","shortfallHours":0,"inH":12},"staff_7":{"productsSold":0,"workedMinutes":530,"otPay":0,"otHours":0,"servicesDone":0,"inM":10,"outM":0,"outH":9,"inAmpm":"PM","status":"Present","shortfallHours":0,"inH":12},"staff_8":{"productsSold":0,"workedMinutes":0,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":9,"inAmpm":"AM","status":"Weekly Off","shortfallHours":0,"inH":9},"staff_5":{"productsSold":0,"workedMinutes":615,"otPay":50,"otHours":1,"servicesDone":0,"inM":45,"outM":0,"outH":9,"inAmpm":"AM","status":"Present","shortfallHours":0,"inH":10},"staff_6":{"productsSold":0,"workedMinutes":544,"otPay":0,"otHours":0,"servicesDone":0,"inM":58,"outM":2,"outH":7,"inAmpm":"AM","status":"Present","shortfallHours":0,"inH":9},"staff_3":{"productsSold":0,"workedMinutes":715,"otPay":150,"otHours":3,"servicesDone":0,"inM":5,"outM":0,"outH":9,"inAmpm":"AM","status":"Present","shortfallHours":0,"inH":9},"staff_1":{"productsSold":0,"workedMinutes":525,"otPay":0,"otHours":0,"servicesDone":0,"inM":25,"outM":10,"outH":9,"inAmpm":"PM","status":"Present","shortfallHours":0,"inH":12},"staff_2":{"productsSold":0,"workedMinutes":660,"otPay":100,"otHours":2,"servicesDone":0,"inM":0,"outM":0,"outH":9,"inAmpm":"AM","status":"Present","shortfallHours":0,"inH":10}},"2026-08-02":{"staff_4":{"productsSold":0,"workedMinutes":540,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":6,"inAmpm":"AM","status":"Present","shortfallHours":0,"inH":9},"staff_7":{"productsSold":0,"workedMinutes":540,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":9,"inAmpm":"PM","status":"Present","shortfallHours":0,"inH":12},"staff_8":{"productsSold":0,"workedMinutes":720,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":9,"inAmpm":"AM","status":"Present","shortfallHours":0,"inH":9},"staff_5":{"productsSold":0,"workedMinutes":540,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":8,"inAmpm":"AM","status":"Present","shortfallHours":0,"inH":11},"staff_6":{"productsSold":0,"workedMinutes":540,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":7,"inAmpm":"AM","status":"Present","shortfallHours":0,"inH":10},"staff_3":{"productsSold":0,"workedMinutes":540,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":9,"inAmpm":"PM","status":"Present","shortfallHours":0,"inH":12},"staff_1":{"productsSold":0,"workedMinutes":540,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":6,"inAmpm":"AM","status":"Present","shortfallHours":0,"inH":9},"staff_2":{"productsSold":0,"workedMinutes":540,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":7,"inAmpm":"AM","status":"Present","shortfallHours":0,"inH":10}},"2026-06-24":{"staff_4":{"productsSold":0,"workedMinutes":540,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":6,"inAmpm":"AM","status":"Present","shortfallHours":0,"inH":9},"staff_8":{"productsSold":0,"workedMinutes":720,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":9,"inAmpm":"AM","status":"Present","shortfallHours":0,"inH":9},"staff_5":{"productsSold":0,"workedMinutes":540,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":8,"inAmpm":"AM","status":"Present","shortfallHours":0,"inH":11},"staff_6":{"productsSold":0,"workedMinutes":540,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":9,"inAmpm":"PM","status":"Present","shortfallHours":0,"inH":12},"staff_3":{"productsSold":0,"workedMinutes":600,"otPay":50,"otHours":1,"servicesDone":0,"inM":0,"outM":0,"outH":9,"inAmpm":"AM","status":"Present","shortfallHours":0,"inH":11},"staff_11":{"productsSold":0,"workedMinutes":540,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":6,"inAmpm":"AM","status":"Present","shortfallHours":0,"inH":9},"staff_2":{"productsSold":0,"workedMinutes":0,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":7,"inAmpm":"AM","status":"Weekly Off","shortfallHours":0,"inH":10},"staff_12":{"productsSold":0,"workedMinutes":540,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":6,"inAmpm":"AM","status":"Present","shortfallHours":0,"inH":9}},"2026-05-28":{"staff_4":{"productsSold":0,"workedMinutes":540,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":9,"inAmpm":"PM","status":"Present","shortfallHours":0,"inH":12},"staff_9":{"productsSold":0,"workedMinutes":540,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":6,"inAmpm":"AM","status":"Present","shortfallHours":0,"inH":9},"staff_8":{"productsSold":0,"workedMinutes":720,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":9,"inAmpm":"AM","status":"Present","shortfallHours":0,"inH":9},"staff_5":{"productsSold":0,"workedMinutes":0,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":7,"inAmpm":"AM","status":"Weekly Off","shortfallHours":0,"inH":10},"staff_6":{"productsSold":0,"workedMinutes":0,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":7,"inAmpm":"AM","status":"Weekly Off","shortfallHours":0,"inH":10},"staff_3":{"productsSold":0,"workedMinutes":480,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":8,"inAmpm":"PM","status":"Present","shortfallHours":1,"inH":12},"staff_11":{"productsSold":0,"workedMinutes":720,"otPay":150,"otHours":3,"servicesDone":0,"inM":0,"outM":0,"outH":9,"inAmpm":"AM","status":"Present","shortfallHours":0,"inH":9},"staff_10":{"productsSold":0,"workedMinutes":720,"otPay":150,"otHours":3,"servicesDone":0,"inM":0,"outM":0,"outH":9,"inAmpm":"AM","status":"Present","shortfallHours":0,"inH":9},"staff_2":{"productsSold":0,"workedMinutes":0,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":7,"inAmpm":"AM","status":"Weekly Off","shortfallHours":0,"inH":10},"staff_12":{"productsSold":0,"workedMinutes":540,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":9,"inAmpm":"PM","status":"Present","shortfallHours":0,"inH":12}},"2026-09-01":{"staff_4":{"productsSold":0,"workedMinutes":0,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":7,"inAmpm":"AM","status":"Weekly Off","shortfallHours":0,"inH":10},"staff_7":{"productsSold":0,"workedMinutes":511,"otPay":0,"otHours":0,"servicesDone":0,"inM":5,"outM":36,"outH":8,"inAmpm":"PM","status":"Present","shortfallHours":0,"inH":12},"staff_8":{"productsSold":0,"workedMinutes":720,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":9,"inAmpm":"AM","status":"Present","shortfallHours":0,"inH":9},"staff_5":{"productsSold":0,"workedMinutes":0,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":7,"inAmpm":"AM","status":"Weekly Off","shortfallHours":0,"inH":10},"staff_6":{"productsSold":0,"workedMinutes":541,"otPay":0,"otHours":0,"servicesDone":0,"inM":20,"outM":21,"outH":7,"inAmpm":"AM","status":"Present","shortfallHours":0,"inH":10},"staff_3":{"productsSold":0,"workedMinutes":539,"otPay":0,"otHours":0,"servicesDone":0,"inM":58,"outM":57,"outH":5,"inAmpm":"AM","status":"Present","shortfallHours":0,"inH":8},"staff_1":{"productsSold":0,"workedMinutes":517,"otPay":0,"otHours":0,"servicesDone":0,"inM":5,"outM":42,"outH":8,"inAmpm":"PM","status":"Present","shortfallHours":0,"inH":12},"staff_2":{"productsSold":0,"workedMinutes":505,"otPay":0,"otHours":0,"servicesDone":0,"inM":7,"outM":32,"outH":8,"inAmpm":"PM","status":"Present","shortfallHours":1,"inH":12}},"2026-07-27":{"staff_4":{"productsSold":0,"workedMinutes":540,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":6,"inAmpm":"AM","status":"Present","shortfallHours":0,"inH":9},"staff_7":{"productsSold":0,"workedMinutes":540,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":7,"inAmpm":"AM","status":"Present","shortfallHours":0,"inH":10},"staff_8":{"productsSold":0,"workedMinutes":720,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":9,"inAmpm":"AM","status":"Present","shortfallHours":0,"inH":9},"staff_5":{"productsSold":0,"workedMinutes":540,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":8,"inAmpm":"AM","status":"Present","shortfallHours":0,"inH":11},"staff_6":{"productsSold":0,"workedMinutes":540,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":9,"inAmpm":"PM","status":"Present","shortfallHours":0,"inH":12},"staff_3":{"otHours":0,"outH":7,"shortfallHours":0,"inAmpm":"AM","outM":0,"workedMinutes":0,"inH":10,"inM":0,"status":"Leave","servicesDone":0,"weekendCut":false,"productsSold":0,"otPay":0},"staff_1":{"productsSold":0,"workedMinutes":540,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":6,"inAmpm":"AM","status":"Present","shortfallHours":0,"inH":9},"staff_2":{"productsSold":0,"workedMinutes":600,"otPay":50,"otHours":1,"servicesDone":0,"inM":0,"outM":0,"outH":9,"inAmpm":"AM","status":"Present","shortfallHours":0,"inH":11}},"2026-07-20":{"staff_4":{"productsSold":0,"workedMinutes":540,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":6,"inAmpm":"AM","status":"Present","shortfallHours":0,"inH":9},"staff_7":{"productsSold":0,"workedMinutes":540,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":7,"inAmpm":"AM","status":"Present","shortfallHours":0,"inH":10},"staff_8":{"productsSold":0,"workedMinutes":720,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":9,"inAmpm":"AM","status":"Present","shortfallHours":0,"inH":9},"staff_5":{"productsSold":0,"workedMinutes":540,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":8,"inAmpm":"AM","status":"Present","shortfallHours":0,"inH":11},"staff_6":{"productsSold":0,"workedMinutes":540,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":9,"inAmpm":"PM","status":"Present","shortfallHours":0,"inH":12},"staff_3":{"otHours":0,"outH":7,"shortfallHours":0,"inAmpm":"AM","outM":0,"workedMinutes":0,"inH":10,"inM":0,"status":"Leave","servicesDone":0,"weekendCut":false,"productsSold":0,"otPay":0},"staff_1":{"productsSold":0,"workedMinutes":540,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":9,"inAmpm":"PM","status":"Present","shortfallHours":0,"inH":12},"staff_2":{"productsSold":0,"workedMinutes":600,"otPay":50,"otHours":1,"servicesDone":0,"inM":0,"outM":0,"outH":9,"inAmpm":"AM","status":"Present","shortfallHours":0,"inH":11}},"2026-07-14":{"staff_4":{"productsSold":0,"workedMinutes":540,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":5,"inAmpm":"AM","status":"Present","shortfallHours":0,"inH":8},"staff_7":{"productsSold":0,"workedMinutes":540,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":7,"inAmpm":"AM","status":"Present","shortfallHours":0,"inH":10},"staff_8":{"productsSold":0,"workedMinutes":720,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":9,"inAmpm":"AM","status":"Present","shortfallHours":0,"inH":9},"staff_5":{"productsSold":0,"workedMinutes":540,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":8,"inAmpm":"AM","status":"Present","shortfallHours":0,"inH":11},"staff_6":{"productsSold":0,"workedMinutes":540,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":9,"inAmpm":"PM","status":"Present","shortfallHours":0,"inH":12},"staff_3":{"productsSold":0,"workedMinutes":540,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":9,"inAmpm":"PM","status":"Present","shortfallHours":0,"inH":12},"staff_1":{"productsSold":0,"workedMinutes":540,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":9,"inAmpm":"PM","status":"Present","shortfallHours":0,"inH":12},"staff_2":{"productsSold":0,"workedMinutes":540,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":7,"inAmpm":"AM","status":"Present","shortfallHours":0,"inH":10}},"2026-06-30":{"staff_4":{"productsSold":0,"workedMinutes":0,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":7,"inAmpm":"AM","status":"Weekly Off","shortfallHours":0,"inH":10},"staff_8":{"productsSold":0,"workedMinutes":720,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":9,"inAmpm":"AM","status":"Present","shortfallHours":0,"inH":9},"staff_5":{"productsSold":0,"workedMinutes":540,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":7,"inAmpm":"AM","status":"Present","shortfallHours":0,"inH":10},"staff_6":{"productsSold":0,"workedMinutes":600,"otPay":50,"otHours":1,"servicesDone":0,"inM":0,"outM":0,"outH":9,"inAmpm":"AM","status":"Present","shortfallHours":0,"inH":11},"staff_3":{"productsSold":0,"workedMinutes":600,"otPay":50,"otHours":1,"servicesDone":0,"inM":0,"outM":0,"outH":9,"inAmpm":"AM","status":"Present","shortfallHours":0,"inH":11},"staff_11":{"productsSold":0,"workedMinutes":0,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":7,"inAmpm":"AM","status":"Weekly Off","shortfallHours":0,"inH":10},"staff_2":{"productsSold":0,"workedMinutes":600,"otPay":50,"otHours":1,"servicesDone":0,"inM":0,"outM":0,"outH":6,"inAmpm":"AM","status":"Present","shortfallHours":0,"inH":8},"staff_12":{"productsSold":0,"workedMinutes":540,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":6,"inAmpm":"AM","status":"Present","shortfallHours":0,"inH":9}},"2026-07-11":{"staff_4":{"productsSold":0,"workedMinutes":540,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":5,"inAmpm":"AM","status":"Present","shortfallHours":0,"inH":8},"staff_8":{"productsSold":0,"workedMinutes":720,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":9,"inAmpm":"AM","status":"Present","shortfallHours":0,"inH":9},"staff_5":{"productsSold":0,"workedMinutes":540,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":8,"inAmpm":"AM","status":"Present","shortfallHours":0,"inH":11},"staff_6":{"productsSold":0,"workedMinutes":660,"otPay":100,"otHours":2,"servicesDone":0,"inM":0,"outM":0,"outH":9,"inAmpm":"AM","status":"Present","shortfallHours":0,"inH":10},"staff_3":{"productsSold":0,"workedMinutes":540,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":9,"inAmpm":"PM","status":"Present","shortfallHours":0,"inH":12},"staff_1":{"productsSold":0,"workedMinutes":540,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":9,"inAmpm":"PM","status":"Present","shortfallHours":0,"inH":12},"staff_2":{"productsSold":0,"workedMinutes":540,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":7,"inAmpm":"AM","status":"Present","shortfallHours":0,"inH":10}},"2026-07-01":{"staff_4":{"productsSold":0,"workedMinutes":540,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":7,"inAmpm":"AM","status":"Present","shortfallHours":0,"inH":10},"staff_8":{"productsSold":0,"workedMinutes":720,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":9,"inAmpm":"AM","status":"Present","shortfallHours":0,"inH":9},"staff_5":{"productsSold":0,"workedMinutes":540,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":8,"inAmpm":"AM","status":"Present","shortfallHours":0,"inH":11},"staff_6":{"productsSold":0,"workedMinutes":540,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":6,"inAmpm":"AM","status":"Present","shortfallHours":0,"inH":9},"staff_3":{"productsSold":0,"workedMinutes":540,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":9,"inAmpm":"PM","status":"Present","shortfallHours":0,"inH":12},"staff_11":{"productsSold":0,"workedMinutes":540,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":9,"inAmpm":"PM","status":"Present","shortfallHours":0,"inH":12},"staff_2":{"productsSold":0,"workedMinutes":540,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":5,"inAmpm":"AM","status":"Present","shortfallHours":0,"inH":8},"staff_12":{"productsSold":0,"workedMinutes":0,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":7,"inAmpm":"AM","status":"Weekly Off","shortfallHours":0,"inH":10}},"2026-08-22":{"staff_4":{"productsSold":0,"workedMinutes":540,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":6,"inAmpm":"AM","status":"Present","shortfallHours":0,"inH":9},"staff_7":{"productsSold":0,"workedMinutes":540,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":9,"inAmpm":"PM","status":"Present","shortfallHours":0,"inH":12},"staff_8":{"productsSold":0,"workedMinutes":720,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":9,"inAmpm":"AM","status":"Present","shortfallHours":0,"inH":9},"staff_5":{"productsSold":0,"workedMinutes":540,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":8,"inAmpm":"AM","status":"Present","shortfallHours":0,"inH":11},"staff_6":{"productsSold":0,"workedMinutes":540,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":7,"inAmpm":"AM","status":"Present","shortfallHours":0,"inH":10},"staff_3":{"productsSold":0,"workedMinutes":540,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":9,"inAmpm":"PM","status":"Present","shortfallHours":0,"inH":12},"staff_1":{"productsSold":0,"workedMinutes":540,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":8,"inAmpm":"AM","status":"Present","shortfallHours":0,"inH":11},"staff_2":{"productsSold":0,"workedMinutes":540,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":7,"inAmpm":"AM","status":"Present","shortfallHours":0,"inH":10}},"2026-05-31":{"staff_4":{"productsSold":0,"workedMinutes":540,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":6,"inAmpm":"AM","status":"Present","shortfallHours":0,"inH":9},"staff_9":{"productsSold":0,"workedMinutes":540,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":7,"inAmpm":"AM","status":"Present","shortfallHours":0,"inH":10},"staff_8":{"productsSold":0,"workedMinutes":720,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":9,"inAmpm":"AM","status":"Present","shortfallHours":0,"inH":9},"staff_5":{"productsSold":0,"workedMinutes":540,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":9,"inAmpm":"PM","status":"Present","shortfallHours":0,"inH":12},"staff_6":{"productsSold":0,"workedMinutes":720,"otPay":150,"otHours":3,"servicesDone":0,"inM":0,"outM":0,"outH":9,"inAmpm":"AM","status":"Present","shortfallHours":0,"inH":9},"staff_3":{"productsSold":0,"workedMinutes":540,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":9,"inAmpm":"PM","status":"Present","shortfallHours":0,"inH":12},"staff_11":{"productsSold":0,"workedMinutes":360,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":6,"inAmpm":"PM","status":"Present","shortfallHours":3,"inH":12},"staff_10":{"productsSold":0,"workedMinutes":540,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":6,"inAmpm":"AM","status":"Present","shortfallHours":0,"inH":9},"staff_2":{"productsSold":0,"workedMinutes":540,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":9,"inAmpm":"PM","status":"Present","shortfallHours":0,"inH":12}},"2026-08-18":{"staff_4":{"productsSold":0,"workedMinutes":540,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":6,"inAmpm":"AM","status":"Present","shortfallHours":0,"inH":9},"staff_7":{"productsSold":0,"workedMinutes":540,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":7,"inAmpm":"AM","status":"Present","shortfallHours":0,"inH":10},"staff_8":{"productsSold":0,"workedMinutes":720,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":9,"inAmpm":"AM","status":"Present","shortfallHours":0,"inH":9},"staff_5":{"productsSold":0,"workedMinutes":540,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":7,"inAmpm":"AM","status":"Present","shortfallHours":0,"inH":10},"staff_6":{"productsSold":0,"workedMinutes":540,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":9,"inAmpm":"PM","status":"Present","shortfallHours":0,"inH":12},"staff_3":{"productsSold":0,"workedMinutes":0,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":7,"inAmpm":"AM","status":"Weekly Off","shortfallHours":0,"inH":10},"staff_1":{"productsSold":0,"workedMinutes":540,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":8,"inAmpm":"AM","status":"Present","shortfallHours":0,"inH":11},"staff_2":{"productsSold":0,"workedMinutes":540,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":9,"inAmpm":"PM","status":"Present","shortfallHours":0,"inH":12}},"2026-07-22":{"staff_4":{"productsSold":0,"workedMinutes":540,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":6,"inAmpm":"AM","status":"Present","shortfallHours":0,"inH":9},"staff_7":{"productsSold":0,"workedMinutes":540,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":7,"inAmpm":"AM","status":"Present","shortfallHours":0,"inH":10},"staff_8":{"productsSold":0,"workedMinutes":720,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":9,"inAmpm":"AM","status":"Present","shortfallHours":0,"inH":9},"staff_5":{"productsSold":0,"workedMinutes":540,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":8,"inAmpm":"AM","status":"Present","shortfallHours":0,"inH":11},"staff_6":{"productsSold":0,"workedMinutes":540,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":9,"inAmpm":"PM","status":"Present","shortfallHours":0,"inH":12},"staff_3":{"otHours":0,"outH":7,"shortfallHours":0,"inAmpm":"AM","outM":0,"workedMinutes":0,"inH":10,"inM":0,"status":"Leave","servicesDone":0,"weekendCut":false,"productsSold":0,"otPay":0},"staff_1":{"productsSold":0,"workedMinutes":540,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":9,"inAmpm":"PM","status":"Present","shortfallHours":0,"inH":12},"staff_2":{"productsSold":0,"workedMinutes":600,"otPay":50,"otHours":1,"servicesDone":0,"inM":0,"outM":0,"outH":9,"inAmpm":"AM","status":"Present","shortfallHours":0,"inH":11}},"2026-06-13":{"staff_4":{"productsSold":0,"workedMinutes":540,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":6,"inAmpm":"AM","status":"Present","shortfallHours":0,"inH":9},"staff_9":{"productsSold":0,"workedMinutes":540,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":6,"inAmpm":"AM","status":"Present","shortfallHours":0,"inH":9},"staff_8":{"productsSold":0,"workedMinutes":720,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":9,"inAmpm":"AM","status":"Present","shortfallHours":0,"inH":9},"staff_5":{"productsSold":0,"workedMinutes":540,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":9,"inAmpm":"PM","status":"Present","shortfallHours":0,"inH":12},"staff_6":{"productsSold":0,"workedMinutes":540,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":9,"inAmpm":"PM","status":"Present","shortfallHours":0,"inH":12},"staff_3":{"productsSold":0,"workedMinutes":540,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":9,"inAmpm":"PM","status":"Present","shortfallHours":0,"inH":12},"staff_11":{"productsSold":0,"workedMinutes":540,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":6,"inAmpm":"AM","status":"Present","shortfallHours":0,"inH":9},"staff_10":{"productsSold":0,"workedMinutes":540,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":6,"inAmpm":"AM","status":"Present","shortfallHours":0,"inH":9},"staff_2":{"productsSold":0,"workedMinutes":540,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":9,"inAmpm":"PM","status":"Present","shortfallHours":0,"inH":12},"staff_12":{"productsSold":0,"workedMinutes":540,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":6,"inAmpm":"AM","status":"Present","shortfallHours":0,"inH":9}},"2026-08-07":{"staff_4":{"otHours":0,"outH":7,"shortfallHours":0,"inAmpm":"AM","outM":0,"workedMinutes":0,"inH":10,"inM":0,"status":"Leave","servicesDone":0,"weekendCut":false,"productsSold":0,"otPay":0},"staff_7":{"productsSold":0,"workedMinutes":540,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":9,"inAmpm":"PM","status":"Present","shortfallHours":0,"inH":12},"staff_8":{"productsSold":0,"workedMinutes":720,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":9,"inAmpm":"AM","status":"Present","shortfallHours":0,"inH":9},"staff_5":{"productsSold":0,"workedMinutes":0,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":7,"inAmpm":"AM","status":"Weekly Off","shortfallHours":0,"inH":10},"staff_6":{"productsSold":0,"workedMinutes":540,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":7,"inAmpm":"AM","status":"Present","shortfallHours":0,"inH":10},"staff_3":{"productsSold":0,"workedMinutes":540,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":9,"inAmpm":"PM","status":"Present","shortfallHours":0,"inH":12},"staff_1":{"productsSold":0,"workedMinutes":540,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":9,"inAmpm":"PM","status":"Present","shortfallHours":0,"inH":12},"staff_2":{"productsSold":0,"workedMinutes":540,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":6,"inAmpm":"AM","status":"Present","shortfallHours":0,"inH":9}},"2026-06-09":{"staff_4":{"productsSold":0,"workedMinutes":540,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":6,"inAmpm":"AM","status":"Present","shortfallHours":0,"inH":9},"staff_9":{"productsSold":0,"workedMinutes":540,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":9,"inAmpm":"PM","status":"Present","shortfallHours":0,"inH":12},"staff_8":{"productsSold":0,"workedMinutes":720,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":9,"inAmpm":"AM","status":"Present","shortfallHours":0,"inH":9},"staff_5":{"productsSold":0,"workedMinutes":540,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":7,"inAmpm":"AM","status":"Present","shortfallHours":0,"inH":10},"staff_6":{"productsSold":0,"workedMinutes":600,"otPay":50,"otHours":1,"servicesDone":0,"inM":0,"outM":0,"outH":9,"inAmpm":"AM","status":"Present","shortfallHours":0,"inH":11},"staff_3":{"productsSold":0,"workedMinutes":0,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":7,"inAmpm":"AM","status":"Weekly Off","shortfallHours":0,"inH":10},"staff_11":{"productsSold":0,"workedMinutes":0,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":7,"inAmpm":"AM","status":"Weekly Off","shortfallHours":0,"inH":10},"staff_10":{"productsSold":0,"workedMinutes":540,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":9,"inAmpm":"PM","status":"Present","shortfallHours":0,"inH":12},"staff_2":{"productsSold":0,"workedMinutes":540,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":8,"inAmpm":"AM","status":"Present","shortfallHours":0,"inH":11},"staff_12":{"productsSold":0,"workedMinutes":540,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":6,"inAmpm":"AM","status":"Present","shortfallHours":0,"inH":9}},"2026-09-23":{"staff_4":{"productsSold":0,"workedMinutes":725,"otPay":150,"otHours":3,"servicesDone":0,"inM":55,"outM":0,"outH":9,"inAmpm":"AM","status":"Present","shortfallHours":0,"inH":8},"staff_7":{"productsSold":0,"workedMinutes":547,"otPay":0,"otHours":0,"servicesDone":0,"inM":53,"outM":0,"outH":9,"inAmpm":"AM","status":"Present","shortfallHours":0,"inH":11},"staff_8":{"productsSold":0,"workedMinutes":720,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":9,"inAmpm":"AM","status":"Present","shortfallHours":0,"inH":9},"staff_5":{"productsSold":0,"workedMinutes":538,"otPay":0,"otHours":0,"servicesDone":0,"inM":6,"outM":4,"outH":7,"inAmpm":"AM","status":"Present","shortfallHours":0,"inH":10},"staff_6":{"productsSold":0,"workedMinutes":0,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":7,"inAmpm":"AM","status":"Weekly Off","shortfallHours":0,"inH":10},"staff_3":{"productsSold":0,"workedMinutes":0,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":7,"inAmpm":"AM","status":"Weekly Off","shortfallHours":0,"inH":10},"staff_1":{"productsSold":0,"workedMinutes":482,"otPay":0,"otHours":0,"servicesDone":0,"inM":13,"outM":15,"outH":6,"inAmpm":"AM","status":"Present","shortfallHours":1,"inH":10},"staff_2":{"productsSold":0,"workedMinutes":0,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":7,"inAmpm":"AM","status":"Weekly Off","shortfallHours":0,"inH":10}},"2026-05-26":{"staff_4":{"productsSold":0,"workedMinutes":540,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":7,"inAmpm":"AM","status":"Present","shortfallHours":0,"inH":10},"staff_9":{"productsSold":0,"workedMinutes":540,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":6,"inAmpm":"AM","status":"Present","shortfallHours":0,"inH":9},"staff_8":{"productsSold":0,"workedMinutes":720,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":9,"inAmpm":"AM","status":"Present","shortfallHours":0,"inH":9},"staff_5":{"productsSold":0,"workedMinutes":540,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":8,"inAmpm":"AM","status":"Present","shortfallHours":0,"inH":11},"staff_6":{"productsSold":0,"workedMinutes":600,"otPay":50,"otHours":1,"servicesDone":0,"inM":0,"outM":0,"outH":9,"inAmpm":"AM","status":"Present","shortfallHours":0,"inH":11},"staff_3":{"productsSold":0,"workedMinutes":480,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":8,"inAmpm":"PM","status":"Present","shortfallHours":1,"inH":12},"staff_11":{"productsSold":0,"workedMinutes":0,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":7,"inAmpm":"AM","status":"Weekly Off","shortfallHours":0,"inH":10},"staff_10":{"productsSold":0,"workedMinutes":540,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":6,"inAmpm":"AM","status":"Present","shortfallHours":0,"inH":9},"staff_2":{"productsSold":0,"workedMinutes":540,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":9,"inAmpm":"PM","status":"Present","shortfallHours":0,"inH":12},"staff_12":{"productsSold":0,"workedMinutes":540,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":9,"inAmpm":"PM","status":"Present","shortfallHours":0,"inH":12}},"2026-08-06":{"staff_4":{"otHours":0,"outH":7,"shortfallHours":0,"inAmpm":"AM","outM":0,"workedMinutes":0,"inH":10,"inM":0,"status":"Leave","servicesDone":0,"weekendCut":false,"productsSold":0,"otPay":0},"staff_7":{"productsSold":0,"workedMinutes":540,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":7,"inAmpm":"AM","status":"Present","shortfallHours":0,"inH":10},"staff_8":{"productsSold":0,"workedMinutes":720,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":9,"inAmpm":"AM","status":"Present","shortfallHours":0,"inH":9},"staff_5":{"productsSold":0,"workedMinutes":540,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":8,"inAmpm":"AM","status":"Present","shortfallHours":0,"inH":11},"staff_6":{"productsSold":0,"workedMinutes":540,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":9,"inAmpm":"PM","status":"Present","shortfallHours":0,"inH":12},"staff_3":{"productsSold":0,"workedMinutes":540,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":6,"inAmpm":"AM","status":"Present","shortfallHours":0,"inH":9},"staff_1":{"productsSold":0,"workedMinutes":0,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":7,"inAmpm":"AM","status":"Weekly Off","shortfallHours":0,"inH":10},"staff_2":{"productsSold":0,"workedMinutes":540,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":9,"inAmpm":"PM","status":"Present","shortfallHours":0,"inH":12}},"2026-07-03":{"staff_4":{"productsSold":0,"workedMinutes":600,"otPay":50,"otHours":1,"servicesDone":0,"inM":0,"outM":0,"outH":6,"inAmpm":"AM","status":"Present","shortfallHours":0,"inH":8},"staff_8":{"productsSold":0,"workedMinutes":720,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":9,"inAmpm":"AM","status":"Present","shortfallHours":0,"inH":9},"staff_5":{"productsSold":0,"workedMinutes":540,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":8,"inAmpm":"AM","status":"Present","shortfallHours":0,"inH":11},"staff_6":{"productsSold":0,"workedMinutes":660,"otPay":100,"otHours":2,"servicesDone":0,"inM":0,"outM":0,"outH":9,"inAmpm":"AM","status":"Present","shortfallHours":0,"inH":10},"staff_3":{"productsSold":0,"workedMinutes":540,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":7,"inAmpm":"AM","status":"Present","shortfallHours":0,"inH":10},"staff_2":{"productsSold":0,"workedMinutes":540,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":9,"inAmpm":"PM","status":"Present","shortfallHours":0,"inH":12}},"2026-05-06":{"staff_4":{"productsSold":0,"workedMinutes":0,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":7,"inAmpm":"AM","status":"Weekly Off","shortfallHours":0,"inH":10},"staff_9":{"productsSold":0,"workedMinutes":540,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":8,"inAmpm":"AM","status":"Present","shortfallHours":0,"inH":11},"staff_8":{"productsSold":0,"workedMinutes":720,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":9,"inAmpm":"AM","status":"Present","shortfallHours":0,"inH":9},"staff_5":{"productsSold":0,"workedMinutes":540,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":8,"inAmpm":"AM","status":"Present","shortfallHours":0,"inH":11},"staff_6":{"productsSold":0,"workedMinutes":540,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":6,"inAmpm":"AM","status":"Present","shortfallHours":0,"inH":9},"staff_3":{"productsSold":0,"workedMinutes":540,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":6,"inAmpm":"AM","status":"Present","shortfallHours":0,"inH":9},"staff_11":{"productsSold":0,"workedMinutes":540,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":9,"inAmpm":"PM","status":"Present","shortfallHours":0,"inH":12},"staff_10":{"productsSold":0,"workedMinutes":0,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":7,"inAmpm":"AM","status":"Weekly Off","shortfallHours":0,"inH":10},"staff_2":{"productsSold":0,"workedMinutes":540,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":9,"inAmpm":"PM","status":"Present","shortfallHours":0,"inH":12}},"2026-09-21":{"staff_4":{"productsSold":0,"workedMinutes":542,"otPay":0,"otHours":0,"servicesDone":0,"inM":6,"outM":8,"outH":6,"inAmpm":"AM","status":"Present","shortfallHours":0,"inH":9},"staff_7":{"productsSold":0,"workedMinutes":536,"otPay":0,"otHours":0,"servicesDone":0,"inM":5,"outM":1,"outH":9,"inAmpm":"PM","status":"Present","shortfallHours":0,"inH":12},"staff_8":{"productsSold":0,"workedMinutes":720,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":9,"inAmpm":"AM","status":"Present","shortfallHours":0,"inH":9},"staff_5":{"productsSold":0,"workedMinutes":548,"otPay":0,"otHours":0,"servicesDone":0,"inM":52,"outM":0,"outH":7,"inAmpm":"AM","status":"Present","shortfallHours":0,"inH":9},"staff_6":{"productsSold":0,"workedMinutes":0,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":7,"inAmpm":"AM","status":"Weekly Off","shortfallHours":0,"inH":10},"staff_3":{"productsSold":0,"workedMinutes":0,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":7,"inAmpm":"AM","status":"Weekly Off","shortfallHours":0,"inH":10},"staff_1":{"productsSold":0,"workedMinutes":539,"otPay":0,"otHours":0,"servicesDone":0,"inM":6,"outM":5,"outH":9,"inAmpm":"PM","status":"Present","shortfallHours":0,"inH":12},"staff_2":{"productsSold":0,"workedMinutes":532,"otPay":0,"otHours":0,"servicesDone":0,"inM":11,"outM":3,"outH":9,"inAmpm":"PM","status":"Present","shortfallHours":0,"inH":12}},"2026-09-09":{"staff_4":{"productsSold":0,"workedMinutes":523,"otPay":0,"otHours":0,"servicesDone":0,"inM":17,"outM":0,"outH":9,"inAmpm":"PM","status":"Present","shortfallHours":0,"inH":12},"staff_7":{"productsSold":0,"workedMinutes":0,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":7,"inAmpm":"AM","status":"Weekly Off","shortfallHours":0,"inH":10},"staff_8":{"productsSold":0,"workedMinutes":720,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":9,"inAmpm":"AM","status":"Present","shortfallHours":0,"inH":9},"staff_5":{"productsSold":0,"workedMinutes":529,"otPay":0,"otHours":0,"servicesDone":0,"inM":15,"outM":4,"outH":7,"inAmpm":"AM","status":"Present","shortfallHours":0,"inH":10},"staff_6":{"productsSold":0,"workedMinutes":530,"otPay":0,"otHours":0,"servicesDone":0,"inM":10,"outM":0,"outH":9,"inAmpm":"PM","status":"Present","shortfallHours":0,"inH":12},"staff_3":{"productsSold":0,"workedMinutes":551,"otPay":0,"otHours":0,"servicesDone":0,"inM":19,"outM":30,"outH":6,"inAmpm":"AM","status":"Present","shortfallHours":0,"inH":9},"staff_1":{"productsSold":0,"workedMinutes":0,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":7,"inAmpm":"AM","status":"Weekly Off","shortfallHours":0,"inH":10},"staff_2":{"productsSold":0,"workedMinutes":0,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":7,"inAmpm":"AM","status":"Weekly Off","shortfallHours":0,"inH":10}},"2026-05-19":{"staff_4":{"productsSold":0,"workedMinutes":0,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":7,"inAmpm":"AM","status":"Weekly Off","shortfallHours":0,"inH":10},"staff_9":{"productsSold":0,"workedMinutes":540,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":6,"inAmpm":"AM","status":"Present","shortfallHours":0,"inH":9},"staff_8":{"productsSold":0,"workedMinutes":720,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":9,"inAmpm":"AM","status":"Present","shortfallHours":0,"inH":9},"staff_5":{"productsSold":0,"workedMinutes":540,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":8,"inAmpm":"AM","status":"Present","shortfallHours":0,"inH":11},"staff_6":{"productsSold":0,"workedMinutes":600,"otPay":50,"otHours":1,"servicesDone":0,"inM":0,"outM":0,"outH":9,"inAmpm":"AM","status":"Present","shortfallHours":0,"inH":11},"staff_3":{"productsSold":0,"workedMinutes":540,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":9,"inAmpm":"PM","status":"Present","shortfallHours":0,"inH":12},"staff_11":{"productsSold":0,"workedMinutes":0,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":7,"inAmpm":"AM","status":"Weekly Off","shortfallHours":0,"inH":10},"staff_10":{"productsSold":0,"workedMinutes":540,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":6,"inAmpm":"AM","status":"Present","shortfallHours":0,"inH":9},"staff_2":{"productsSold":0,"workedMinutes":540,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":8,"inAmpm":"AM","status":"Present","shortfallHours":0,"inH":11},"staff_12":{"productsSold":0,"workedMinutes":540,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":6,"inAmpm":"AM","status":"Present","shortfallHours":0,"inH":9}},"2026-05-29":{"staff_4":{"productsSold":0,"workedMinutes":540,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":6,"inAmpm":"AM","status":"Present","shortfallHours":0,"inH":9},"staff_9":{"productsSold":0,"workedMinutes":0,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":7,"inAmpm":"AM","status":"Weekly Off","shortfallHours":0,"inH":10},"staff_8":{"productsSold":0,"workedMinutes":720,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":9,"inAmpm":"AM","status":"Present","shortfallHours":0,"inH":9},"staff_5":{"otHours":0,"outH":7,"shortfallHours":0,"inAmpm":"AM","outM":0,"workedMinutes":0,"inH":10,"inM":0,"status":"Leave","servicesDone":0,"weekendCut":false,"productsSold":0,"otPay":0},"staff_6":{"productsSold":0,"workedMinutes":540,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":9,"inAmpm":"PM","status":"Present","shortfallHours":0,"inH":12},"staff_3":{"productsSold":0,"workedMinutes":540,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":8,"inAmpm":"AM","status":"Present","shortfallHours":0,"inH":11},"staff_11":{"productsSold":0,"workedMinutes":540,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":6,"inAmpm":"AM","status":"Present","shortfallHours":0,"inH":9},"staff_10":{"productsSold":0,"workedMinutes":540,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":5,"inAmpm":"AM","status":"Present","shortfallHours":0,"inH":8},"staff_2":{"productsSold":0,"workedMinutes":540,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":9,"inAmpm":"PM","status":"Present","shortfallHours":0,"inH":12},"staff_12":{"productsSold":0,"workedMinutes":540,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":9,"inAmpm":"PM","status":"Present","shortfallHours":0,"inH":12}},"2026-06-23":{"staff_4":{"productsSold":0,"workedMinutes":0,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":7,"inAmpm":"AM","status":"Weekly Off","shortfallHours":0,"inH":10},"staff_8":{"productsSold":0,"workedMinutes":720,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":9,"inAmpm":"AM","status":"Present","shortfallHours":0,"inH":9},"staff_5":{"productsSold":0,"workedMinutes":540,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":7,"inAmpm":"AM","status":"Present","shortfallHours":0,"inH":10},"staff_6":{"productsSold":0,"workedMinutes":600,"otPay":50,"otHours":1,"servicesDone":0,"inM":0,"outM":0,"outH":9,"inAmpm":"AM","status":"Present","shortfallHours":0,"inH":11},"staff_3":{"productsSold":0,"workedMinutes":540,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":6,"inAmpm":"AM","status":"Present","shortfallHours":0,"inH":9},"staff_11":{"productsSold":0,"workedMinutes":0,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":7,"inAmpm":"AM","status":"Weekly Off","shortfallHours":0,"inH":10},"staff_2":{"productsSold":0,"workedMinutes":600,"otPay":50,"otHours":1,"servicesDone":0,"inM":0,"outM":0,"outH":9,"inAmpm":"AM","status":"Present","shortfallHours":0,"inH":11},"staff_12":{"productsSold":0,"workedMinutes":540,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":6,"inAmpm":"AM","status":"Present","shortfallHours":0,"inH":9}},"2026-08-24":{"staff_4":{"productsSold":0,"workedMinutes":540,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":6,"inAmpm":"AM","status":"Present","shortfallHours":0,"inH":9},"staff_7":{"productsSold":0,"workedMinutes":660,"otPay":100,"otHours":2,"servicesDone":0,"inM":0,"outM":0,"outH":9,"inAmpm":"AM","status":"Present","shortfallHours":0,"inH":10},"staff_8":{"productsSold":0,"workedMinutes":720,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":9,"inAmpm":"AM","status":"Present","shortfallHours":0,"inH":9},"staff_5":{"productsSold":0,"workedMinutes":540,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":8,"inAmpm":"AM","status":"Present","shortfallHours":0,"inH":11},"staff_6":{"productsSold":0,"workedMinutes":0,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":7,"inAmpm":"AM","status":"Weekly Off","shortfallHours":0,"inH":10},"staff_3":{"productsSold":0,"workedMinutes":0,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":7,"inAmpm":"AM","status":"Weekly Off","shortfallHours":0,"inH":10},"staff_1":{"productsSold":0,"workedMinutes":540,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":8,"inAmpm":"AM","status":"Present","shortfallHours":0,"inH":11},"staff_2":{"productsSold":0,"workedMinutes":540,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":9,"inAmpm":"PM","status":"Present","shortfallHours":0,"inH":12}},"2026-07-29":{"staff_4":{"productsSold":0,"workedMinutes":540,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":6,"inAmpm":"AM","status":"Present","shortfallHours":0,"inH":9},"staff_7":{"productsSold":0,"workedMinutes":660,"otPay":100,"otHours":2,"servicesDone":0,"inM":0,"outM":0,"outH":9,"inAmpm":"AM","status":"Present","shortfallHours":0,"inH":10},"staff_8":{"productsSold":0,"workedMinutes":720,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":9,"inAmpm":"AM","status":"Present","shortfallHours":0,"inH":9},"staff_5":{"productsSold":0,"workedMinutes":540,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":8,"inAmpm":"AM","status":"Present","shortfallHours":0,"inH":11},"staff_6":{"productsSold":0,"workedMinutes":0,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":7,"inAmpm":"AM","status":"Weekly Off","shortfallHours":0,"inH":10},"staff_3":{"otHours":0,"outH":7,"shortfallHours":0,"inAmpm":"AM","outM":0,"workedMinutes":0,"inH":10,"inM":0,"status":"Leave","servicesDone":0,"weekendCut":false,"productsSold":0,"otPay":0},"staff_1":{"productsSold":0,"workedMinutes":540,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":6,"inAmpm":"AM","status":"Present","shortfallHours":0,"inH":9},"staff_2":{"productsSold":0,"workedMinutes":600,"otPay":50,"otHours":1,"servicesDone":0,"inM":0,"outM":0,"outH":9,"inAmpm":"AM","status":"Present","shortfallHours":0,"inH":11}},"2026-09-24":{"staff_4":{"productsSold":0,"workedMinutes":531,"otPay":0,"otHours":0,"servicesDone":0,"inM":12,"outM":3,"outH":9,"inAmpm":"PM","status":"Present","shortfallHours":0,"inH":12},"staff_7":{"productsSold":0,"workedMinutes":648,"otPay":100,"otHours":2,"servicesDone":0,"inM":12,"outM":0,"outH":9,"inAmpm":"AM","status":"Present","shortfallHours":0,"inH":10},"staff_8":{"productsSold":0,"workedMinutes":720,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":9,"inAmpm":"AM","status":"Present","shortfallHours":0,"inH":9},"staff_5":{"productsSold":0,"workedMinutes":0,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":7,"inAmpm":"AM","status":"Weekly Off","shortfallHours":0,"inH":10},"staff_6":{"productsSold":0,"workedMinutes":0,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":7,"inAmpm":"AM","status":"Weekly Off","shortfallHours":0,"inH":10},"staff_3":{"productsSold":0,"workedMinutes":0,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":7,"inAmpm":"AM","status":"Weekly Off","shortfallHours":0,"inH":10},"staff_1":{"productsSold":0,"workedMinutes":0,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":7,"inAmpm":"AM","status":"Weekly Off","shortfallHours":0,"inH":10},"staff_2":{"productsSold":0,"workedMinutes":715,"otPay":150,"otHours":3,"servicesDone":0,"inM":5,"outM":0,"outH":9,"inAmpm":"AM","status":"Present","shortfallHours":0,"inH":9}},"2026-06-29":{"staff_4":{"productsSold":0,"workedMinutes":600,"otPay":50,"otHours":1,"servicesDone":0,"inM":0,"outM":0,"outH":9,"inAmpm":"AM","status":"Present","shortfallHours":0,"inH":11},"staff_8":{"productsSold":0,"workedMinutes":720,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":9,"inAmpm":"AM","status":"Present","shortfallHours":0,"inH":9},"staff_5":{"productsSold":0,"workedMinutes":540,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":7,"inAmpm":"AM","status":"Present","shortfallHours":0,"inH":10},"staff_6":{"productsSold":0,"workedMinutes":0,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":7,"inAmpm":"AM","status":"Weekly Off","shortfallHours":0,"inH":10},"staff_3":{"productsSold":0,"workedMinutes":0,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":7,"inAmpm":"AM","status":"Weekly Off","shortfallHours":0,"inH":10},"staff_11":{"productsSold":0,"workedMinutes":600,"otPay":50,"otHours":1,"servicesDone":0,"inM":0,"outM":0,"outH":9,"inAmpm":"AM","status":"Present","shortfallHours":0,"inH":11},"staff_2":{"productsSold":0,"workedMinutes":600,"otPay":50,"otHours":1,"servicesDone":0,"inM":0,"outM":0,"outH":6,"inAmpm":"AM","status":"Present","shortfallHours":0,"inH":8},"staff_12":{"productsSold":0,"workedMinutes":540,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":6,"inAmpm":"AM","status":"Present","shortfallHours":0,"inH":9}},"2026-08-15":{"staff_4":{"productsSold":0,"workedMinutes":540,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":6,"inAmpm":"AM","status":"Present","shortfallHours":0,"inH":9},"staff_7":{"productsSold":0,"workedMinutes":540,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":7,"inAmpm":"AM","status":"Present","shortfallHours":0,"inH":10},"staff_8":{"productsSold":0,"workedMinutes":720,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":9,"inAmpm":"AM","status":"Present","shortfallHours":0,"inH":9},"staff_5":{"productsSold":0,"workedMinutes":540,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":8,"inAmpm":"AM","status":"Present","shortfallHours":0,"inH":11},"staff_6":{"productsSold":0,"workedMinutes":540,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":9,"inAmpm":"PM","status":"Present","shortfallHours":0,"inH":12},"staff_3":{"productsSold":0,"workedMinutes":540,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":9,"inAmpm":"PM","status":"Present","shortfallHours":0,"inH":12},"staff_1":{"productsSold":0,"workedMinutes":540,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":8,"inAmpm":"AM","status":"Present","shortfallHours":0,"inH":11},"staff_2":{"productsSold":0,"workedMinutes":540,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":7,"inAmpm":"AM","status":"Present","shortfallHours":0,"inH":10}},"2026-09-16":{"staff_4":{"productsSold":0,"workedMinutes":725,"otPay":150,"otHours":3,"servicesDone":0,"inM":55,"outM":0,"outH":9,"inAmpm":"AM","status":"Present","shortfallHours":0,"inH":8},"staff_7":{"productsSold":0,"workedMinutes":537,"otPay":0,"otHours":0,"servicesDone":0,"inM":4,"outM":1,"outH":7,"inAmpm":"AM","status":"Present","shortfallHours":0,"inH":10},"staff_8":{"productsSold":0,"workedMinutes":720,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":9,"inAmpm":"AM","status":"Present","shortfallHours":0,"inH":9},"staff_5":{"productsSold":0,"workedMinutes":0,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":7,"inAmpm":"AM","status":"Weekly Off","shortfallHours":0,"inH":10},"staff_6":{"productsSold":0,"workedMinutes":523,"otPay":0,"otHours":0,"servicesDone":0,"inM":18,"outM":1,"outH":9,"inAmpm":"PM","status":"Present","shortfallHours":0,"inH":12},"staff_3":{"productsSold":0,"workedMinutes":0,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":7,"inAmpm":"AM","status":"Weekly Off","shortfallHours":0,"inH":10},"staff_1":{"productsSold":0,"workedMinutes":0,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":7,"inAmpm":"AM","status":"Weekly Off","shortfallHours":0,"inH":10},"staff_2":{"productsSold":0,"workedMinutes":406,"otPay":0,"otHours":0,"servicesDone":0,"inM":14,"outM":0,"outH":9,"inAmpm":"PM","status":"Present","shortfallHours":2,"inH":2}},"2026-07-15":{"staff_7":{"productsSold":0,"workedMinutes":660,"otPay":100,"otHours":2,"servicesDone":0,"inM":0,"outM":0,"outH":9,"inAmpm":"AM","status":"Present","shortfallHours":0,"inH":10},"staff_8":{"productsSold":0,"workedMinutes":720,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":9,"inAmpm":"AM","status":"Present","shortfallHours":0,"inH":9},"staff_5":{"productsSold":0,"workedMinutes":540,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":8,"inAmpm":"AM","status":"Present","shortfallHours":0,"inH":11},"staff_6":{"productsSold":0,"workedMinutes":0,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":7,"inAmpm":"AM","status":"Weekly Off","shortfallHours":0,"inH":10},"staff_3":{"productsSold":0,"workedMinutes":540,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":9,"inAmpm":"PM","status":"Present","shortfallHours":0,"inH":12},"staff_1":{"productsSold":0,"workedMinutes":540,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":9,"inAmpm":"PM","status":"Present","shortfallHours":0,"inH":12},"staff_2":{"productsSold":0,"workedMinutes":540,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":7,"inAmpm":"AM","status":"Present","shortfallHours":0,"inH":10}},"2026-05-17":{"staff_4":{"productsSold":0,"workedMinutes":480,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":6,"inAmpm":"AM","status":"Present","shortfallHours":1,"inH":10},"staff_9":{"productsSold":0,"workedMinutes":540,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":6,"inAmpm":"AM","status":"Present","shortfallHours":0,"inH":9},"staff_8":{"productsSold":0,"workedMinutes":720,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":9,"inAmpm":"AM","status":"Present","shortfallHours":0,"inH":9},"staff_5":{"productsSold":0,"workedMinutes":480,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":6,"inAmpm":"AM","status":"Present","shortfallHours":1,"inH":10},"staff_6":{"productsSold":0,"workedMinutes":540,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":6,"inAmpm":"AM","status":"Present","shortfallHours":0,"inH":9},"staff_3":{"productsSold":0,"workedMinutes":540,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":9,"inAmpm":"PM","status":"Present","shortfallHours":0,"inH":12},"staff_11":{"productsSold":0,"workedMinutes":540,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":9,"inAmpm":"PM","status":"Present","shortfallHours":0,"inH":12},"staff_10":{"productsSold":0,"workedMinutes":540,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":9,"inAmpm":"PM","status":"Present","shortfallHours":0,"inH":12},"staff_2":{"productsSold":0,"workedMinutes":540,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":9,"inAmpm":"PM","status":"Present","shortfallHours":0,"inH":12},"staff_12":{"productsSold":0,"workedMinutes":540,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":6,"inAmpm":"AM","status":"Present","shortfallHours":0,"inH":9}},"2026-09-04":{"staff_4":{"productsSold":0,"workedMinutes":589,"otPay":50,"otHours":1,"servicesDone":0,"inM":11,"outM":0,"outH":9,"inAmpm":"AM","status":"Present","shortfallHours":0,"inH":11},"staff_7":{"productsSold":0,"workedMinutes":541,"otPay":0,"otHours":0,"servicesDone":0,"inM":59,"outM":0,"outH":9,"inAmpm":"AM","status":"Present","shortfallHours":0,"inH":11},"staff_8":{"productsSold":0,"workedMinutes":720,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":9,"inAmpm":"AM","status":"Present","shortfallHours":0,"inH":9},"staff_5":{"productsSold":0,"workedMinutes":0,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":7,"inAmpm":"AM","status":"Weekly Off","shortfallHours":0,"inH":10},"staff_6":{"productsSold":0,"workedMinutes":546,"otPay":0,"otHours":0,"servicesDone":0,"inM":54,"outM":0,"outH":7,"inAmpm":"AM","status":"Present","shortfallHours":0,"inH":9},"staff_3":{"productsSold":0,"workedMinutes":550,"otPay":0,"otHours":0,"servicesDone":0,"inM":50,"outM":0,"outH":6,"inAmpm":"AM","status":"Present","shortfallHours":0,"inH":8},"staff_1":{"productsSold":0,"workedMinutes":588,"otPay":50,"otHours":1,"servicesDone":0,"inM":25,"outM":13,"outH":9,"inAmpm":"AM","status":"Present","shortfallHours":0,"inH":11},"staff_2":{"productsSold":0,"workedMinutes":537,"otPay":0,"otHours":0,"servicesDone":0,"inM":8,"outM":5,"outH":9,"inAmpm":"PM","status":"Present","shortfallHours":0,"inH":12}},"2026-07-04":{"staff_4":{"productsSold":0,"workedMinutes":600,"otPay":50,"otHours":1,"servicesDone":0,"inM":0,"outM":0,"outH":6,"inAmpm":"AM","status":"Present","shortfallHours":0,"inH":8},"staff_8":{"productsSold":0,"workedMinutes":720,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":9,"inAmpm":"AM","status":"Present","shortfallHours":0,"inH":9},"staff_5":{"productsSold":0,"workedMinutes":540,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":8,"inAmpm":"AM","status":"Present","shortfallHours":0,"inH":11},"staff_6":{"productsSold":0,"workedMinutes":660,"otPay":100,"otHours":2,"servicesDone":0,"inM":0,"outM":0,"outH":9,"inAmpm":"AM","status":"Present","shortfallHours":0,"inH":10},"staff_3":{"productsSold":0,"workedMinutes":540,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":7,"inAmpm":"AM","status":"Present","shortfallHours":0,"inH":10},"staff_2":{"productsSold":0,"workedMinutes":540,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":9,"inAmpm":"PM","status":"Present","shortfallHours":0,"inH":12}},"2026-06-17":{"staff_4":{"productsSold":0,"workedMinutes":540,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":6,"inAmpm":"AM","status":"Present","shortfallHours":0,"inH":9},"staff_8":{"productsSold":0,"workedMinutes":720,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":9,"inAmpm":"AM","status":"Present","shortfallHours":0,"inH":9},"staff_5":{"productsSold":0,"workedMinutes":540,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":8,"inAmpm":"AM","status":"Present","shortfallHours":0,"inH":11},"staff_6":{"productsSold":0,"workedMinutes":540,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":6,"inAmpm":"AM","status":"Present","shortfallHours":0,"inH":9},"staff_3":{"productsSold":0,"workedMinutes":540,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":9,"inAmpm":"PM","status":"Present","shortfallHours":0,"inH":12},"staff_11":{"productsSold":0,"workedMinutes":540,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":9,"inAmpm":"PM","status":"Present","shortfallHours":0,"inH":12},"staff_2":{"productsSold":0,"workedMinutes":540,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":9,"inAmpm":"PM","status":"Present","shortfallHours":0,"inH":12},"staff_12":{"productsSold":0,"workedMinutes":540,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":9,"inAmpm":"PM","status":"Present","shortfallHours":0,"inH":12}},"2026-05-23":{"staff_4":{"productsSold":0,"workedMinutes":540,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":6,"inAmpm":"AM","status":"Present","shortfallHours":0,"inH":9},"staff_9":{"productsSold":0,"workedMinutes":540,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":9,"inAmpm":"PM","status":"Present","shortfallHours":0,"inH":12},"staff_8":{"productsSold":0,"workedMinutes":720,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":9,"inAmpm":"AM","status":"Present","shortfallHours":0,"inH":9},"staff_5":{"productsSold":0,"workedMinutes":540,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":7,"inAmpm":"AM","status":"Present","shortfallHours":0,"inH":10},"staff_6":{"productsSold":0,"workedMinutes":540,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":6,"inAmpm":"AM","status":"Present","shortfallHours":0,"inH":9},"staff_3":{"productsSold":0,"workedMinutes":540,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":9,"inAmpm":"PM","status":"Present","shortfallHours":0,"inH":12},"staff_11":{"productsSold":0,"workedMinutes":540,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":9,"inAmpm":"PM","status":"Present","shortfallHours":0,"inH":12},"staff_10":{"productsSold":0,"workedMinutes":540,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":9,"inAmpm":"PM","status":"Present","shortfallHours":0,"inH":12},"staff_2":{"productsSold":0,"workedMinutes":540,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":8,"inAmpm":"AM","status":"Present","shortfallHours":0,"inH":11},"staff_12":{"productsSold":0,"workedMinutes":540,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":9,"inAmpm":"PM","status":"Present","shortfallHours":0,"inH":12}},"2026-09-22":{"staff_4":{"productsSold":0,"workedMinutes":0,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":7,"inAmpm":"AM","status":"Weekly Off","shortfallHours":0,"inH":10},"staff_7":{"productsSold":0,"workedMinutes":551,"otPay":0,"otHours":0,"servicesDone":0,"inM":50,"outM":1,"outH":9,"inAmpm":"AM","status":"Present","shortfallHours":0,"inH":11},"staff_8":{"productsSold":0,"workedMinutes":720,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":9,"inAmpm":"AM","status":"Present","shortfallHours":0,"inH":9},"staff_5":{"productsSold":0,"workedMinutes":541,"otPay":0,"otHours":0,"servicesDone":0,"inM":1,"outM":2,"outH":7,"inAmpm":"AM","status":"Present","shortfallHours":0,"inH":10},"staff_6":{"productsSold":0,"workedMinutes":0,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":7,"inAmpm":"AM","status":"Weekly Off","shortfallHours":0,"inH":10},"staff_3":{"productsSold":0,"workedMinutes":0,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":7,"inAmpm":"AM","status":"Weekly Off","shortfallHours":0,"inH":10},"staff_1":{"productsSold":0,"workedMinutes":567,"otPay":0,"otHours":0,"servicesDone":0,"inM":2,"outM":29,"outH":9,"inAmpm":"PM","status":"Present","shortfallHours":0,"inH":12},"staff_2":{"productsSold":0,"workedMinutes":729,"otPay":150,"otHours":3,"servicesDone":0,"inM":0,"outM":9,"outH":9,"inAmpm":"AM","status":"Present","shortfallHours":0,"inH":9}},"2026-05-20":{"staff_4":{"productsSold":0,"workedMinutes":540,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":8,"inAmpm":"AM","status":"Present","shortfallHours":0,"inH":11},"staff_9":{"productsSold":0,"workedMinutes":0,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":7,"inAmpm":"AM","status":"Weekly Off","shortfallHours":0,"inH":10},"staff_8":{"productsSold":0,"workedMinutes":720,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":9,"inAmpm":"AM","status":"Present","shortfallHours":0,"inH":9},"staff_5":{"productsSold":0,"workedMinutes":540,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":6,"inAmpm":"AM","status":"Present","shortfallHours":0,"inH":9},"staff_6":{"productsSold":0,"workedMinutes":0,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":7,"inAmpm":"AM","status":"Weekly Off","shortfallHours":0,"inH":10},"staff_3":{"productsSold":0,"workedMinutes":540,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":6,"inAmpm":"AM","status":"Present","shortfallHours":0,"inH":9},"staff_11":{"productsSold":0,"workedMinutes":600,"otPay":50,"otHours":1,"servicesDone":0,"inM":0,"outM":0,"outH":9,"inAmpm":"AM","status":"Present","shortfallHours":0,"inH":11},"staff_10":{"productsSold":0,"workedMinutes":540,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":8,"inAmpm":"AM","status":"Present","shortfallHours":0,"inH":11},"staff_2":{"productsSold":0,"workedMinutes":540,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":9,"inAmpm":"PM","status":"Present","shortfallHours":0,"inH":12},"staff_12":{"productsSold":0,"workedMinutes":540,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":6,"inAmpm":"AM","status":"Present","shortfallHours":0,"inH":9}},"2026-08-12":{"staff_4":{"otHours":0,"outH":7,"shortfallHours":0,"inAmpm":"AM","outM":0,"workedMinutes":0,"inH":10,"inM":0,"status":"Leave","servicesDone":0,"weekendCut":false,"productsSold":0,"otPay":0},"staff_7":{"productsSold":0,"workedMinutes":540,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":7,"inAmpm":"AM","status":"Present","shortfallHours":0,"inH":10},"staff_8":{"productsSold":0,"workedMinutes":720,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":9,"inAmpm":"AM","status":"Present","shortfallHours":0,"inH":9},"staff_5":{"productsSold":0,"workedMinutes":540,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":8,"inAmpm":"AM","status":"Present","shortfallHours":0,"inH":11},"staff_6":{"productsSold":0,"workedMinutes":540,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":9,"inAmpm":"PM","status":"Present","shortfallHours":0,"inH":12},"staff_3":{"productsSold":0,"workedMinutes":540,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":9,"inAmpm":"PM","status":"Present","shortfallHours":0,"inH":12},"staff_1":{"productsSold":0,"workedMinutes":540,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":8,"inAmpm":"AM","status":"Present","shortfallHours":0,"inH":11},"staff_2":{"productsSold":0,"workedMinutes":540,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":6,"inAmpm":"AM","status":"Present","shortfallHours":0,"inH":9}},"2026-07-13":{"staff_4":{"productsSold":0,"workedMinutes":540,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":5,"inAmpm":"AM","status":"Present","shortfallHours":0,"inH":8},"staff_7":{"productsSold":0,"workedMinutes":540,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":7,"inAmpm":"AM","status":"Present","shortfallHours":0,"inH":10},"staff_8":{"productsSold":0,"workedMinutes":720,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":9,"inAmpm":"AM","status":"Present","shortfallHours":0,"inH":9},"staff_5":{"productsSold":0,"workedMinutes":540,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":8,"inAmpm":"AM","status":"Present","shortfallHours":0,"inH":11},"staff_6":{"productsSold":0,"workedMinutes":540,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":9,"inAmpm":"PM","status":"Present","shortfallHours":0,"inH":12},"staff_3":{"productsSold":0,"workedMinutes":540,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":9,"inAmpm":"PM","status":"Present","shortfallHours":0,"inH":12},"staff_1":{"productsSold":0,"workedMinutes":540,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":9,"inAmpm":"PM","status":"Present","shortfallHours":0,"inH":12},"staff_2":{"productsSold":0,"workedMinutes":540,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":7,"inAmpm":"AM","status":"Present","shortfallHours":0,"inH":10}},"2026-08-03":{"staff_4":{"productsSold":0,"workedMinutes":540,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":6,"inAmpm":"AM","status":"Present","shortfallHours":0,"inH":9},"staff_7":{"productsSold":0,"workedMinutes":0,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":7,"inAmpm":"AM","status":"Weekly Off","shortfallHours":0,"inH":10},"staff_8":{"productsSold":0,"workedMinutes":720,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":9,"inAmpm":"AM","status":"Present","shortfallHours":0,"inH":9},"staff_5":{"productsSold":0,"workedMinutes":540,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":8,"inAmpm":"AM","status":"Present","shortfallHours":0,"inH":11},"staff_6":{"productsSold":0,"workedMinutes":660,"otPay":100,"otHours":2,"servicesDone":0,"inM":0,"outM":0,"outH":9,"inAmpm":"AM","status":"Present","shortfallHours":0,"inH":10},"staff_3":{"productsSold":0,"workedMinutes":0,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":7,"inAmpm":"AM","status":"Weekly Off","shortfallHours":0,"inH":10},"staff_1":{"productsSold":0,"workedMinutes":540,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":9,"inAmpm":"PM","status":"Present","shortfallHours":0,"inH":12},"staff_2":{"productsSold":0,"workedMinutes":540,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":8,"inAmpm":"AM","status":"Present","shortfallHours":0,"inH":11}},"2026-09-12":{"staff_4":{"productsSold":0,"workedMinutes":0,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":7,"inAmpm":"AM","status":"Weekly Off","shortfallHours":0,"inH":10},"staff_7":{"productsSold":0,"workedMinutes":554,"otPay":0,"otHours":0,"servicesDone":0,"inM":46,"outM":0,"outH":7,"inAmpm":"AM","status":"Present","shortfallHours":0,"inH":9},"staff_8":{"productsSold":0,"workedMinutes":720,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":9,"inAmpm":"AM","status":"Present","shortfallHours":0,"inH":9},"staff_5":{"productsSold":0,"workedMinutes":539,"otPay":0,"otHours":0,"servicesDone":0,"inM":1,"outM":0,"outH":8,"inAmpm":"AM","status":"Present","shortfallHours":0,"inH":11},"staff_6":{"productsSold":0,"workedMinutes":559,"otPay":0,"otHours":0,"servicesDone":0,"inM":43,"outM":2,"outH":9,"inAmpm":"AM","status":"Present","shortfallHours":0,"inH":11},"staff_3":{"productsSold":0,"workedMinutes":0,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":7,"inAmpm":"AM","status":"Weekly Off","shortfallHours":0,"inH":10},"staff_1":{"productsSold":0,"workedMinutes":546,"otPay":0,"otHours":0,"servicesDone":0,"inM":56,"outM":2,"outH":9,"inAmpm":"AM","status":"Present","shortfallHours":0,"inH":11},"staff_2":{"productsSold":0,"workedMinutes":0,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":7,"inAmpm":"AM","status":"Weekly Off","shortfallHours":0,"inH":10}},"2026-06-27":{"staff_4":{"productsSold":0,"workedMinutes":540,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":5,"inAmpm":"AM","status":"Present","shortfallHours":0,"inH":8},"staff_8":{"productsSold":0,"workedMinutes":720,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":9,"inAmpm":"AM","status":"Present","shortfallHours":0,"inH":9},"staff_5":{"productsSold":0,"workedMinutes":540,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":8,"inAmpm":"AM","status":"Present","shortfallHours":0,"inH":11},"staff_6":{"productsSold":0,"workedMinutes":540,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":9,"inAmpm":"PM","status":"Present","shortfallHours":0,"inH":12},"staff_3":{"productsSold":0,"workedMinutes":540,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":7,"inAmpm":"AM","status":"Present","shortfallHours":0,"inH":10},"staff_11":{"productsSold":0,"workedMinutes":540,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":7,"inAmpm":"AM","status":"Present","shortfallHours":0,"inH":10},"staff_2":{"productsSold":0,"workedMinutes":540,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":9,"inAmpm":"PM","status":"Present","shortfallHours":0,"inH":12},"staff_12":{"productsSold":0,"workedMinutes":540,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":6,"inAmpm":"AM","status":"Present","shortfallHours":0,"inH":9}},"2026-06-28":{"staff_4":{"productsSold":0,"workedMinutes":540,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":5,"inAmpm":"AM","status":"Present","shortfallHours":0,"inH":8},"staff_8":{"productsSold":0,"workedMinutes":720,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":9,"inAmpm":"AM","status":"Present","shortfallHours":0,"inH":9},"staff_5":{"productsSold":0,"workedMinutes":540,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":7,"inAmpm":"AM","status":"Present","shortfallHours":0,"inH":10},"staff_6":{"productsSold":0,"workedMinutes":540,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":9,"inAmpm":"PM","status":"Present","shortfallHours":0,"inH":12},"staff_3":{"productsSold":0,"workedMinutes":540,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":7,"inAmpm":"AM","status":"Present","shortfallHours":0,"inH":10},"staff_11":{"productsSold":0,"workedMinutes":540,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":6,"inAmpm":"AM","status":"Present","shortfallHours":0,"inH":9},"staff_2":{"productsSold":0,"workedMinutes":540,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":9,"inAmpm":"PM","status":"Present","shortfallHours":0,"inH":12},"staff_12":{"productsSold":0,"workedMinutes":540,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":6,"inAmpm":"AM","status":"Present","shortfallHours":0,"inH":9}},"2026-08-16":{"staff_4":{"productsSold":0,"workedMinutes":540,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":6,"inAmpm":"AM","status":"Present","shortfallHours":0,"inH":9},"staff_7":{"productsSold":0,"workedMinutes":540,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":7,"inAmpm":"AM","status":"Present","shortfallHours":0,"inH":10},"staff_8":{"productsSold":0,"workedMinutes":720,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":9,"inAmpm":"AM","status":"Present","shortfallHours":0,"inH":9},"staff_5":{"productsSold":0,"workedMinutes":540,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":8,"inAmpm":"AM","status":"Present","shortfallHours":0,"inH":11},"staff_6":{"productsSold":0,"workedMinutes":540,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":9,"inAmpm":"PM","status":"Present","shortfallHours":0,"inH":12},"staff_3":{"productsSold":0,"workedMinutes":540,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":9,"inAmpm":"PM","status":"Present","shortfallHours":0,"inH":12},"staff_1":{"productsSold":0,"workedMinutes":540,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":8,"inAmpm":"AM","status":"Present","shortfallHours":0,"inH":11},"staff_2":{"productsSold":0,"workedMinutes":540,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":7,"inAmpm":"AM","status":"Present","shortfallHours":0,"inH":10}},"2026-05-10":{"staff_4":{"productsSold":0,"workedMinutes":540,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":9,"inAmpm":"PM","status":"Present","shortfallHours":0,"inH":12},"staff_9":{"productsSold":0,"workedMinutes":480,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":6,"inAmpm":"AM","status":"Present","shortfallHours":1,"inH":10},"staff_8":{"productsSold":0,"workedMinutes":720,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":9,"inAmpm":"AM","status":"Present","shortfallHours":0,"inH":9},"staff_5":{"productsSold":0,"workedMinutes":540,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":9,"inAmpm":"PM","status":"Present","shortfallHours":0,"inH":12},"staff_6":{"productsSold":0,"workedMinutes":540,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":8,"inAmpm":"AM","status":"Present","shortfallHours":0,"inH":11},"staff_3":{"productsSold":0,"workedMinutes":540,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":6,"inAmpm":"AM","status":"Present","shortfallHours":0,"inH":9},"staff_11":{"productsSold":0,"workedMinutes":540,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":7,"inAmpm":"AM","status":"Present","shortfallHours":0,"inH":10},"staff_10":{"productsSold":0,"workedMinutes":540,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":6,"inAmpm":"AM","status":"Present","shortfallHours":0,"inH":9},"staff_2":{"productsSold":0,"workedMinutes":540,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":8,"inAmpm":"AM","status":"Present","shortfallHours":0,"inH":11},"staff_12":{"otHours":0,"outH":7,"shortfallHours":0,"inAmpm":"AM","outM":0,"workedMinutes":0,"inH":10,"inM":0,"status":"Leave","servicesDone":0,"weekendCut":true,"productsSold":0,"otPay":0},"staff_13":{"productsSold":0,"workedMinutes":600,"otPay":50,"otHours":1,"servicesDone":0,"inM":0,"outM":0,"outH":7,"inAmpm":"AM","status":"Present","shortfallHours":0,"inH":9}},"2026-08-23":{"staff_4":{"productsSold":0,"workedMinutes":540,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":6,"inAmpm":"AM","status":"Present","shortfallHours":0,"inH":9},"staff_7":{"productsSold":0,"workedMinutes":540,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":7,"inAmpm":"AM","status":"Present","shortfallHours":0,"inH":10},"staff_8":{"productsSold":0,"workedMinutes":720,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":9,"inAmpm":"AM","status":"Present","shortfallHours":0,"inH":9},"staff_5":{"productsSold":0,"workedMinutes":540,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":8,"inAmpm":"AM","status":"Present","shortfallHours":0,"inH":11},"staff_6":{"productsSold":0,"workedMinutes":540,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":9,"inAmpm":"PM","status":"Present","shortfallHours":0,"inH":12},"staff_3":{"productsSold":0,"workedMinutes":540,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":9,"inAmpm":"PM","status":"Present","shortfallHours":0,"inH":12},"staff_1":{"productsSold":0,"workedMinutes":540,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":8,"inAmpm":"AM","status":"Present","shortfallHours":0,"inH":11},"staff_2":{"productsSold":0,"workedMinutes":540,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":7,"inAmpm":"AM","status":"Present","shortfallHours":0,"inH":10}},"2026-08-11":{"staff_4":{"otHours":0,"outH":7,"shortfallHours":0,"inAmpm":"AM","outM":0,"workedMinutes":0,"inH":10,"inM":0,"status":"Leave","servicesDone":0,"weekendCut":false,"productsSold":0,"otPay":0},"staff_7":{"productsSold":0,"workedMinutes":540,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":7,"inAmpm":"AM","status":"Present","shortfallHours":0,"inH":10},"staff_8":{"productsSold":0,"workedMinutes":720,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":9,"inAmpm":"AM","status":"Present","shortfallHours":0,"inH":9},"staff_5":{"productsSold":0,"workedMinutes":540,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":8,"inAmpm":"AM","status":"Present","shortfallHours":0,"inH":11},"staff_6":{"productsSold":0,"workedMinutes":0,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":7,"inAmpm":"AM","status":"Weekly Off","shortfallHours":0,"inH":10},"staff_3":{"productsSold":0,"workedMinutes":540,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":9,"inAmpm":"PM","status":"Present","shortfallHours":0,"inH":12},"staff_1":{"productsSold":0,"workedMinutes":540,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":6,"inAmpm":"AM","status":"Present","shortfallHours":0,"inH":9},"staff_2":{"productsSold":0,"workedMinutes":540,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":6,"inAmpm":"AM","status":"Present","shortfallHours":0,"inH":9}},"2026-05-12":{"staff_4":{"productsSold":0,"workedMinutes":540,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":9,"inAmpm":"PM","status":"Present","shortfallHours":0,"inH":12},"staff_9":{"productsSold":0,"workedMinutes":540,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":6,"inAmpm":"AM","status":"Present","shortfallHours":0,"inH":9},"staff_8":{"productsSold":0,"workedMinutes":720,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":9,"inAmpm":"AM","status":"Present","shortfallHours":0,"inH":9},"staff_5":{"productsSold":0,"workedMinutes":540,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":6,"inAmpm":"AM","status":"Present","shortfallHours":0,"inH":9},"staff_6":{"productsSold":0,"workedMinutes":600,"otPay":50,"otHours":1,"servicesDone":0,"inM":0,"outM":0,"outH":9,"inAmpm":"AM","status":"Present","shortfallHours":0,"inH":11},"staff_3":{"productsSold":0,"workedMinutes":540,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":8,"inAmpm":"AM","status":"Present","shortfallHours":0,"inH":11},"staff_11":{"productsSold":0,"workedMinutes":0,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":7,"inAmpm":"AM","status":"Weekly Off","shortfallHours":0,"inH":10},"staff_10":{"productsSold":0,"workedMinutes":540,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":7,"inAmpm":"AM","status":"Present","shortfallHours":0,"inH":10},"staff_2":{"productsSold":0,"workedMinutes":540,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":7,"inAmpm":"AM","status":"Present","shortfallHours":0,"inH":10},"staff_12":{"productsSold":0,"workedMinutes":540,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":9,"inAmpm":"PM","status":"Present","shortfallHours":0,"inH":12},"staff_13":{"otHours":0,"outH":7,"shortfallHours":0,"inAmpm":"AM","outM":0,"workedMinutes":0,"inH":10,"inM":0,"status":"Leave","servicesDone":0,"weekendCut":false,"productsSold":0,"otPay":0}},"2026-08-04":{"staff_4":{"otHours":0,"outH":7,"shortfallHours":0,"inAmpm":"AM","outM":0,"workedMinutes":0,"inH":10,"inM":0,"status":"Leave","servicesDone":0,"weekendCut":false,"productsSold":0,"otPay":0},"staff_7":{"productsSold":0,"workedMinutes":540,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":9,"inAmpm":"PM","status":"Present","shortfallHours":0,"inH":12},"staff_8":{"productsSold":0,"workedMinutes":720,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":9,"inAmpm":"AM","status":"Present","shortfallHours":0,"inH":9},"staff_5":{"productsSold":0,"workedMinutes":540,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":8,"inAmpm":"AM","status":"Present","shortfallHours":0,"inH":11},"staff_6":{"productsSold":0,"workedMinutes":540,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":7,"inAmpm":"AM","status":"Present","shortfallHours":0,"inH":10},"staff_3":{"productsSold":0,"workedMinutes":540,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":6,"inAmpm":"AM","status":"Present","shortfallHours":0,"inH":9},"staff_1":{"productsSold":0,"workedMinutes":540,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":9,"inAmpm":"PM","status":"Present","shortfallHours":0,"inH":12},"staff_2":{"productsSold":0,"workedMinutes":540,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":9,"inAmpm":"PM","status":"Present","shortfallHours":0,"inH":12}},"2026-08-26":{"staff_4":{"productsSold":0,"workedMinutes":540,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":7,"inAmpm":"AM","status":"Present","shortfallHours":0,"inH":10},"staff_7":{"productsSold":0,"workedMinutes":660,"otPay":100,"otHours":2,"servicesDone":0,"inM":0,"outM":0,"outH":9,"inAmpm":"AM","status":"Present","shortfallHours":0,"inH":10},"staff_8":{"productsSold":0,"workedMinutes":720,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":9,"inAmpm":"AM","status":"Present","shortfallHours":0,"inH":9},"staff_5":{"productsSold":0,"workedMinutes":0,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":7,"inAmpm":"AM","status":"Weekly Off","shortfallHours":0,"inH":10},"staff_6":{"productsSold":0,"workedMinutes":0,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":7,"inAmpm":"AM","status":"Weekly Off","shortfallHours":0,"inH":10},"staff_3":{"productsSold":0,"workedMinutes":540,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":6,"inAmpm":"AM","status":"Present","shortfallHours":0,"inH":9},"staff_1":{"productsSold":0,"workedMinutes":540,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":8,"inAmpm":"AM","status":"Present","shortfallHours":0,"inH":11},"staff_2":{"productsSold":0,"workedMinutes":540,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":9,"inAmpm":"PM","status":"Present","shortfallHours":0,"inH":12}},"2026-08-27":{"staff_4":{"productsSold":0,"workedMinutes":540,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":9,"inAmpm":"PM","status":"Present","shortfallHours":0,"inH":12},"staff_7":{"productsSold":0,"workedMinutes":540,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":9,"inAmpm":"PM","status":"Present","shortfallHours":0,"inH":12},"staff_8":{"productsSold":0,"workedMinutes":720,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":9,"inAmpm":"AM","status":"Present","shortfallHours":0,"inH":9},"staff_5":{"productsSold":0,"workedMinutes":540,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":8,"inAmpm":"AM","status":"Present","shortfallHours":0,"inH":11},"staff_6":{"productsSold":0,"workedMinutes":540,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":7,"inAmpm":"AM","status":"Present","shortfallHours":0,"inH":10},"staff_3":{"productsSold":0,"workedMinutes":540,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":6,"inAmpm":"AM","status":"Present","shortfallHours":0,"inH":9},"staff_1":{"productsSold":0,"workedMinutes":540,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":8,"inAmpm":"AM","status":"Present","shortfallHours":0,"inH":11},"staff_2":{"productsSold":0,"workedMinutes":540,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":8,"inAmpm":"AM","status":"Present","shortfallHours":0,"inH":11}},"2026-06-20":{"staff_4":{"productsSold":0,"workedMinutes":540,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":6,"inAmpm":"AM","status":"Present","shortfallHours":0,"inH":9},"staff_8":{"productsSold":0,"workedMinutes":720,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":9,"inAmpm":"AM","status":"Present","shortfallHours":0,"inH":9},"staff_5":{"productsSold":0,"workedMinutes":540,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":8,"inAmpm":"AM","status":"Present","shortfallHours":0,"inH":11},"staff_6":{"productsSold":0,"workedMinutes":540,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":9,"inAmpm":"PM","status":"Present","shortfallHours":0,"inH":12},"staff_3":{"productsSold":0,"workedMinutes":540,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":7,"inAmpm":"AM","status":"Present","shortfallHours":0,"inH":10},"staff_11":{"productsSold":0,"workedMinutes":540,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":6,"inAmpm":"AM","status":"Present","shortfallHours":0,"inH":9},"staff_2":{"productsSold":0,"workedMinutes":540,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":9,"inAmpm":"PM","status":"Present","shortfallHours":0,"inH":12},"staff_12":{"productsSold":0,"workedMinutes":540,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":6,"inAmpm":"AM","status":"Present","shortfallHours":0,"inH":9}},"2026-05-18":{"staff_4":{"productsSold":0,"workedMinutes":540,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":8,"inAmpm":"AM","status":"Present","shortfallHours":0,"inH":11},"staff_9":{"productsSold":0,"workedMinutes":540,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":6,"inAmpm":"AM","status":"Present","shortfallHours":0,"inH":9},"staff_8":{"productsSold":0,"workedMinutes":720,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":9,"inAmpm":"AM","status":"Present","shortfallHours":0,"inH":9},"staff_5":{"productsSold":0,"workedMinutes":0,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":7,"inAmpm":"AM","status":"Weekly Off","shortfallHours":0,"inH":10},"staff_6":{"productsSold":0,"workedMinutes":540,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":6,"inAmpm":"AM","status":"Present","shortfallHours":0,"inH":9},"staff_3":{"productsSold":0,"workedMinutes":540,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":9,"inAmpm":"PM","status":"Present","shortfallHours":0,"inH":12},"staff_11":{"productsSold":0,"workedMinutes":540,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":9,"inAmpm":"PM","status":"Present","shortfallHours":0,"inH":12},"staff_10":{"productsSold":0,"workedMinutes":540,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":8,"inAmpm":"AM","status":"Present","shortfallHours":0,"inH":11},"staff_2":{"productsSold":0,"workedMinutes":540,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":7,"inAmpm":"AM","status":"Present","shortfallHours":0,"inH":10},"staff_12":{"productsSold":0,"workedMinutes":540,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":6,"inAmpm":"AM","status":"Present","shortfallHours":0,"inH":9}},"2026-06-03":{"staff_4":{"productsSold":0,"workedMinutes":540,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":7,"inAmpm":"AM","status":"Present","shortfallHours":0,"inH":10},"staff_9":{"productsSold":0,"workedMinutes":540,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":6,"inAmpm":"AM","status":"Present","shortfallHours":0,"inH":9},"staff_8":{"productsSold":0,"workedMinutes":720,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":9,"inAmpm":"AM","status":"Present","shortfallHours":0,"inH":9},"staff_5":{"productsSold":0,"workedMinutes":540,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":6,"inAmpm":"AM","status":"Present","shortfallHours":0,"inH":9},"staff_6":{"productsSold":0,"workedMinutes":540,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":9,"inAmpm":"PM","status":"Present","shortfallHours":0,"inH":12},"staff_3":{"productsSold":0,"workedMinutes":540,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":9,"inAmpm":"PM","status":"Present","shortfallHours":0,"inH":12},"staff_11":{"productsSold":0,"workedMinutes":540,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":8,"inAmpm":"AM","status":"Present","shortfallHours":0,"inH":11},"staff_10":{"productsSold":0,"workedMinutes":0,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":7,"inAmpm":"AM","status":"Weekly Off","shortfallHours":0,"inH":10},"staff_2":{"productsSold":0,"workedMinutes":540,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":9,"inAmpm":"PM","status":"Present","shortfallHours":0,"inH":12}},"2026-05-08":{"staff_4":{"productsSold":0,"workedMinutes":540,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":8,"inAmpm":"AM","status":"Present","shortfallHours":0,"inH":11},"staff_9":{"productsSold":0,"workedMinutes":540,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":6,"inAmpm":"AM","status":"Present","shortfallHours":0,"inH":9},"staff_8":{"productsSold":0,"workedMinutes":720,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":9,"inAmpm":"AM","status":"Present","shortfallHours":0,"inH":9},"staff_5":{"productsSold":0,"workedMinutes":540,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":8,"inAmpm":"AM","status":"Present","shortfallHours":0,"inH":11},"staff_6":{"productsSold":0,"workedMinutes":540,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":9,"inAmpm":"PM","status":"Present","shortfallHours":0,"inH":12},"staff_3":{"productsSold":0,"workedMinutes":540,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":9,"inAmpm":"PM","status":"Present","shortfallHours":0,"inH":12},"staff_11":{"productsSold":0,"workedMinutes":540,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":6,"inAmpm":"AM","status":"Present","shortfallHours":0,"inH":9},"staff_10":{"productsSold":0,"workedMinutes":540,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":9,"inAmpm":"PM","status":"Present","shortfallHours":0,"inH":12},"staff_2":{"productsSold":0,"workedMinutes":540,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":9,"inAmpm":"PM","status":"Present","shortfallHours":0,"inH":12},"staff_12":{"otHours":0,"outH":7,"shortfallHours":0,"inAmpm":"AM","outM":0,"workedMinutes":0,"inH":10,"inM":0,"status":"Leave","servicesDone":0,"weekendCut":false,"productsSold":0,"otPay":0},"staff_13":{"productsSold":0,"workedMinutes":600,"otPay":50,"otHours":1,"servicesDone":0,"inM":0,"outM":0,"outH":7,"inAmpm":"AM","status":"Present","shortfallHours":0,"inH":9}},"2026-05-27":{"staff_4":{"productsSold":0,"workedMinutes":540,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":6,"inAmpm":"AM","status":"Present","shortfallHours":0,"inH":9},"staff_9":{"productsSold":0,"workedMinutes":540,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":9,"inAmpm":"PM","status":"Present","shortfallHours":0,"inH":12},"staff_8":{"productsSold":0,"workedMinutes":720,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":9,"inAmpm":"AM","status":"Present","shortfallHours":0,"inH":9},"staff_5":{"productsSold":0,"workedMinutes":0,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":7,"inAmpm":"AM","status":"Weekly Off","shortfallHours":0,"inH":10},"staff_6":{"productsSold":0,"workedMinutes":0,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":7,"inAmpm":"AM","status":"Weekly Off","shortfallHours":0,"inH":10},"staff_3":{"productsSold":0,"workedMinutes":540,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":8,"inAmpm":"AM","status":"Present","shortfallHours":0,"inH":11},"staff_11":{"productsSold":0,"workedMinutes":720,"otPay":150,"otHours":3,"servicesDone":0,"inM":0,"outM":0,"outH":9,"inAmpm":"AM","status":"Present","shortfallHours":0,"inH":9},"staff_10":{"productsSold":0,"workedMinutes":720,"otPay":150,"otHours":3,"servicesDone":0,"inM":0,"outM":0,"outH":9,"inAmpm":"AM","status":"Present","shortfallHours":0,"inH":9},"staff_2":{"productsSold":0,"workedMinutes":0,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":7,"inAmpm":"AM","status":"Weekly Off","shortfallHours":0,"inH":10},"staff_12":{"productsSold":0,"workedMinutes":540,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":9,"inAmpm":"PM","status":"Present","shortfallHours":0,"inH":12}},"2026-07-21":{"staff_4":{"productsSold":0,"workedMinutes":540,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":6,"inAmpm":"AM","status":"Present","shortfallHours":0,"inH":9},"staff_7":{"productsSold":0,"workedMinutes":660,"otPay":100,"otHours":2,"servicesDone":0,"inM":0,"outM":0,"outH":9,"inAmpm":"AM","status":"Present","shortfallHours":0,"inH":10},"staff_8":{"productsSold":0,"workedMinutes":720,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":9,"inAmpm":"AM","status":"Present","shortfallHours":0,"inH":9},"staff_5":{"productsSold":0,"workedMinutes":540,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":8,"inAmpm":"AM","status":"Present","shortfallHours":0,"inH":11},"staff_6":{"productsSold":0,"workedMinutes":0,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":7,"inAmpm":"AM","status":"Weekly Off","shortfallHours":0,"inH":10},"staff_3":{"otHours":0,"outH":7,"shortfallHours":0,"inAmpm":"AM","outM":0,"workedMinutes":0,"inH":10,"inM":0,"status":"Leave","servicesDone":0,"weekendCut":false,"productsSold":0,"otPay":0},"staff_1":{"productsSold":0,"workedMinutes":540,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":9,"inAmpm":"PM","status":"Present","shortfallHours":0,"inH":12},"staff_2":{"productsSold":0,"workedMinutes":600,"otPay":50,"otHours":1,"servicesDone":0,"inM":0,"outM":0,"outH":9,"inAmpm":"AM","status":"Present","shortfallHours":0,"inH":11}},"2026-06-10":{"staff_4":{"productsSold":0,"workedMinutes":540,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":6,"inAmpm":"AM","status":"Present","shortfallHours":0,"inH":9},"staff_9":{"productsSold":0,"workedMinutes":540,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":6,"inAmpm":"AM","status":"Present","shortfallHours":0,"inH":9},"staff_8":{"productsSold":0,"workedMinutes":720,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":9,"inAmpm":"AM","status":"Present","shortfallHours":0,"inH":9},"staff_5":{"productsSold":0,"workedMinutes":540,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":8,"inAmpm":"AM","status":"Present","shortfallHours":0,"inH":11},"staff_6":{"productsSold":0,"workedMinutes":540,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":9,"inAmpm":"PM","status":"Present","shortfallHours":0,"inH":12},"staff_3":{"productsSold":0,"workedMinutes":540,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":9,"inAmpm":"PM","status":"Present","shortfallHours":0,"inH":12},"staff_11":{"productsSold":0,"workedMinutes":540,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":6,"inAmpm":"AM","status":"Present","shortfallHours":0,"inH":9},"staff_10":{"productsSold":0,"workedMinutes":0,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":7,"inAmpm":"AM","status":"Weekly Off","shortfallHours":0,"inH":10},"staff_2":{"productsSold":0,"workedMinutes":540,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":9,"inAmpm":"PM","status":"Present","shortfallHours":0,"inH":12},"staff_12":{"productsSold":0,"workedMinutes":540,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":6,"inAmpm":"AM","status":"Present","shortfallHours":0,"inH":9}},"2026-05-24":{"staff_4":{"productsSold":0,"workedMinutes":540,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":6,"inAmpm":"AM","status":"Present","shortfallHours":0,"inH":9},"staff_9":{"productsSold":0,"workedMinutes":540,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":9,"inAmpm":"PM","status":"Present","shortfallHours":0,"inH":12},"staff_8":{"productsSold":0,"workedMinutes":720,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":9,"inAmpm":"AM","status":"Present","shortfallHours":0,"inH":9},"staff_5":{"productsSold":0,"workedMinutes":540,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":9,"inAmpm":"PM","status":"Present","shortfallHours":0,"inH":12},"staff_6":{"productsSold":0,"workedMinutes":540,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":6,"inAmpm":"AM","status":"Present","shortfallHours":0,"inH":9},"staff_3":{"productsSold":0,"workedMinutes":540,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":9,"inAmpm":"PM","status":"Present","shortfallHours":0,"inH":12},"staff_11":{"productsSold":0,"workedMinutes":480,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":9,"inAmpm":"PM","status":"Present","shortfallHours":1,"inH":1},"staff_10":{"productsSold":0,"workedMinutes":540,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":6,"inAmpm":"AM","status":"Present","shortfallHours":0,"inH":9},"staff_2":{"productsSold":0,"workedMinutes":540,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":8,"inAmpm":"AM","status":"Present","shortfallHours":0,"inH":11},"staff_12":{"productsSold":0,"workedMinutes":540,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":6,"inAmpm":"AM","status":"Present","shortfallHours":0,"inH":9}},"2026-08-17":{"staff_4":{"productsSold":0,"workedMinutes":540,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":6,"inAmpm":"AM","status":"Present","shortfallHours":0,"inH":9},"staff_7":{"productsSold":0,"workedMinutes":540,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":7,"inAmpm":"AM","status":"Present","shortfallHours":0,"inH":10},"staff_8":{"productsSold":0,"workedMinutes":720,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":9,"inAmpm":"AM","status":"Present","shortfallHours":0,"inH":9},"staff_5":{"productsSold":0,"workedMinutes":540,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":7,"inAmpm":"AM","status":"Present","shortfallHours":0,"inH":10},"staff_6":{"productsSold":0,"workedMinutes":540,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":9,"inAmpm":"PM","status":"Present","shortfallHours":0,"inH":12},"staff_3":{"productsSold":0,"workedMinutes":540,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":9,"inAmpm":"PM","status":"Present","shortfallHours":0,"inH":12},"staff_1":{"productsSold":0,"workedMinutes":540,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":8,"inAmpm":"AM","status":"Present","shortfallHours":0,"inH":11},"staff_2":{"productsSold":0,"workedMinutes":540,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":7,"inAmpm":"AM","status":"Present","shortfallHours":0,"inH":10}},"2026-06-22":{"staff_4":{"productsSold":0,"workedMinutes":540,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":6,"inAmpm":"AM","status":"Present","shortfallHours":0,"inH":9},"staff_8":{"productsSold":0,"workedMinutes":720,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":9,"inAmpm":"AM","status":"Present","shortfallHours":0,"inH":9},"staff_5":{"productsSold":0,"workedMinutes":540,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":6,"inAmpm":"AM","status":"Present","shortfallHours":0,"inH":9},"staff_6":{"productsSold":0,"workedMinutes":0,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":7,"inAmpm":"AM","status":"Weekly Off","shortfallHours":0,"inH":10},"staff_3":{"productsSold":0,"workedMinutes":540,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":7,"inAmpm":"AM","status":"Present","shortfallHours":0,"inH":10},"staff_11":{"productsSold":0,"workedMinutes":600,"otPay":50,"otHours":1,"servicesDone":0,"inM":0,"outM":0,"outH":9,"inAmpm":"AM","status":"Present","shortfallHours":0,"inH":11},"staff_2":{"productsSold":0,"workedMinutes":540,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":9,"inAmpm":"PM","status":"Present","shortfallHours":0,"inH":12},"staff_12":{"productsSold":0,"workedMinutes":0,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":7,"inAmpm":"AM","status":"Weekly Off","shortfallHours":0,"inH":10}},"2026-06-21":{"staff_4":{"productsSold":0,"workedMinutes":540,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":6,"inAmpm":"AM","status":"Present","shortfallHours":0,"inH":9},"staff_8":{"productsSold":0,"workedMinutes":720,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":9,"inAmpm":"AM","status":"Present","shortfallHours":0,"inH":9},"staff_5":{"productsSold":0,"workedMinutes":540,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":8,"inAmpm":"AM","status":"Present","shortfallHours":0,"inH":11},"staff_6":{"productsSold":0,"workedMinutes":540,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":6,"inAmpm":"AM","status":"Present","shortfallHours":0,"inH":9},"staff_3":{"productsSold":0,"workedMinutes":540,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":7,"inAmpm":"AM","status":"Present","shortfallHours":0,"inH":10},"staff_11":{"productsSold":0,"workedMinutes":480,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":9,"inAmpm":"PM","status":"Present","shortfallHours":1,"inH":1},"staff_2":{"productsSold":0,"workedMinutes":540,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":9,"inAmpm":"PM","status":"Present","shortfallHours":0,"inH":12},"staff_12":{"productsSold":0,"workedMinutes":540,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":6,"inAmpm":"AM","status":"Present","shortfallHours":0,"inH":9}},"2026-07-24":{"staff_4":{"productsSold":0,"workedMinutes":540,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":6,"inAmpm":"AM","status":"Present","shortfallHours":0,"inH":9},"staff_7":{"productsSold":0,"workedMinutes":540,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":7,"inAmpm":"AM","status":"Present","shortfallHours":0,"inH":10},"staff_8":{"productsSold":0,"workedMinutes":720,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":9,"inAmpm":"AM","status":"Present","shortfallHours":0,"inH":9},"staff_5":{"productsSold":0,"workedMinutes":0,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":7,"inAmpm":"AM","status":"Weekly Off","shortfallHours":0,"inH":10},"staff_6":{"productsSold":0,"workedMinutes":540,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":9,"inAmpm":"PM","status":"Present","shortfallHours":0,"inH":12},"staff_3":{"otHours":0,"outH":7,"shortfallHours":0,"inAmpm":"AM","outM":0,"workedMinutes":0,"inH":10,"inM":0,"status":"Leave","servicesDone":0,"weekendCut":false,"productsSold":0,"otPay":0},"staff_1":{"productsSold":0,"workedMinutes":540,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":6,"inAmpm":"AM","status":"Present","shortfallHours":0,"inH":9},"staff_2":{"productsSold":0,"workedMinutes":600,"otPay":50,"otHours":1,"servicesDone":0,"inM":0,"outM":0,"outH":9,"inAmpm":"AM","status":"Present","shortfallHours":0,"inH":11}},"2026-06-11":{"staff_4":{"productsSold":0,"workedMinutes":540,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":6,"inAmpm":"AM","status":"Present","shortfallHours":0,"inH":9},"staff_9":{"productsSold":0,"workedMinutes":540,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":6,"inAmpm":"AM","status":"Present","shortfallHours":0,"inH":9},"staff_8":{"productsSold":0,"workedMinutes":720,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":9,"inAmpm":"AM","status":"Present","shortfallHours":0,"inH":9},"staff_5":{"productsSold":0,"workedMinutes":540,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":8,"inAmpm":"AM","status":"Present","shortfallHours":0,"inH":11},"staff_6":{"productsSold":0,"workedMinutes":540,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":9,"inAmpm":"PM","status":"Present","shortfallHours":0,"inH":12},"staff_3":{"productsSold":0,"workedMinutes":540,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":9,"inAmpm":"PM","status":"Present","shortfallHours":0,"inH":12},"staff_11":{"productsSold":0,"workedMinutes":540,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":6,"inAmpm":"AM","status":"Present","shortfallHours":0,"inH":9},"staff_10":{"productsSold":0,"workedMinutes":540,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":9,"inAmpm":"PM","status":"Present","shortfallHours":0,"inH":12},"staff_2":{"productsSold":0,"workedMinutes":540,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":9,"inAmpm":"PM","status":"Present","shortfallHours":0,"inH":12},"staff_12":{"productsSold":0,"workedMinutes":0,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":7,"inAmpm":"AM","status":"Weekly Off","shortfallHours":0,"inH":10}},"2026-09-11":{"staff_4":{"productsSold":0,"workedMinutes":720,"otPay":150,"otHours":3,"servicesDone":0,"inM":0,"outM":0,"outH":9,"inAmpm":"AM","status":"Present","shortfallHours":0,"inH":9},"staff_7":{"productsSold":0,"workedMinutes":516,"otPay":0,"otHours":0,"servicesDone":0,"inM":25,"outM":1,"outH":7,"inAmpm":"AM","status":"Present","shortfallHours":0,"inH":10},"staff_8":{"productsSold":0,"workedMinutes":720,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":9,"inAmpm":"AM","status":"Present","shortfallHours":0,"inH":9},"staff_5":{"productsSold":0,"workedMinutes":556,"otPay":0,"otHours":0,"servicesDone":0,"inM":46,"outM":2,"outH":8,"inAmpm":"AM","status":"Present","shortfallHours":0,"inH":10},"staff_6":{"productsSold":0,"workedMinutes":548,"otPay":0,"otHours":0,"servicesDone":0,"inM":55,"outM":3,"outH":9,"inAmpm":"AM","status":"Present","shortfallHours":0,"inH":11},"staff_3":{"productsSold":0,"workedMinutes":0,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":7,"inAmpm":"AM","status":"Weekly Off","shortfallHours":0,"inH":10},"staff_1":{"productsSold":0,"workedMinutes":525,"otPay":0,"otHours":0,"servicesDone":0,"inM":18,"outM":3,"outH":9,"inAmpm":"PM","status":"Present","shortfallHours":0,"inH":12},"staff_2":{"productsSold":0,"workedMinutes":0,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":7,"inAmpm":"AM","status":"Weekly Off","shortfallHours":0,"inH":10}},"2026-07-30":{"staff_4":{"productsSold":0,"workedMinutes":540,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":6,"inAmpm":"AM","status":"Present","shortfallHours":0,"inH":9},"staff_7":{"productsSold":0,"workedMinutes":0,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":7,"inAmpm":"AM","status":"Weekly Off","shortfallHours":0,"inH":10},"staff_8":{"productsSold":0,"workedMinutes":720,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":9,"inAmpm":"AM","status":"Present","shortfallHours":0,"inH":9},"staff_5":{"productsSold":0,"workedMinutes":540,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":8,"inAmpm":"AM","status":"Present","shortfallHours":0,"inH":11},"staff_6":{"productsSold":0,"workedMinutes":660,"otPay":100,"otHours":2,"servicesDone":0,"inM":0,"outM":0,"outH":9,"inAmpm":"AM","status":"Present","shortfallHours":0,"inH":10},"staff_3":{"otHours":0,"outH":7,"shortfallHours":0,"inAmpm":"AM","outM":0,"workedMinutes":0,"inH":10,"inM":0,"status":"Leave","servicesDone":0,"weekendCut":false,"productsSold":0,"otPay":0},"staff_1":{"productsSold":0,"workedMinutes":0,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":7,"inAmpm":"AM","status":"Weekly Off","shortfallHours":0,"inH":10},"staff_2":{"productsSold":0,"workedMinutes":600,"otPay":50,"otHours":1,"servicesDone":0,"inM":0,"outM":0,"outH":9,"inAmpm":"AM","status":"Present","shortfallHours":0,"inH":11}},"2026-09-19":{"staff_4":{"productsSold":0,"workedMinutes":555,"otPay":0,"otHours":0,"servicesDone":0,"inM":51,"outM":6,"outH":6,"inAmpm":"AM","status":"Present","shortfallHours":0,"inH":8},"staff_7":{"productsSold":0,"workedMinutes":533,"otPay":0,"otHours":0,"servicesDone":0,"inM":11,"outM":4,"outH":7,"inAmpm":"AM","status":"Present","shortfallHours":0,"inH":10},"staff_8":{"productsSold":0,"workedMinutes":720,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":9,"inAmpm":"AM","status":"Present","shortfallHours":0,"inH":9},"staff_5":{"productsSold":0,"workedMinutes":556,"otPay":0,"otHours":0,"servicesDone":0,"inM":45,"outM":1,"outH":8,"inAmpm":"AM","status":"Present","shortfallHours":0,"inH":10},"staff_6":{"productsSold":0,"workedMinutes":501,"otPay":0,"otHours":0,"servicesDone":0,"inM":45,"outM":6,"outH":9,"inAmpm":"PM","status":"Present","shortfallHours":1,"inH":12},"staff_3":{"productsSold":0,"workedMinutes":0,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":7,"inAmpm":"AM","status":"Weekly Off","shortfallHours":0,"inH":10},"staff_1":{"productsSold":0,"workedMinutes":558,"otPay":0,"otHours":0,"servicesDone":0,"inM":48,"outM":6,"outH":9,"inAmpm":"AM","status":"Present","shortfallHours":0,"inH":11},"staff_2":{"productsSold":0,"workedMinutes":535,"otPay":0,"otHours":0,"servicesDone":0,"inM":12,"outM":7,"outH":9,"inAmpm":"PM","status":"Present","shortfallHours":0,"inH":12}},"2026-08-29":{"staff_4":{"productsSold":0,"workedMinutes":600,"otPay":50,"otHours":1,"servicesDone":0,"inM":0,"outM":0,"outH":9,"inAmpm":"AM","status":"Present","shortfallHours":0,"inH":11},"staff_7":{"productsSold":0,"workedMinutes":540,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":7,"inAmpm":"AM","status":"Present","shortfallHours":0,"inH":10},"staff_8":{"productsSold":0,"workedMinutes":720,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":9,"inAmpm":"AM","status":"Present","shortfallHours":0,"inH":9},"staff_5":{"productsSold":0,"workedMinutes":540,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":8,"inAmpm":"AM","status":"Present","shortfallHours":0,"inH":11},"staff_6":{"productsSold":0,"workedMinutes":540,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":9,"inAmpm":"PM","status":"Present","shortfallHours":0,"inH":12},"staff_3":{"productsSold":0,"workedMinutes":540,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":6,"inAmpm":"AM","status":"Present","shortfallHours":0,"inH":9},"staff_2":{"productsSold":0,"workedMinutes":540,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":9,"inAmpm":"PM","status":"Present","shortfallHours":0,"inH":12}},"2026-07-07":{"staff_4":{"productsSold":0,"workedMinutes":0,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":7,"inAmpm":"AM","status":"Weekly Off","shortfallHours":0,"inH":10},"staff_8":{"productsSold":0,"workedMinutes":720,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":9,"inAmpm":"AM","status":"Present","shortfallHours":0,"inH":9},"staff_5":{"productsSold":0,"workedMinutes":540,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":8,"inAmpm":"AM","status":"Present","shortfallHours":0,"inH":11},"staff_6":{"productsSold":0,"workedMinutes":660,"otPay":100,"otHours":2,"servicesDone":0,"inM":0,"outM":0,"outH":9,"inAmpm":"AM","status":"Present","shortfallHours":0,"inH":10},"staff_3":{"productsSold":0,"workedMinutes":540,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":5,"inAmpm":"AM","status":"Present","shortfallHours":0,"inH":8},"staff_1":{"productsSold":0,"workedMinutes":540,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":9,"inAmpm":"PM","status":"Present","shortfallHours":0,"inH":12},"staff_2":{"productsSold":0,"workedMinutes":600,"otPay":50,"otHours":1,"servicesDone":0,"inM":0,"outM":0,"outH":9,"inAmpm":"AM","status":"Present","shortfallHours":0,"inH":11}},"2026-05-05":{"staff_4":{"productsSold":0,"workedMinutes":540,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":6,"inAmpm":"AM","status":"Present","shortfallHours":0,"inH":9},"staff_9":{"productsSold":0,"workedMinutes":540,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":9,"inAmpm":"PM","status":"Present","shortfallHours":0,"inH":12},"staff_8":{"productsSold":0,"workedMinutes":720,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":9,"inAmpm":"AM","status":"Present","shortfallHours":0,"inH":9},"staff_5":{"productsSold":0,"workedMinutes":540,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":6,"inAmpm":"AM","status":"Present","shortfallHours":0,"inH":9},"staff_6":{"productsSold":0,"workedMinutes":540,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":8,"inAmpm":"AM","status":"Present","shortfallHours":0,"inH":11},"staff_3":{"productsSold":0,"workedMinutes":540,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":8,"inAmpm":"AM","status":"Present","shortfallHours":0,"inH":11},"staff_11":{"productsSold":0,"workedMinutes":0,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":7,"inAmpm":"AM","status":"Weekly Off","shortfallHours":0,"inH":10},"staff_10":{"productsSold":0,"workedMinutes":540,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":9,"inAmpm":"PM","status":"Present","shortfallHours":0,"inH":12},"staff_2":{"productsSold":0,"workedMinutes":0,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":7,"inAmpm":"AM","status":"Weekly Off","shortfallHours":0,"inH":10}},"2026-07-19":{"staff_4":{"productsSold":0,"workedMinutes":540,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":6,"inAmpm":"AM","status":"Present","shortfallHours":0,"inH":9},"staff_7":{"productsSold":0,"workedMinutes":540,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":9,"inAmpm":"PM","status":"Present","shortfallHours":0,"inH":12},"staff_8":{"productsSold":0,"workedMinutes":720,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":9,"inAmpm":"AM","status":"Present","shortfallHours":0,"inH":9},"staff_5":{"productsSold":0,"workedMinutes":540,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":8,"inAmpm":"AM","status":"Present","shortfallHours":0,"inH":11},"staff_6":{"productsSold":0,"workedMinutes":540,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":6,"inAmpm":"AM","status":"Present","shortfallHours":0,"inH":9},"staff_3":{"otHours":0,"outH":7,"shortfallHours":0,"inAmpm":"AM","outM":0,"workedMinutes":0,"inH":10,"inM":0,"status":"Leave","servicesDone":0,"weekendCut":true,"productsSold":0,"otPay":0},"staff_1":{"productsSold":0,"workedMinutes":540,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":9,"inAmpm":"PM","status":"Present","shortfallHours":0,"inH":12},"staff_2":{"productsSold":0,"workedMinutes":600,"otPay":50,"otHours":1,"servicesDone":0,"inM":0,"outM":0,"outH":9,"inAmpm":"AM","status":"Present","shortfallHours":0,"inH":11}},"2026-09-25":{"staff_4":{"productsSold":0,"workedMinutes":530,"otPay":0,"otHours":0,"servicesDone":0,"inM":6,"outM":56,"outH":8,"inAmpm":"PM","status":"Present","shortfallHours":0,"inH":12},"staff_7":{"productsSold":0,"workedMinutes":546,"otPay":0,"otHours":0,"servicesDone":0,"inM":54,"outM":0,"outH":9,"inAmpm":"AM","status":"Present","shortfallHours":0,"inH":11},"staff_8":{"productsSold":0,"workedMinutes":720,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":9,"inAmpm":"AM","status":"Present","shortfallHours":0,"inH":9},"staff_5":{"productsSold":0,"workedMinutes":571,"otPay":0,"otHours":0,"servicesDone":0,"inM":39,"outM":10,"outH":8,"inAmpm":"AM","status":"Present","shortfallHours":0,"inH":10},"staff_6":{"productsSold":0,"workedMinutes":0,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":7,"inAmpm":"AM","status":"Weekly Off","shortfallHours":0,"inH":10},"staff_3":{"productsSold":0,"workedMinutes":0,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":7,"inAmpm":"AM","status":"Weekly Off","shortfallHours":0,"inH":10},"staff_1":{"productsSold":0,"workedMinutes":249,"otPay":0,"otHours":0,"servicesDone":0,"inM":55,"outM":4,"outH":9,"inAmpm":"PM","status":"Present","shortfallHours":5,"inH":4},"staff_2":{"productsSold":0,"workedMinutes":579,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":39,"outH":6,"inAmpm":"AM","status":"Present","shortfallHours":0,"inH":9}},"2026-09-07":{"staff_4":{"productsSold":0,"workedMinutes":539,"otPay":0,"otHours":0,"servicesDone":0,"inM":4,"outM":3,"outH":9,"inAmpm":"PM","status":"Present","shortfallHours":0,"inH":12},"staff_7":{"productsSold":0,"workedMinutes":545,"otPay":0,"otHours":0,"servicesDone":0,"inM":57,"outM":2,"outH":9,"inAmpm":"AM","status":"Present","shortfallHours":0,"inH":11},"staff_8":{"productsSold":0,"workedMinutes":720,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":9,"inAmpm":"AM","status":"Present","shortfallHours":0,"inH":9},"staff_5":{"productsSold":0,"workedMinutes":538,"otPay":0,"otHours":0,"servicesDone":0,"inM":5,"outM":3,"outH":7,"inAmpm":"AM","status":"Present","shortfallHours":0,"inH":10},"staff_6":{"productsSold":0,"workedMinutes":0,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":7,"inAmpm":"AM","status":"Leave","shortfallHours":0,"inH":10},"staff_3":{"productsSold":0,"workedMinutes":0,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":7,"inAmpm":"AM","status":"Weekly Off","shortfallHours":0,"inH":10},"staff_1":{"productsSold":0,"workedMinutes":545,"otPay":0,"otHours":0,"servicesDone":0,"inM":1,"outM":6,"outH":9,"inAmpm":"PM","status":"Present","shortfallHours":0,"inH":12},"staff_2":{"productsSold":0,"workedMinutes":714,"otPay":150,"otHours":3,"servicesDone":0,"inM":6,"outM":0,"outH":9,"inAmpm":"AM","status":"Present","shortfallHours":0,"inH":9}},"2026-07-09":{"staff_4":{"productsSold":0,"workedMinutes":540,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":5,"inAmpm":"AM","status":"Present","shortfallHours":0,"inH":8},"staff_8":{"productsSold":0,"workedMinutes":720,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":9,"inAmpm":"AM","status":"Present","shortfallHours":0,"inH":9},"staff_5":{"productsSold":0,"workedMinutes":0,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":7,"inAmpm":"AM","status":"Weekly Off","shortfallHours":0,"inH":10},"staff_6":{"productsSold":0,"workedMinutes":660,"otPay":100,"otHours":2,"servicesDone":0,"inM":0,"outM":0,"outH":9,"inAmpm":"AM","status":"Present","shortfallHours":0,"inH":10},"staff_3":{"productsSold":0,"workedMinutes":540,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":8,"inAmpm":"AM","status":"Present","shortfallHours":0,"inH":11},"staff_1":{"productsSold":0,"workedMinutes":540,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":9,"inAmpm":"PM","status":"Present","shortfallHours":0,"inH":12},"staff_2":{"productsSold":0,"workedMinutes":540,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":9,"inAmpm":"PM","status":"Present","shortfallHours":0,"inH":12}},"2026-06-12":{"staff_4":{"productsSold":0,"workedMinutes":540,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":6,"inAmpm":"AM","status":"Present","shortfallHours":0,"inH":9},"staff_9":{"productsSold":0,"workedMinutes":540,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":8,"inAmpm":"AM","status":"Present","shortfallHours":0,"inH":11},"staff_8":{"productsSold":0,"workedMinutes":720,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":9,"inAmpm":"AM","status":"Present","shortfallHours":0,"inH":9},"staff_5":{"productsSold":0,"workedMinutes":0,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":7,"inAmpm":"AM","status":"Weekly Off","shortfallHours":0,"inH":10},"staff_6":{"productsSold":0,"workedMinutes":540,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":9,"inAmpm":"PM","status":"Present","shortfallHours":0,"inH":12},"staff_3":{"productsSold":0,"workedMinutes":540,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":9,"inAmpm":"PM","status":"Present","shortfallHours":0,"inH":12},"staff_11":{"productsSold":0,"workedMinutes":540,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":6,"inAmpm":"AM","status":"Present","shortfallHours":0,"inH":9},"staff_10":{"productsSold":0,"workedMinutes":540,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":6,"inAmpm":"AM","status":"Present","shortfallHours":0,"inH":9},"staff_2":{"productsSold":0,"workedMinutes":0,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":7,"inAmpm":"AM","status":"Weekly Off","shortfallHours":0,"inH":10},"staff_12":{"productsSold":0,"workedMinutes":540,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":6,"inAmpm":"AM","status":"Present","shortfallHours":0,"inH":9}},"2026-08-13":{"staff_4":{"otHours":0,"outH":7,"shortfallHours":0,"inAmpm":"AM","outM":0,"workedMinutes":0,"inH":10,"inM":0,"status":"Leave","servicesDone":0,"weekendCut":false,"productsSold":0,"otPay":0},"staff_7":{"productsSold":0,"workedMinutes":540,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":7,"inAmpm":"AM","status":"Present","shortfallHours":0,"inH":10},"staff_8":{"productsSold":0,"workedMinutes":720,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":9,"inAmpm":"AM","status":"Present","shortfallHours":0,"inH":9},"staff_5":{"productsSold":0,"workedMinutes":540,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":8,"inAmpm":"AM","status":"Present","shortfallHours":0,"inH":11},"staff_6":{"productsSold":0,"workedMinutes":540,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":9,"inAmpm":"PM","status":"Present","shortfallHours":0,"inH":12},"staff_3":{"productsSold":0,"workedMinutes":540,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":9,"inAmpm":"PM","status":"Present","shortfallHours":0,"inH":12},"staff_1":{"productsSold":0,"workedMinutes":540,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":8,"inAmpm":"AM","status":"Present","shortfallHours":0,"inH":11},"staff_2":{"productsSold":0,"workedMinutes":540,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":6,"inAmpm":"AM","status":"Present","shortfallHours":0,"inH":9}},"2026-08-31":{"staff_4":{"productsSold":0,"workedMinutes":540,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":6,"inAmpm":"AM","status":"Present","shortfallHours":0,"inH":9},"staff_7":{"productsSold":0,"workedMinutes":660,"otPay":100,"otHours":2,"servicesDone":0,"inM":0,"outM":0,"outH":9,"inAmpm":"AM","status":"Present","shortfallHours":0,"inH":10},"staff_8":{"productsSold":0,"workedMinutes":720,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":9,"inAmpm":"AM","status":"Present","shortfallHours":0,"inH":9},"staff_5":{"productsSold":0,"workedMinutes":540,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":8,"inAmpm":"AM","status":"Present","shortfallHours":0,"inH":11},"staff_6":{"productsSold":0,"workedMinutes":0,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":7,"inAmpm":"AM","status":"Weekly Off","shortfallHours":0,"inH":10},"staff_3":{"productsSold":0,"workedMinutes":0,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":7,"inAmpm":"AM","status":"Weekly Off","shortfallHours":0,"inH":10},"staff_1":{"productsSold":0,"workedMinutes":540,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":9,"inAmpm":"PM","status":"Present","shortfallHours":0,"inH":12},"staff_2":{"productsSold":0,"workedMinutes":540,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":9,"inAmpm":"PM","status":"Present","shortfallHours":0,"inH":12}},"2026-09-02":{"staff_4":{"productsSold":0,"workedMinutes":529,"otPay":0,"otHours":0,"servicesDone":0,"inM":11,"outM":0,"outH":9,"inAmpm":"PM","status":"Present","shortfallHours":0,"inH":12},"staff_7":{"productsSold":0,"workedMinutes":566,"otPay":0,"otHours":0,"servicesDone":0,"inM":35,"outM":1,"outH":9,"inAmpm":"AM","status":"Present","shortfallHours":0,"inH":11},"staff_8":{"productsSold":0,"workedMinutes":720,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":9,"inAmpm":"AM","status":"Present","shortfallHours":0,"inH":9},"staff_5":{"productsSold":0,"workedMinutes":546,"otPay":0,"otHours":0,"servicesDone":0,"inM":54,"outM":0,"outH":8,"inAmpm":"AM","status":"Present","shortfallHours":0,"inH":10},"staff_6":{"productsSold":0,"workedMinutes":544,"otPay":0,"otHours":0,"servicesDone":0,"inM":56,"outM":0,"outH":7,"inAmpm":"AM","status":"Present","shortfallHours":0,"inH":9},"staff_3":{"productsSold":0,"workedMinutes":535,"otPay":0,"otHours":0,"servicesDone":0,"inM":5,"outM":0,"outH":6,"inAmpm":"AM","status":"Present","shortfallHours":0,"inH":9},"staff_1":{"productsSold":0,"workedMinutes":537,"otPay":0,"otHours":0,"servicesDone":0,"inM":7,"outM":4,"outH":9,"inAmpm":"PM","status":"Present","shortfallHours":0,"inH":12},"staff_2":{"productsSold":0,"workedMinutes":0,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":7,"inAmpm":"AM","status":"Weekly Off","shortfallHours":0,"inH":10}},"2026-08-20":{"staff_4":{"productsSold":0,"workedMinutes":540,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":6,"inAmpm":"AM","status":"Present","shortfallHours":0,"inH":9},"staff_7":{"productsSold":0,"workedMinutes":540,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":7,"inAmpm":"AM","status":"Present","shortfallHours":0,"inH":10},"staff_8":{"productsSold":0,"workedMinutes":720,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":9,"inAmpm":"AM","status":"Present","shortfallHours":0,"inH":9},"staff_5":{"productsSold":0,"workedMinutes":540,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":7,"inAmpm":"AM","status":"Present","shortfallHours":0,"inH":10},"staff_6":{"productsSold":0,"workedMinutes":540,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":9,"inAmpm":"PM","status":"Present","shortfallHours":0,"inH":12},"staff_3":{"productsSold":0,"workedMinutes":540,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":8,"inAmpm":"AM","status":"Present","shortfallHours":0,"inH":11},"staff_1":{"productsSold":0,"workedMinutes":540,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":8,"inAmpm":"AM","status":"Present","shortfallHours":0,"inH":11},"staff_2":{"productsSold":0,"workedMinutes":0,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":7,"inAmpm":"AM","status":"Weekly Off","shortfallHours":0,"inH":10}},"2026-07-05":{"staff_4":{"productsSold":0,"workedMinutes":540,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":9,"inAmpm":"PM","status":"Present","shortfallHours":0,"inH":12},"staff_8":{"productsSold":0,"workedMinutes":720,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":9,"inAmpm":"AM","status":"Present","shortfallHours":0,"inH":9},"staff_5":{"productsSold":0,"workedMinutes":540,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":8,"inAmpm":"AM","status":"Present","shortfallHours":0,"inH":11},"staff_6":{"productsSold":0,"workedMinutes":660,"otPay":100,"otHours":2,"servicesDone":0,"inM":0,"outM":0,"outH":9,"inAmpm":"AM","status":"Present","shortfallHours":0,"inH":10},"staff_3":{"productsSold":0,"workedMinutes":540,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":5,"inAmpm":"AM","status":"Present","shortfallHours":0,"inH":8},"staff_2":{"productsSold":0,"workedMinutes":540,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":7,"inAmpm":"AM","status":"Present","shortfallHours":0,"inH":10}},"2026-06-14":{"staff_4":{"productsSold":0,"workedMinutes":540,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":6,"inAmpm":"AM","status":"Present","shortfallHours":0,"inH":9},"staff_9":{"productsSold":0,"workedMinutes":540,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":6,"inAmpm":"AM","status":"Present","shortfallHours":0,"inH":9},"staff_8":{"productsSold":0,"workedMinutes":720,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":9,"inAmpm":"AM","status":"Present","shortfallHours":0,"inH":9},"staff_5":{"productsSold":0,"workedMinutes":540,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":9,"inAmpm":"PM","status":"Present","shortfallHours":0,"inH":12},"staff_6":{"productsSold":0,"workedMinutes":540,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":6,"inAmpm":"AM","status":"Present","shortfallHours":0,"inH":9},"staff_3":{"productsSold":0,"workedMinutes":540,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":9,"inAmpm":"PM","status":"Present","shortfallHours":0,"inH":12},"staff_11":{"productsSold":0,"workedMinutes":540,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":9,"inAmpm":"PM","status":"Present","shortfallHours":0,"inH":12},"staff_10":{"productsSold":0,"workedMinutes":540,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":6,"inAmpm":"AM","status":"Present","shortfallHours":0,"inH":9},"staff_2":{"productsSold":0,"workedMinutes":540,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":9,"inAmpm":"PM","status":"Present","shortfallHours":0,"inH":12},"staff_12":{"productsSold":0,"workedMinutes":540,"otPay":0,"otHours":0,"servicesDone":0,"inM":0,"outM":0,"outH":6,"inAmpm":"AM","status":"Present","shortfallHours":0,"inH":9}}}
;
const SEPTEMBER_2026_REAL_ATTENDANCE = FULL_SALON_ATTENDANCE_DATA;

const DATA_VERSION = '20260926_chat_v2';

function initStorage() {
  const savedStaff = localStorage.getItem(STORAGE_KEYS.STAFF);
  if (savedStaff) {
    try { staffList = JSON.parse(savedStaff); } catch(e) { staffList = [...DEFAULT_STAFF]; }
  } else {
    staffList = [...DEFAULT_STAFF];
  }
  // Ensure all current staff definitions exist (including Karthik, Bhargavi, Navanitha, Varsha, Ramesh)
  DEFAULT_STAFF.forEach(defStaff => {
    if (!staffList.some(s => s.id === defStaff.id)) {
      staffList.push({ ...defStaff });
    }
  });
  localStorage.setItem(STORAGE_KEYS.STAFF, JSON.stringify(staffList));

  const savedRules = localStorage.getItem(STORAGE_KEYS.RULES);
  if (savedRules) {
    try { salonRules = JSON.parse(savedRules); } catch(e) { salonRules = { ...DEFAULT_SALON_RULES }; }
  } else {
    salonRules = { ...DEFAULT_SALON_RULES };
    localStorage.setItem(STORAGE_KEYS.RULES, JSON.stringify(salonRules));
  }

  // Load and merge attendance data
  let savedAttendance = localStorage.getItem(STORAGE_KEYS.ATTENDANCE);
  if (!savedAttendance) {
    const olderKeys = ['gt_kothapet_attendance_v3', 'gt_kothapet_attendance_v2', 'gt_kothapet_attendance_v1', 'gt_kothapet_attendance', 'gt_attendance_data'];
    for (const ok of olderKeys) {
      const val = localStorage.getItem(ok);
      if (val) {
        savedAttendance = val;
        break;
      }
    }
  }

  if (savedAttendance) {
    try {
      attendanceData = JSON.parse(savedAttendance);
    } catch(e) {
      attendanceData = {};
    }
  } else {
    attendanceData = {};
  }

  // Merge full roster from May 5 to Sep 26 into attendanceData
  for (const dateKey in FULL_SALON_ATTENDANCE_DATA) {
    if (!attendanceData[dateKey]) {
      attendanceData[dateKey] = JSON.parse(JSON.stringify(FULL_SALON_ATTENDANCE_DATA[dateKey]));
    } else {
      for (const staffId in FULL_SALON_ATTENDANCE_DATA[dateKey]) {
        if (!attendanceData[dateKey][staffId]) {
          attendanceData[dateKey][staffId] = JSON.parse(JSON.stringify(FULL_SALON_ATTENDANCE_DATA[dateKey][staffId]));
        }
      }
    }
  }
  localStorage.setItem(STORAGE_KEYS.ATTENDANCE, JSON.stringify(attendanceData));

  const savedAdvances = localStorage.getItem(STORAGE_KEYS.ADVANCES);
  if (savedAdvances) {
    try { advanceData = JSON.parse(savedAdvances); } catch(e) { advanceData = {}; }
  } else {
    advanceData = {};
  }

  const savedExpenses = localStorage.getItem(STORAGE_KEYS.EXPENSES);
  if (savedExpenses) {
    try { salonExpenses = JSON.parse(savedExpenses); } catch(e) { salonExpenses = [...DEFAULT_SALON_EXPENSES]; }
  } else {
    salonExpenses = [...DEFAULT_SALON_EXPENSES];
    saveSalonExpenses();
  }
}

function syncRealSeptemberAttendanceData() {
  if (confirm("Re-sync all attendance with accurate WhatsApp check-in / check-out data for Sep 1â€“26?")) {
    attendanceData = JSON.parse(JSON.stringify(SEPTEMBER_2026_REAL_ATTENDANCE));
    saveAttendanceData();
    updateViewFromHash();
    showToast("Successfully synchronized all September 1â€“26 attendance records from chat!");
  }
}

function saveStaffList() {
  localStorage.setItem(STORAGE_KEYS.STAFF, JSON.stringify(staffList));
  pushToFirestoreDebounced();
}

function saveSalonRules() {
  localStorage.setItem(STORAGE_KEYS.RULES, JSON.stringify(salonRules));
  pushToFirestoreDebounced();
}

function saveAttendanceData() {
  localStorage.setItem(STORAGE_KEYS.ATTENDANCE, JSON.stringify(attendanceData));
  pushToFirestoreDebounced();
}

function saveAdvanceData() {
  localStorage.setItem(STORAGE_KEYS.ADVANCES, JSON.stringify(advanceData));
  pushToFirestoreDebounced();
}

function saveSalonExpenses() {
  localStorage.setItem(STORAGE_KEYS.EXPENSES, JSON.stringify(salonExpenses));
  pushToFirestoreDebounced();
}

function updateStaffAdvance(staffId, amount) {
  if (!advanceData[selectedMonthStr]) advanceData[selectedMonthStr] = {};
  const numVal = Math.max(0, parseFloat(amount) || 0);
  if (numVal === 0) {
    delete advanceData[selectedMonthStr][staffId];
  } else {
    advanceData[selectedMonthStr][staffId] = numVal;
  }
  saveAdvanceData();
  renderMonthlyPayroll();
  showToast(`Advance updated for ${getStaffName(staffId)}: â‚¹${numVal.toLocaleString('en-IN')}`);
}

// ==========================================
// 2.3 FIREBASE REAL-TIME CLOUD SYNC (100% FREE)
// ==========================================

function pushToFirestoreDebounced() {
  if (!firestoreDb) return;
  if (cloudSyncTimeout) clearTimeout(cloudSyncTimeout);
  cloudSyncTimeout = setTimeout(() => {
    pushLocalDataToFirestore(false);
  }, 1200);
}

async function pushLocalDataToFirestore(showToastNotification = false) {
  if (!firestoreDb) {
    if (showToastNotification) alert("Firebase is not connected yet. Paste your config in Admin to connect.");
    return;
  }

  try {
    isSyncingToCloud = true;
    updateCloudSyncUI('syncing');

    await firestoreDb.collection('salons').doc('green_trends_kothapet').set({
      attendance: attendanceData,
      staff: staffList,
      rules: salonRules,
      advances: advanceData,
      expenses: salonExpenses,
      lastUpdated: firebase.firestore.FieldValue.serverTimestamp(),
      updatedBy: getSessionUser()?.username || 'Owner'
    }, { merge: true });

    setTimeout(() => {
      isSyncingToCloud = false;
      const savedConfig = localStorage.getItem(STORAGE_KEYS.FIREBASE);
      const projectId = savedConfig ? JSON.parse(savedConfig).projectId : '';
      updateCloudSyncUI('connected', projectId);
    }, 500);

    if (showToastNotification) {
      showToast("âœ“ Synced all 15-day attendance & staff records to Firebase Cloud!");
    }
  } catch (err) {
    console.error("Firestore push error:", err);
    isSyncingToCloud = false;
    updateCloudSyncUI('error');
    if (showToastNotification) {
      alert("Cloud Push Error: " + (err.message || err));
    }
  }
}

async function pullDataFromFirestore(showToastNotification = false) {
  if (!firestoreDb) {
    if (showToastNotification) alert("Firebase is not connected yet.");
    return;
  }

  try {
    showToast("Checking cloud for latest updates...");
    const docSnap = await firestoreDb.collection('salons').doc('green_trends_kothapet').get();
    if (docSnap.exists) {
      const data = docSnap.data();
      let updated = false;

      if (data.attendance) {
        attendanceData = data.attendance;
        localStorage.setItem(STORAGE_KEYS.ATTENDANCE, JSON.stringify(attendanceData));
        updated = true;
      }
      if (data.staff) {
        staffList = data.staff;
        localStorage.setItem(STORAGE_KEYS.STAFF, JSON.stringify(staffList));
        updated = true;
      }
      if (data.rules) {
        salonRules = data.rules;
        localStorage.setItem(STORAGE_KEYS.RULES, JSON.stringify(salonRules));
        updated = true;
      }
      if (data.advances) {
        advanceData = data.advances;
        localStorage.setItem(STORAGE_KEYS.ADVANCES, JSON.stringify(advanceData));
        updated = true;
      }
      if (data.expenses) {
        salonExpenses = data.expenses;
        localStorage.setItem(STORAGE_KEYS.EXPENSES, JSON.stringify(salonExpenses));
        updated = true;
      }

      if (updated) {
        updateViewFromHash();
      }

      if (showToastNotification) {
        showToast("âœ“ Pulled latest salon records from Firebase Cloud!");
      }
    } else {
      if (showToastNotification) {
        showToast("No data in cloud yet. Click 'Push to Cloud' to upload your local data.");
      }
    }
  } catch (err) {
    console.error("Firestore pull error:", err);
    if (showToastNotification) {
      alert("Cloud Pull Error: " + (err.message || err));
    }
  }
}

function parseFirebaseConfigInput(raw) {
  if (!raw) return null;
  let str = raw.trim();

  // 1. Direct JSON parse
  try {
    const parsed = JSON.parse(str);
    if (parsed.apiKey && parsed.projectId) return parsed;
  } catch (e) {}

  // 2. Strip JavaScript declaration: "const firebaseConfig = { ... };"
  str = str.replace(/^(?:const|let|var)\s+\w+\s*=\s*/i, '');
  str = str.replace(/;\s*$/, '').trim();

  try {
    const parsed = JSON.parse(str);
    if (parsed.apiKey && parsed.projectId) return parsed;
  } catch (e) {}

  // 3. Robust regex extraction for loose JS objects
  const extract = (key) => {
    const m = str.match(new RegExp('(?:["\']?' + key + '["\']?\\s*:\\s*["\']([^"\']+)["\'])', 'i'));
    return m ? m[1].trim() : '';
  };

  const apiKey = extract('apiKey');
  const projectId = extract('projectId');
  if (apiKey && projectId) {
    return {
      apiKey: apiKey,
      authDomain: extract('authDomain') || `${projectId}.firebaseapp.com`,
      projectId: projectId,
      storageBucket: extract('storageBucket') || `${projectId}.appspot.com`,
      messagingSenderId: extract('messagingSenderId'),
      appId: extract('appId')
    };
  }

  return null;
}

function initFirebaseSync() {
  const savedSetting = localStorage.getItem(STORAGE_KEYS.FIREBASE);
  if (savedSetting === 'disabled') {
    updateCloudSyncUI('local');
    return;
  }

  let config = null;
  if (savedSetting) {
    try { config = JSON.parse(savedSetting); } catch (e) {}
  }

  if (!config && typeof DEFAULT_FIREBASE_CONFIG !== 'undefined' && DEFAULT_FIREBASE_CONFIG.apiKey) {
    config = { ...DEFAULT_FIREBASE_CONFIG };
    localStorage.setItem(STORAGE_KEYS.FIREBASE, JSON.stringify(config));
  }

  if (!config || !config.apiKey || !config.projectId) {
    updateCloudSyncUI('local');
    return;
  }

  try {
    if (typeof firebase === 'undefined') {
      console.warn("Firebase SDK not available");
      updateCloudSyncUI('local');
      return;
    }

    if (!firebase.apps || firebase.apps.length === 0) {
      firebaseApp = firebase.initializeApp(config);
    } else {
      firebaseApp = firebase.apps[0];
    }

    firestoreDb = firebase.firestore();

    // Attach real-time snapshot listener
    if (firestoreUnsubscribe) firestoreUnsubscribe();

    firestoreUnsubscribe = firestoreDb.collection('salons').doc('green_trends_kothapet')
      .onSnapshot((doc) => {
        if (doc.exists) {
          const cloudData = doc.data();
          if (cloudData && !isSyncingToCloud) {
            let changed = false;
            if (cloudData.attendance && JSON.stringify(cloudData.attendance) !== JSON.stringify(attendanceData)) {
              attendanceData = cloudData.attendance;
              localStorage.setItem(STORAGE_KEYS.ATTENDANCE, JSON.stringify(attendanceData));
              changed = true;
            }
            if (cloudData.staff && JSON.stringify(cloudData.staff) !== JSON.stringify(staffList)) {
              staffList = cloudData.staff;
              localStorage.setItem(STORAGE_KEYS.STAFF, JSON.stringify(staffList));
              changed = true;
            }
            if (cloudData.rules && JSON.stringify(cloudData.rules) !== JSON.stringify(salonRules)) {
              salonRules = cloudData.rules;
              localStorage.setItem(STORAGE_KEYS.RULES, JSON.stringify(salonRules));
              changed = true;
            }
            if (cloudData.advances && JSON.stringify(cloudData.advances) !== JSON.stringify(advanceData)) {
              advanceData = cloudData.advances;
              localStorage.setItem(STORAGE_KEYS.ADVANCES, JSON.stringify(advanceData));
              changed = true;
            }
            if (cloudData.expenses && JSON.stringify(cloudData.expenses) !== JSON.stringify(salonExpenses)) {
              salonExpenses = cloudData.expenses;
              localStorage.setItem(STORAGE_KEYS.EXPENSES, JSON.stringify(salonExpenses));
              changed = true;
            }

            if (changed) {
              updateViewFromHash();
              // Seamless silent cloud sync: no intrusive popups on auto-sync
            }
            updateCloudSyncUI('connected', config.projectId);
          }
        } else {
          // New document: Push existing local data so nothing is lost!
          pushLocalDataToFirestore(false);
          updateCloudSyncUI('connected', config.projectId);
        }
      }, (err) => {
        console.error("Firestore onSnapshot error:", err);
        updateCloudSyncUI('error', config.projectId);
      });

    updateCloudSyncUI('connected', config.projectId);
  } catch (err) {
    console.error("Firebase init error:", err);
    updateCloudSyncUI('error');
  }
}

async function connectFirebaseCloud() {
  const inputEl = document.getElementById('firebaseConfigInput');
  if (!inputEl) return;

  const raw = inputEl.value;
  const config = parseFirebaseConfigInput(raw);

  if (!config || !config.apiKey || !config.projectId) {
    alert("Please paste a valid Firebase configuration with 'apiKey' and 'projectId'. Click 'How to get free key?' for 3 quick steps.");
    return;
  }

  localStorage.setItem(STORAGE_KEYS.FIREBASE, JSON.stringify(config));
  initFirebaseSync();

  showToast("Connecting to Firebase Cloud...");
  setTimeout(async () => {
    await pushLocalDataToFirestore(true);
    renderAdminView();
  }, 1000);
}

function disconnectFirebaseCloud() {
  if (confirm("Disconnect from Firebase Cloud and switch back to Local Storage? Your data will remain safe on your device.")) {
    if (firestoreUnsubscribe) firestoreUnsubscribe();
    firestoreUnsubscribe = null;
    firestoreDb = null;
    firebaseApp = null;
    localStorage.setItem(STORAGE_KEYS.FIREBASE, 'disabled');
    updateCloudSyncUI('local');
    renderAdminView();
    showToast("Disconnected from Firebase. Operating in Local Storage mode.");
  }
}

function updateCloudSyncUI(status, projectId = '') {
  cloudSyncStatus = status;

  // Header Badge
  const headerDot = document.getElementById('cloudSyncHeaderDot');
  const headerText = document.getElementById('cloudSyncHeaderText');

  if (headerDot && headerText) {
    if (status === 'connected') {
      headerDot.className = 'w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse';
      headerText.className = 'text-emerald-400 font-bold text-xs';
      headerText.innerHTML = '<i class="fa-solid fa-cloud text-emerald-400 mr-1"></i><span class="hidden 2xl:inline">Cloud </span>Live';
    } else if (status === 'syncing') {
      headerDot.className = 'w-1.5 h-1.5 rounded-full bg-[#ff2a85] animate-ping';
      headerText.className = 'text-[#ff7eb3] font-bold text-xs';
      headerText.innerHTML = '<i class="fa-solid fa-arrows-rotate fa-spin text-[#ff2a85] mr-1"></i><span class="hidden 2xl:inline">Syncing...</span>';
    } else if (status === 'error') {
      headerDot.className = 'w-1.5 h-1.5 rounded-full bg-rose-500';
      headerText.className = 'text-rose-400 font-bold text-xs';
      headerText.innerHTML = '<i class="fa-solid fa-circle-exclamation text-rose-400 mr-1"></i>Error';
    } else {
      headerDot.className = 'w-1.5 h-1.5 rounded-full bg-amber-400';
      headerText.className = 'text-gray-400 font-semibold text-xs';
      headerText.innerHTML = '<i class="fa-solid fa-hard-drive text-amber-400 mr-1"></i><span class="hidden 2xl:inline">Local </span>Storage';
    }
  }

  // Admin Card UI
  const adminBadge = document.getElementById('cloudStatusBadgeAdmin');
  const adminDot = document.getElementById('cloudStatusDotAdmin');
  const adminText = document.getElementById('cloudStatusTextAdmin');
  const setupSec = document.getElementById('firebaseSetupSection');
  const connSec = document.getElementById('firebaseConnectedSection');
  const projName = document.getElementById('connectedProjectName');
  const syncTime = document.getElementById('lastCloudSyncTime');

  if (adminBadge && adminText && adminDot) {
    if (status === 'connected') {
      adminBadge.className = 'text-[10px] font-bold font-mono px-2.5 py-1 rounded-full bg-emerald-500/15 text-emerald-400 border border-emerald-500/30 flex items-center gap-1.5';
      adminDot.className = 'w-1.5 h-1.5 rounded-full bg-emerald-400';
      adminText.innerText = 'Connected & Live';
      if (setupSec) setupSec.classList.add('hidden');
      if (connSec) connSec.classList.remove('hidden');
      if (projName) projName.innerText = `Connected: ${projectId || 'green-trends-kothapet'}`;
      if (syncTime) syncTime.innerText = `Live 2-Way Sync Active (${new Date().toLocaleTimeString()})`;
    } else if (status === 'syncing') {
      adminBadge.className = 'text-[10px] font-bold font-mono px-2.5 py-1 rounded-full bg-[#ff2a85]/15 text-[#ff7eb3] border border-[#ff2a85]/30 flex items-center gap-1.5';
      adminDot.className = 'w-1.5 h-1.5 rounded-full bg-[#ff2a85] animate-ping';
      adminText.innerText = 'Syncing...';
    } else if (status === 'error') {
      adminBadge.className = 'text-[10px] font-bold font-mono px-2.5 py-1 rounded-full bg-rose-500/15 text-rose-400 border border-rose-500/30 flex items-center gap-1.5';
      adminDot.className = 'w-1.5 h-1.5 rounded-full bg-rose-400';
      adminText.innerText = 'Connection Error';
    } else {
      adminBadge.className = 'text-[10px] font-bold font-mono px-2.5 py-1 rounded-full bg-amber-500/15 text-amber-400 border border-amber-500/30 flex items-center gap-1.5';
      adminDot.className = 'w-1.5 h-1.5 rounded-full bg-amber-400';
      adminText.innerText = 'Local Storage Only';
      if (setupSec) setupSec.classList.remove('hidden');
      if (connSec) connSec.classList.add('hidden');
    }
  }
}

function openFirebaseHelpModal() {
  const m = document.getElementById('firebaseHelpModal');
  if (m) m.classList.remove('hidden');
}

function closeFirebaseHelpModal() {
  const m = document.getElementById('firebaseHelpModal');
  if (m) m.classList.add('hidden');
}

// ==========================================
// 2.5 AUTHENTICATION & LOGIN MANAGEMENT
// ==========================================

function getAuthCredentials() {
  const saved = localStorage.getItem(STORAGE_KEYS.AUTH);
  let creds;
  if (!saved) {
    creds = { ...DEFAULT_AUTH };
    localStorage.setItem(STORAGE_KEYS.AUTH, JSON.stringify(creds));
    return creds;
  }
  try {
    creds = JSON.parse(saved);
  } catch (e) {
    creds = { ...DEFAULT_AUTH };
  }

  // Ensure accounts array exists and contains both Owner and Manager accounts
  if (!creds.accounts || !Array.isArray(creds.accounts)) {
    creds.accounts = [...DEFAULT_AUTH.accounts];
  }
  const hasManager = creds.accounts.some(a => a.username.toLowerCase() === 'greentrendskothapet@gmail.com');
  if (!hasManager) {
    creds.accounts.push({
      username: 'Greentrendskothapet@gmail.com',
      password: 'Kothapet@9',
      role: 'Salon Manager'
    });
    localStorage.setItem(STORAGE_KEYS.AUTH, JSON.stringify(creds));
  }
  return creds;
}

function getSessionUser() {
  const local = localStorage.getItem(STORAGE_KEYS.SESSION);
  if (local) {
    try { return JSON.parse(local); } catch (e) {}
  }
  const session = sessionStorage.getItem(STORAGE_KEYS.SESSION);
  if (session) {
    try { return JSON.parse(session); } catch (e) {}
  }
  return null;
}

function saveSessionUser(user, remember = true) {
  const json = JSON.stringify(user);
  if (remember) {
    localStorage.setItem(STORAGE_KEYS.SESSION, json);
    sessionStorage.removeItem(STORAGE_KEYS.SESSION);
  } else {
    sessionStorage.setItem(STORAGE_KEYS.SESSION, json);
    localStorage.removeItem(STORAGE_KEYS.SESSION);
  }
}

function clearSessionUser() {
  localStorage.removeItem(STORAGE_KEYS.SESSION);
  sessionStorage.removeItem(STORAGE_KEYS.SESSION);
}

function initAuth() {
  const user = getSessionUser();
  const overlay = document.getElementById('loginOverlay');
  const userBadge = document.getElementById('userHeaderBadge');
  const nameEl = document.getElementById('headerUserName');
  const adminDesktopBtn = document.getElementById('navBtn-admin');
  const adminMobileBtn = document.getElementById('mobileNav-admin');
  const mobileNavGrid = document.getElementById('mobileNavGrid');
  const cloudSyncBadge = document.getElementById('cloudSyncHeaderBadge');

  if (user && user.username) {
    if (overlay) overlay.classList.add('hidden');
    if (userBadge) userBadge.classList.remove('hidden');

    const u = user.username.toLowerCase();
    const isOwner = u.includes('kancherla') || (user.role && user.role.includes('Owner'));
    const isManager = u.includes('greentrendskothapet') || (user.role && user.role.includes('Manager'));
    const displayName = isOwner ? 'Owner' : (isManager ? 'Manager' : (u.includes('@') ? (u.split('@')[0]) : u));

    if (nameEl) {
      nameEl.innerText = displayName;
      nameEl.title = `${user.username} (${user.role || (isManager ? 'Salon Manager' : 'Administrator')})`;
    }

    // Role-based Admin Tab Removal:
    // Manager has access to all salon operations (attendance, kiosk, payroll, incentives, petty cash, roster)
    // but Admin tab (credentials, firebase keys, commission rules) is strictly REMOVED for Manager
    if (isManager && !isOwner) {
      if (adminDesktopBtn) {
        adminDesktopBtn.classList.add('hidden');
        adminDesktopBtn.style.display = 'none';
      }
      if (adminMobileBtn) {
        adminMobileBtn.classList.add('hidden');
        adminMobileBtn.style.display = 'none';
      }
      if (mobileNavGrid) {
        mobileNavGrid.className = 'grid grid-cols-6 gap-0.5 text-center w-full max-w-lg mx-auto';
      }
      if (cloudSyncBadge) {
        cloudSyncBadge.onclick = null;
        cloudSyncBadge.style.cursor = 'default';
        cloudSyncBadge.title = 'Firebase Cloud Live (Protected)';
      }

      // If user is currently attempting to view #admin, redirect immediately to #attendance
      if (window.location.hash === '#admin') {
        window.location.hash = 'attendance';
      }
    } else {
      // Owner account: has full access to Admin tab
      if (adminDesktopBtn) {
        adminDesktopBtn.classList.remove('hidden');
        adminDesktopBtn.style.display = '';
      }
      if (adminMobileBtn) {
        adminMobileBtn.classList.remove('hidden');
        adminMobileBtn.style.display = '';
      }
      if (mobileNavGrid) {
        mobileNavGrid.className = 'grid grid-cols-7 gap-0.5 text-center w-full max-w-lg mx-auto';
      }
      if (cloudSyncBadge) {
        cloudSyncBadge.onclick = () => navigateTo('admin');
        cloudSyncBadge.style.cursor = 'pointer';
        cloudSyncBadge.title = 'Cloud Sync Status (Click to manage in Admin)';
      }
    }
  } else {
    if (overlay) overlay.classList.remove('hidden');
    if (userBadge) userBadge.classList.add('hidden');
  }
}

function handleLoginSubmit(e) {
  e.preventDefault();
  const uInput = document.getElementById('loginUsername');
  const pInput = document.getElementById('loginPassword');
  const rememberInput = document.getElementById('loginRememberMe');
  const errorAlert = document.getElementById('loginErrorAlert');
  const errorMsg = document.getElementById('loginErrorMsg');
  const loginCard = document.getElementById('loginCard');

  const username = (uInput?.value || '').trim().toLowerCase();
  const password = (pInput?.value || '').trim();
  const remember = rememberInput ? rememberInput.checked : true;

  const authCreds = getAuthCredentials();
  let matchedUser = null;

  // 1. Check accounts list
  if (authCreds.accounts && Array.isArray(authCreds.accounts)) {
    matchedUser = authCreds.accounts.find(
      acc => {
        const accUser = acc.username.toLowerCase();
        const matchesUser = (accUser === username) || 
          (accUser === 'kancherlavatsalsai@gmial.com' && username === 'kancherlavatsalsai@gmail.com') ||
          (accUser === 'kancherlavatsalsai@gmail.com' && username === 'kancherlavatsalsai@gmial.com') ||
          (accUser === 'greentrendskothapet@gmail.com' && username === 'greentrendskothapet@gmail.com');
        return matchesUser && acc.password === password;
      }
    );
  }

  // 2. Exact fallback for Manager account (Greentrendskothapet@gmail.com / Kothapet@9)
  if (!matchedUser && username === 'greentrendskothapet@gmail.com' && password === 'Kothapet@9') {
    matchedUser = { username: 'Greentrendskothapet@gmail.com', role: 'Salon Manager' };
  }

  // 3. Exact fallback for Owner account (kancherlavatsalsai@gmial.com / Vinayaka@9)
  if (!matchedUser && (username === 'kancherlavatsalsai@gmial.com' || username === 'kancherlavatsalsai@gmail.com') && password === 'Vinayaka@9') {
    matchedUser = { username: 'kancherlavatsalsai@gmial.com', role: 'Owner & Administrator' };
  }

  if (matchedUser) {
    if (errorAlert) errorAlert.classList.add('hidden');
    saveSessionUser(matchedUser, remember);

    initAuth();
    updateViewFromHash();

    showToast(`Welcome, ${matchedUser.username}!`);
  } else {
    if (errorAlert) {
      errorAlert.classList.remove('hidden');
      if (errorMsg) errorMsg.innerText = 'Incorrect username or password. Please try again.';
    }
    if (loginCard) {
      loginCard.classList.remove('shake-anim');
      void loginCard.offsetWidth; // trigger reflow
      loginCard.classList.add('shake-anim');
    }
  }
}

function logoutUser() {
  clearSessionUser();
  const overlay = document.getElementById('loginOverlay');
  const userBadge = document.getElementById('userHeaderBadge');
  const pInput = document.getElementById('loginPassword');

  if (pInput) pInput.value = '';
  if (overlay) overlay.classList.remove('hidden');
  if (userBadge) userBadge.classList.add('hidden');

  const errorAlert = document.getElementById('loginErrorAlert');
  if (errorAlert) errorAlert.classList.add('hidden');

  showToast('You have been logged out.');
}

function togglePasswordVisibility() {
  const pInput = document.getElementById('loginPassword');
  const eyeIcon = document.getElementById('passwordEyeIcon');
  if (!pInput || !eyeIcon) return;

  if (pInput.type === 'password') {
    pInput.type = 'text';
    eyeIcon.classList.remove('fa-eye-slash');
    eyeIcon.classList.add('fa-eye');
  } else {
    pInput.type = 'password';
    eyeIcon.classList.remove('fa-eye');
    eyeIcon.classList.add('fa-eye-slash');
  }
}

function saveAdminCredentials() {
  const ownerUserInput = document.getElementById('adminAuthUsername');
  const ownerPassInput = document.getElementById('adminAuthPassword');
  const managerUserInput = document.getElementById('adminManagerUsername');
  const managerPassInput = document.getElementById('adminManagerPassword');

  const authCreds = getAuthCredentials();
  if (!authCreds.accounts || !Array.isArray(authCreds.accounts)) {
    authCreds.accounts = [...DEFAULT_AUTH.accounts];
  }

  // 1. Update Owner account
  const newOwnerUser = (ownerUserInput?.value || 'kancherlavatsalsai@gmial.com').trim();
  const newOwnerPass = (ownerPassInput?.value || '').trim();
  let ownerAcc = authCreds.accounts.find(a => a.username.toLowerCase().includes('kancherla') || (a.role && a.role.includes('Owner')));
  if (!ownerAcc) {
    ownerAcc = { username: newOwnerUser, password: 'Vinayaka@9', role: 'Owner & Administrator' };
    authCreds.accounts.unshift(ownerAcc);
  }
  ownerAcc.username = newOwnerUser;
  if (newOwnerPass) {
    ownerAcc.password = newOwnerPass;
    authCreds.password = newOwnerPass;
  }
  authCreds.username = newOwnerUser;

  // 2. Update Manager account
  const newManagerUser = (managerUserInput?.value || 'Greentrendskothapet@gmail.com').trim();
  const newManagerPass = (managerPassInput?.value || '').trim();
  let managerAcc = authCreds.accounts.find(a => a.username.toLowerCase().includes('greentrendskothapet') || (a.role && a.role.includes('Manager')));
  if (!managerAcc) {
    managerAcc = { username: newManagerUser, password: 'Kothapet@9', role: 'Salon Manager' };
    authCreds.accounts.push(managerAcc);
  }
  managerAcc.username = newManagerUser;
  if (newManagerPass) {
    managerAcc.password = newManagerPass;
  }

  localStorage.setItem(STORAGE_KEYS.AUTH, JSON.stringify(authCreds));

  if (ownerPassInput) ownerPassInput.value = '';
  if (managerPassInput) managerPassInput.value = '';

  const sessionUser = getSessionUser();
  if (sessionUser) {
    const isOwner = sessionUser.username.toLowerCase().includes('kancherla');
    sessionUser.username = isOwner ? newOwnerUser : newManagerUser;
    saveSessionUser(sessionUser, true);
    const nameEl = document.getElementById('headerUserName');
    if (nameEl) nameEl.innerText = isOwner ? 'Owner' : 'Manager';
  }

  showToast('âœ“ Portal credentials updated successfully for Owner & Manager!');
}

// ==========================================
// 3. CORE CALCULATION ENGINES
// ==========================================

function convertToMinutes(h, m, ampm) {
  let hour = parseInt(h, 10) || 12;
  let minute = parseInt(m, 10) || 0;
  
  if (ampm === 'AM') {
    if (hour === 12) hour = 0;
  } else {
    if (hour !== 12) hour += 12;
  }
  return hour * 60 + minute;
}

function calculateShiftHoursParsed(inH, inM, inAmpm, outH, outM, outAmpm = 'PM', isHousekeeping = false) {
  if (typeof outAmpm === 'boolean') {
    isHousekeeping = outAmpm;
    outAmpm = 'PM';
  }
  const inMinutes = convertToMinutes(inH, inM, inAmpm || 'AM');
  const outMinutes = convertToMinutes(outH, outM, outAmpm || 'PM');

  let totalWorkedMinutes = outMinutes - inMinutes;
  if (totalWorkedMinutes < 0) {
    totalWorkedMinutes += 24 * 60;
  }

  const standardShiftMinutes = (salonRules.shiftHours || 9) * 60; // 540 mins
  const thresholdMinutes = salonRules.otGraceThresholdMinutes || 45; // 45 mins
  const ratePerHour = salonRules.otHourlyRate || 50;

  const hoursWorked = Math.floor(totalWorkedMinutes / 60);
  const minsWorked = totalWorkedMinutes % 60;
  const formattedDuration = `${hoursWorked}h ${minsWorked < 10 ? '0' : ''}${minsWorked}m`;

  let otMinutes = 0;
  let otHours = 0;
  let shortfallHours = 0;
  let otPay = 0;

  if (!isHousekeeping) {
    if (totalWorkedMinutes > standardShiftMinutes) {
      otMinutes = totalWorkedMinutes - standardShiftMinutes;
      if (otMinutes >= thresholdMinutes) {
        otHours = 1 + Math.floor((otMinutes - thresholdMinutes) / 60);
        otPay = otHours * ratePerHour;
      }
    } else if (totalWorkedMinutes < standardShiftMinutes) {
      const shortMinutes = standardShiftMinutes - totalWorkedMinutes;
      shortfallHours = Math.round(shortMinutes / 60);
    }
  }

  return {
    workedMinutes: totalWorkedMinutes,
    formattedDuration,
    otMinutes,
    otHours,
    shortfallHours,
    otPay
  };
}

function getDaysInMonth(year, month) {
  return new Date(year, month, 0).getDate();
}

function isWeekendDay(dateStr) {
  if (!dateStr) return false;
  const parts = dateStr.split('-');
  if (parts.length < 3) return false;
  const d = new Date(parseInt(parts[0], 10), parseInt(parts[1], 10) - 1, parseInt(parts[2], 10));
  const dow = d.getDay();
  return dow === 0 || dow === 6; // Sunday = 0, Saturday = 6
}

function getDayOfWeekName(dateStr) {
  if (!dateStr) return '';
  const parts = dateStr.split('-');
  const d = new Date(parseInt(parts[0], 10), parseInt(parts[1], 10) - 1, parseInt(parts[2], 10));
  return d.toLocaleString('en-US', { weekday: 'long' });
}

function getCalendarWeekKey(dateObj) {
  const d = new Date(Date.UTC(dateObj.getFullYear(), dateObj.getMonth(), dateObj.getDate()));
  const dayNum = d.getUTCDay() || 7;
  d.setUTCDate(d.getUTCDate() + 4 - dayNum);
  const yearStart = new Date(Date.UTC(d.getUTCFullYear(), 0, 1));
  const weekNo = Math.ceil((((d - yearStart) / 86400000) + 1) / 7);
  return `${d.getUTCFullYear()}-W${String(weekNo).padStart(2, '0')}`;
}

function calculateStaffMonthPayroll(staff, year, month) {
  const daysInMonth = getDaysInMonth(year, month);
  const perDaySalary = staff.baseSalary / daysInMonth;

  let presentDays = 0;
  let weeklyOffs = 0;
  let weekdayLeaves = 0;
  let weekendLeaves = 0;
  let excessWeekOffs = 0;
  let totalGrossOtHours = 0;
  let totalShortfallHours = 0;
  let totalServicesDone = 0;
  let totalProductsSold = 0;

  // Track weekly offs per Monday-Sunday calendar week
  // Salon Policy: Strictly 1 week off allowed per week, Monday to Friday ONLY!
  const weekOffsPerWeek = {};

  for (let d = 1; d <= daysInMonth; d++) {
    const dayStr = `${year}-${String(month).padStart(2, '0')}-${String(d).padStart(2, '0')}`;
    const dateObj = new Date(year, month - 1, d);
    const dayOfWeek = dateObj.getDay(); // 0 = Sunday, 6 = Saturday
    const isWeekend = (dayOfWeek === 0 || dayOfWeek === 6);
    const weekKey = getCalendarWeekKey(dateObj);

    const dayRecord = attendanceData[dayStr] && attendanceData[dayStr][staff.id];

    if (dayRecord) {
      if (dayRecord.status === 'Present') {
        presentDays++;
        if (!staff.isHousekeeping) {
          totalGrossOtHours += (dayRecord.otHours || 0);
          totalShortfallHours += (dayRecord.shortfallHours || 0);
        }
        totalServicesDone += Number(dayRecord.servicesDone || 0);
        totalProductsSold += Number(dayRecord.productsSold || 0);
      } else if (dayRecord.status === 'Weekly Off') {
        if (isWeekend) {
          // Weekend week off is STRICTLY prohibited by salon policy:
          // Marked as Weekend Leave with DOUBLE SALARY CUT (2x Daily Pay)!
          weekendLeaves++;
        } else {
          // Weekday week off: allowed max 1 per week (Mon to Fri)
          weekOffsPerWeek[weekKey] = (weekOffsPerWeek[weekKey] || 0) + 1;
          if (weekOffsPerWeek[weekKey] <= 1) {
            weeklyOffs++;
          } else {
            // Extra week off in same week converts to unpaid weekday leave
            excessWeekOffs++;
            weekdayLeaves++;
          }
        }
      } else if (dayRecord.status === 'Leave' || dayRecord.status === 'Absent') {
        if (isWeekend) {
          // Saturday & Sunday: Double Salary Cut (2x Daily Rate)!
          weekendLeaves++;
        } else {
          // Monday to Friday: Standard 1x Daily Rate Cut
          weekdayLeaves++;
        }
      }
    }
  }

  const unpaidLeaves = weekdayLeaves + weekendLeaves;
  // DOUBLE SALARY CUT: Weekend leaves (Saturday & Sunday) deduct 2x daily salary!
  // Weekday leaves deduct 1x daily salary!
  const weekdayCutAmount = weekdayLeaves * perDaySalary;
  const weekendCutAmount = weekendLeaves * 2 * perDaySalary;
  const leaveDeduction = weekdayCutAmount + weekendCutAmount;

  let netOtHours = 0;
  let netOtPay = 0;

  if (!staff.isHousekeeping) {
    netOtHours = Math.max(0, totalGrossOtHours - totalShortfallHours);
    netOtPay = netOtHours * (salonRules.otHourlyRate || 50);
  }

  let serviceCommission = 0;
  let productCommission = 0;

  if (staff.isManager) {
    const totalSalonServices = calculateTotalSalonServiceRevenue(year, month);
    const target = salonRules.salonMonthlyServiceTarget || 600000;
    if (totalSalonServices >= target) {
      serviceCommission = Math.round(totalSalonServices * ((staff.managerCommissionRate || 1) / 100));
    }
    productCommission = 0;
  } else if (!staff.isHousekeeping) {
    const target = staff.serviceTarget || (staff.baseSalary * 5);
    if (totalServicesDone >= target) {
      serviceCommission = Math.round(totalServicesDone * ((staff.serviceCommissionRate || 5) / 100));
    }

    if (staff.productTier2Min && totalProductsSold > staff.productTier2Min) {
      productCommission = Math.round(totalProductsSold * (staff.productTier2Rate / 100));
    } else if (staff.productTier1Min && totalProductsSold >= staff.productTier1Min) {
      productCommission = Math.round(totalProductsSold * (staff.productTier1Rate / 100));
    }
  }

  const totalIncentives = serviceCommission + productCommission;
  const foodAllowance = staff.foodAllowance || 0;

  const monthKey = `${year}-${String(month).padStart(2, '0')}`;
  const advanceTaken = (advanceData[monthKey] && advanceData[monthKey][staff.id]) || 0;

  const netPayable = Math.max(0, Math.round(
    staff.baseSalary + foodAllowance - leaveDeduction + netOtPay + totalIncentives - advanceTaken
  ));

  return {
    staff,
    daysInMonth,
    perDaySalary,
    presentDays,
    weeklyOffs,
    unpaidLeaves,
    weekdayLeaves,
    weekendLeaves,
    excessWeekOffs,
    weekdayCutAmount,
    weekendCutAmount,
    leaveDeduction,
    totalGrossOtHours,
    totalShortfallHours,
    netOtHours,
    netOtPay,
    totalServicesDone,
    totalProductsSold,
    serviceCommission,
    productCommission,
    totalIncentives,
    foodAllowance,
    advanceTaken,
    netPayable
  };
}

function calculateTotalSalonServiceRevenue(year, month) {
  const daysInMonth = getDaysInMonth(year, month);
  let grandTotal = 0;

  for (let d = 1; d <= daysInMonth; d++) {
    const dayStr = `${year}-${String(month).padStart(2, '0')}-${String(d).padStart(2, '0')}`;
    const dayRecords = attendanceData[dayStr];
    if (dayRecords) {
      staffList.forEach(s => {
        if (dayRecords[s.id] && dayRecords[s.id].servicesDone) {
          grandTotal += Number(dayRecords[s.id].servicesDone);
        }
      });
    }
  }
  return grandTotal;
}

// ==========================================
// 4. VIEW ROUTING & NAVIGATION
// ==========================================

function navigateTo(viewName) {
  const user = getSessionUser();
  const isManager = user && (user.username?.toLowerCase().includes('greentrendskothapet') || (user.role && user.role.includes('Manager')));
  const isOwner = user && (user.username?.toLowerCase().includes('kancherla') || (user.role && user.role.includes('Owner')));

  if (viewName === 'admin' && isManager && !isOwner) {
    showToast('Admin settings are restricted to Owner only.');
    window.location.hash = 'attendance';
    updateViewFromHash();
    return;
  }

  window.location.hash = viewName;
  updateViewFromHash();
}

function updateViewFromHash() {
  const hash = window.location.hash.replace('#', '') || 'attendance';
  const user = getSessionUser();
  const isManager = user && (user.username?.toLowerCase().includes('greentrendskothapet') || (user.role && user.role.includes('Manager')));
  const isOwner = user && (user.username?.toLowerCase().includes('kancherla') || (user.role && user.role.includes('Owner')));

  if (hash === 'admin' && isManager && !isOwner) {
    window.location.hash = 'attendance';
    showToast('Admin settings are restricted to Owner only.');
    return;
  }

  const views = ['attendance', 'kiosk', 'payroll', 'incentives', 'expenses', 'roster', 'admin'];

  views.forEach(v => {
    const el = document.getElementById(`view-${v}`);
    const navBtn = document.getElementById(`navBtn-${v}`);
    const mobBtn = document.getElementById(`mobileNav-${v}`);

    if (v === hash) {
      if (el) el.classList.remove('hidden');
      if (navBtn) {
        navBtn.classList.add('active');
        navBtn.classList.remove('text-gray-400');
        navBtn.classList.add('text-white');
      }
      if (mobBtn) {
        mobBtn.classList.add('text-[#ff2a85]', 'bg-[#ff2a85]/15');
        mobBtn.classList.remove('text-gray-400');
      }
    } else {
      if (el) el.classList.add('hidden');
      if (navBtn) {
        navBtn.classList.remove('active', 'text-white');
        navBtn.classList.add('text-gray-400');
      }
      if (mobBtn) {
        mobBtn.classList.remove('text-[#ff2a85]', 'bg-[#ff2a85]/15');
        mobBtn.classList.add('text-gray-400');
      }
    }
  });

  if (hash === 'attendance') renderDailyAttendance();
  if (hash === 'kiosk') renderKioskView();
  if (hash === 'payroll') renderMonthlyPayroll();
  if (hash === 'incentives') renderIncentivesView();
  if (hash === 'expenses') renderPettyCashLedger();
  if (hash === 'roster') renderRosterView();
  if (hash === 'admin') renderAdminView();
}

// ==========================================
// 5. VIEW 1: DAILY ATTENDANCE (TWO-TIER NO OVERFLOW)
// ==========================================

function renderDailyAttendance() {
  const container = document.getElementById('staffAttendanceContainer');
  if (!container) return;

  const dateKey = selectedDateStr;
  const isWeekend = isWeekendDay(dateKey);
  const dayName = getDayOfWeekName(dateKey);

  if (!attendanceData[dateKey]) {
    attendanceData[dateKey] = {};
  }

  let presentCount = 0;
  let weeklyOffCount = 0;
  let leaveCount = 0;
  let dailyOtHoursTotal = 0;
  let dailyOtPayTotal = 0;
  let dailyServicesTotal = 0;
  let dailyProductsTotal = 0;

  let html = '';

  if (isWeekend) {
    html += `
      <div class="p-4 rounded-2xl bg-gradient-to-r from-rose-950/40 via-[#180a14] to-amber-950/30 border border-rose-500/40 flex items-center justify-between gap-3 text-xs mb-3 shadow-lg">
        <div class="flex items-center gap-3">
          <span class="w-8 h-8 rounded-xl bg-rose-500/20 text-rose-400 flex items-center justify-center font-bold text-sm shrink-0">
            <i class="fa-solid fa-triangle-exclamation"></i>
          </span>
          <div>
            <strong class="text-white font-syne text-sm block">Weekend Attendance Rule (${dayName})</strong>
            <span class="text-rose-200">Mandatory Full Salon Presence • No Weekly Offs permitted • Any Leave incurs <strong class="text-white">DOUBLE SALARY CUT (2x Daily Pay)</strong></span>
          </div>
        </div>
        <span class="text-[10px] font-mono px-3 py-1 rounded-xl bg-rose-500/25 text-rose-300 font-bold border border-rose-500/40 shrink-0">
          2x Salary Cut Active
        </span>
      </div>
    `;
  }

  staffList.forEach((staff) => {
    if (!attendanceData[dateKey][staff.id]) {
      const isHk = !!staff.isHousekeeping;
      attendanceData[dateKey][staff.id] = {
        status: 'Present',
        inH: isHk ? 9 : 10,
        inM: 0,
        inAmpm: 'AM',
        outH: isHk ? 9 : 7,
        outM: 0,
        workedMinutes: isHk ? 720 : 540,
        otHours: 0,
        shortfallHours: 0,
        otPay: 0,
        servicesDone: 0,
        productsSold: 0
      };
    }

    const record = attendanceData[dateKey][staff.id];
    record.inH = record.inH || (staff.isHousekeeping ? 9 : 10);
    record.inM = record.inM !== undefined ? record.inM : 0;
    record.inAmpm = record.inAmpm || 'AM';
    record.outH = record.outH || (staff.isHousekeeping ? 9 : 7);
    record.outM = record.outM !== undefined ? record.outM : 0;
    record.outAmpm = record.outAmpm || 'PM';

    // Auto convert weekly off on weekend to leave
    if (isWeekend && record.status === 'Weekly Off') {
      record.status = 'Leave';
      record.weekendCut = true;
    }

    const shiftCalc = calculateShiftHoursParsed(record.inH, record.inM, record.inAmpm, record.outH, record.outM, record.outAmpm, staff.isHousekeeping);
    const perDayDaily = Math.round(staff.baseSalary / 30);
    const doubleCutVal = perDayDaily * 2;

    if (record.status === 'Present') {
      record.workedMinutes = shiftCalc.workedMinutes;
      if (record.isOtManual !== true) {
        record.otHours = shiftCalc.otHours;
        record.otPay = shiftCalc.otPay;
      } else {
        record.otPay = Math.round((record.otHours || 0) * (salonRules.otHourlyRate || 50));
      }
      record.shortfallHours = shiftCalc.shortfallHours;
      presentCount++;
      dailyOtHoursTotal += Number(record.otHours || 0);
      dailyOtPayTotal += Number(record.otPay || 0);
      dailyServicesTotal += Number(record.servicesDone || 0);
      dailyProductsTotal += Number(record.productsSold || 0);
    } else if (record.status === 'Weekly Off') {
      weeklyOffCount++;
    } else if (record.status === 'Leave' || record.status === 'Absent') {
      leaveCount++;
    }

    const isPresent = record.status === 'Present';
    const isOff = record.status === 'Weekly Off';
    const isLeave = record.status === 'Leave' || record.status === 'Absent';

    // Live Shift Progress & Overtime Calculations
    const targetHours = staff.isHousekeeping ? 12 : 9;
    const targetMinutes = targetHours * 60;
    const workedMin = isPresent ? (shiftCalc.workedMinutes || 0) : 0;
    const progressPct = isPresent ? Math.min(100, Math.max(0, Math.round((workedMin / targetMinutes) * 100))) : 0;
    const isShiftComplete = workedMin >= targetMinutes;
    const hasOt = (record.otHours || 0) > 0;

    let shiftTimerLabel = '';
    let shiftBadgeClass = '';
    if (isPresent) {
      if (hasOt) {
        shiftTimerLabel = `🔥 Standard ${targetHours}h Shift Done • +${record.otHours}h Overtime Active (+₹${record.otPay || 0})`;
        shiftBadgeClass = 'bg-amber-500/20 text-amber-300 border-amber-500/40';
      } else if (isShiftComplete) {
        shiftTimerLabel = `✓ Standard ${targetHours}h Shift Completed (${shiftCalc.formattedDuration})`;
        shiftBadgeClass = 'bg-emerald-500/20 text-emerald-400 border-emerald-500/40';
      } else {
        const remainingMin = targetMinutes - workedMin;
        const remH = Math.floor(remainingMin / 60);
        const remM = remainingMin % 60;
        shiftTimerLabel = `⏱️ ${shiftCalc.formattedDuration} elapsed • ${remH}h ${remM > 0 ? remM + 'm ' : ''}remaining in ${targetHours}h shift (${shiftCalc.shortfallHours}h Shortfall)`;
        shiftBadgeClass = 'bg-[#ff2a85]/15 text-[#ff7eb3] border-[#ff2a85]/30';
      }
    } else if (isOff) {
      shiftTimerLabel = `☕ On Scheduled Weekly Off`;
      shiftBadgeClass = 'bg-indigo-500/15 text-indigo-300 border-indigo-500/30';
    } else {
      if (isWeekend) {
        shiftTimerLabel = `🚨 Saturday/Sunday Mandatory Day Leave — DOUBLE SALARY CUT (-₹${doubleCutVal.toLocaleString('en-IN')})`;
        shiftBadgeClass = 'bg-rose-500/20 text-rose-300 border-rose-500/40 font-bold';
      } else {
        shiftTimerLabel = `❌ Full Day Leave (Daily Salary Deducted -₹${perDayDaily.toLocaleString('en-IN')})`;
        shiftBadgeClass = 'bg-rose-500/15 text-rose-300 border-rose-500/30';
      }
    }

    html += `
      <div class="staff-card bg-[#0d0d15] p-5 sm:p-6 rounded-3xl border border-[#1f1f30] shadow-xl transition-all space-y-4">
        
        <!-- TIER 1: Identity & Attendance Status Buttons -->
        <div class="flex flex-col md:flex-row md:items-center justify-between gap-3 border-b border-[#181826] pb-3.5">
          <!-- Staff Identity -->
          <div class="flex items-center gap-3.5">
            <div class="w-12 h-12 rounded-2xl bg-gradient-to-tr from-[#1a0d1e] to-[#26102a] border border-[#ff2a85]/40 flex items-center justify-center font-syne font-bold text-lg text-[#ff7eb3] shadow-md shadow-[#ff2a85]/15">
              ${staff.name.substring(0, 2).toUpperCase()}
            </div>
            <div>
              <div class="flex items-center gap-2">
                <h3 class="font-syne font-bold text-white text-base">${staff.name}</h3>
                ${staff.isManager ? '<span class="text-[9px] px-2 py-0.5 rounded-full bg-[#ff2a85]/20 text-[#ff7eb3] font-bold border border-[#ff2a85]/30">MANAGER</span>' : ''}
                ${staff.foodAllowance > 0 ? '<span class="text-[9px] px-2 py-0.5 rounded-full bg-emerald-500/15 text-emerald-400 font-bold border border-emerald-500/30">+₹1500 FOOD</span>' : ''}
              </div>
              <div class="flex items-center gap-2 mt-0.5 text-xs text-gray-400">
                <span>${staff.role}</span>
                <span class="text-gray-600">•</span>
                <span class="font-mono text-gray-300">Base: ₹${staff.baseSalary.toLocaleString('en-IN')}</span>
              </div>
              ${isWeekend && isLeave ? `
                <div class="mt-1">
                  <span class="text-[10px] font-bold text-rose-300 bg-rose-950/70 border border-rose-500/40 px-2 py-0.5 rounded-lg inline-flex items-center gap-1">
                    <i class="fa-solid fa-triangle-exclamation text-rose-400"></i> Double Salary Cut (2x Daily Pay: -₹${doubleCutVal.toLocaleString('en-IN')})
                  </span>
                </div>
              ` : ''}
            </div>
          </div>

          <!-- Tactile Status Buttons (NO HALF DAY) -->
          <div class="flex items-center gap-2 bg-[#08080f] p-1.5 rounded-2xl border border-[#1c1c2c] self-start md:self-auto">
            <button type="button" onclick="setAttendancePill('${staff.id}', 'Present')" 
              class="status-pill px-4 py-2 rounded-xl text-xs font-bold border ${isPresent ? 'active-present' : 'border-transparent text-gray-400 hover:text-white'}">
              🟢 Present
            </button>
            <button type="button" onclick="setAttendancePill('${staff.id}', 'Weekly Off')" 
              class="status-pill px-4 py-2 rounded-xl text-xs font-bold border ${isWeekend ? 'opacity-35 cursor-not-allowed border-dashed border-gray-700 text-gray-500' : (isOff ? 'active-off' : 'border-transparent text-gray-400 hover:text-white')}"
              ${isWeekend ? 'title="Policy Rule: Weekly Off is strictly allowed Monday to Friday only! Saturday & Sunday are mandatory."' : ''}>
              ☕ Weekly Off ${isWeekend ? '<span class="text-[9px] text-amber-400 block font-normal">(Mon-Fri Only)</span>' : ''}
            </button>
            <button type="button" onclick="setAttendancePill('${staff.id}', 'Leave')" 
              class="status-pill px-4 py-2 rounded-xl text-xs font-bold border ${isLeave ? 'active-leave' : 'border-transparent text-gray-400 hover:text-white'}">
              ${isWeekend ? '🚨 Leave (2x Cut)' : '❌ Leave (Cut)'}
            </button>
          </div>
        </div>

        <!-- TIER 2: Time Pickers, OT / Shortfall Feedback, and Sales Inputs (Never overflows) -->
        ${staff.isHousekeeping ? `
        <div class="flex flex-wrap items-center justify-between gap-4 pt-1 bg-[#090912] p-3.5 rounded-2xl border border-[#1b1b2a]">
          <div class="flex items-center gap-3">
            <span class="px-3.5 py-1.5 rounded-xl bg-purple-500/15 text-purple-300 font-bold border border-purple-500/30 flex items-center gap-2 text-xs font-mono">
              <i class="fa-solid fa-clock-rotate-left text-xs"></i>
              Fixed Daily Schedule: 9:00 AM – 9:00 PM (12 Hours)
            </span>
            <span class="text-xs text-gray-300 font-medium">
              ${isPresent ? '🟢 Working Standard 12h' : (isOff ? '☕ Weekly Off (Sundays)' : '❌ Full Day Leave (Salary Cut)')}
            </span>
          </div>
          <div class="flex items-center gap-2 text-[11px] text-gray-400">
            <i class="fa-solid fa-broom text-[#ff7eb3]"></i>
            <span>House Keeping Staff • ₹${staff.baseSalary.toLocaleString('en-IN')}/mo • Excluded from Roster Scanner</span>
          </div>
        </div>
        ` : `
        <div class="flex flex-wrap items-center justify-between gap-4 pt-1">
          
          <!-- Left: Check In & Check Out Controls -->
          <div class="flex flex-wrap items-center gap-3 ${isPresent ? '' : 'opacity-25 pointer-events-none'}">
            
            <!-- Check-In -->
            <div class="flex flex-col gap-1">
              <span class="text-[10px] uppercase font-bold text-gray-400 tracking-wider">Check In</span>
              <div class="flex items-center bg-[#08080f] border border-[#202032] rounded-2xl p-1.5 gap-1 focus-within:border-[#ff2a85]">
                <input type="number" min="1" max="12" value="${record.inH}" 
                  onfocus="this.select()" onclick="this.select()"
                  oninput="if(parseInt(this.value, 10) === 12) updateTimeDigit('${staff.id}', 'inH', 12)"
                  onchange="updateTimeDigit('${staff.id}', 'inH', this.value)"
                  class="w-9 text-center bg-[#131320] rounded-xl text-white font-mono font-bold text-xs py-1.5 focus:outline-none" title="Hour (1-12)">
                <span class="text-gray-500 font-bold">:</span>
                <input type="number" min="0" max="59" step="5" value="${record.inM < 10 ? '0' + record.inM : record.inM}" 
                  onfocus="this.select()" onclick="this.select()"
                  onchange="updateTimeDigit('${staff.id}', 'inM', this.value)"
                  class="w-10 text-center bg-[#131320] rounded-xl text-white font-mono font-bold text-xs py-1.5 focus:outline-none" title="Minute (00-59)">
                <button type="button" onclick="toggleAmPm('${staff.id}')" 
                  class="ampm-toggle px-2.5 py-1 rounded-xl text-[10px] font-bold ${record.inAmpm === 'AM' ? 'is-am' : 'is-pm'}">
                  ${record.inAmpm}
                </button>
              </div>
            </div>

            <!-- Arrow Divider -->
            <div class="pt-5 text-gray-600">
              <i class="fa-solid fa-arrow-right text-xs"></i>
            </div>

            <!-- Check-Out -->
            <div class="flex flex-col gap-1">
              <span class="text-[10px] uppercase font-bold text-gray-400 tracking-wider">Check Out (PM)</span>
              <div class="flex items-center bg-[#08080f] border border-[#202032] rounded-2xl p-1.5 gap-1 focus-within:border-[#ff2a85]">
                <input type="number" min="1" max="12" value="${record.outH}" 
                  onfocus="this.select()" onclick="this.select()"
                  onchange="updateTimeDigit('${staff.id}', 'outH', this.value)"
                  class="w-9 text-center bg-[#131320] rounded-xl text-white font-mono font-bold text-xs py-1.5 focus:outline-none" title="Hour (1-12)">
                <span class="text-gray-500 font-bold">:</span>
                <input type="number" min="0" max="59" step="5" value="${record.outM < 10 ? '0' + record.outM : record.outM}" 
                  onfocus="this.select()" onclick="this.select()"
                  onchange="updateTimeDigit('${staff.id}', 'outM', this.value)"
                  class="w-10 text-center bg-[#131320] rounded-xl text-white font-mono font-bold text-xs py-1.5 focus:outline-none" title="Minute (00-59)">
                <span class="px-2 py-1 rounded-xl text-[10px] font-bold font-mono bg-purple-500/20 text-purple-300 border border-purple-500/30">
                  PM
                </span>
              </div>
            </div>

            <!-- Overtime / Shortfall Result -->
            <div class="flex flex-col gap-1 pl-2">
              <span class="text-[10px] uppercase font-bold text-gray-400 tracking-wider">OT / Shortfall</span>
              <div class="flex items-center gap-1.5 py-1.5">
                ${isPresent ? `
                  <div class="flex items-center gap-1">
                    <button type="button" onclick="adjustManualOt('${staff.id}', -1)" 
                      class="w-6 h-6 rounded-lg bg-[#141424] hover:bg-[#1f1f33] text-gray-400 hover:text-white flex items-center justify-center text-xs font-bold font-mono transition-colors" title="Minus 1 Hour OT">
                      -
                    </button>
                    <span class="font-mono font-bold px-2 py-0.5 rounded-lg text-xs ${record.otHours > 0 ? 'bg-amber-500/20 text-amber-300 border border-amber-500/40' : 'bg-[#141424] text-gray-400'}">
                      ${record.otHours || 0}h
                    </span>
                    <button type="button" onclick="adjustManualOt('${staff.id}', 1)" 
                      class="w-6 h-6 rounded-lg bg-[#141424] hover:bg-[#1f1f33] text-gray-400 hover:text-white flex items-center justify-center text-xs font-bold font-mono transition-colors" title="Plus 1 Hour OT">
                      +
                    </button>
                  </div>
                  <div>
                    ${record.otHours > 0 ? 
                      `<span class="font-mono font-bold text-emerald-400 bg-emerald-500/15 border border-emerald-500/30 px-1.5 py-0.5 rounded-lg text-[11px]">+₹${record.otPay || 0}</span>` : 
                      (shiftCalc.shortfallHours > 0 ? 
                        `<span class="font-mono font-bold text-amber-400 bg-amber-500/15 border border-amber-500/30 px-1.5 py-0.5 rounded-lg text-[11px]">-${shiftCalc.shortfallHours}h Early Exit</span>` : 
                        `<span class="text-[11px] text-gray-500 font-mono">0 OT</span>`
                      )
                    }
                  </div>
                ` : `
                  <span class="text-xs text-gray-600 font-mono">--</span>
                `}
              </div>
            </div>
          </div>

          <!-- Right: Daily Services & Products Inputs (Fixed spacing, totally contained!) -->
          <div class="flex items-center gap-3 ${isPresent ? '' : 'opacity-35'}">
            <div>
              <label class="text-[10px] uppercase font-bold text-purple-400 block mb-1">Services (₹)</label>
              <input type="number" min="0" placeholder="0" value="${record.servicesDone || ''}" 
                onfocus="this.select()" onclick="this.select()"
                onchange="updateStaffSales('${staff.id}', 'servicesDone', this.value)"
                class="w-28 bg-[#08080f] border border-[#202032] text-white text-xs font-bold rounded-2xl px-3 py-2.5 focus:border-[#ff2a85]">
            </div>
            <div>
              <label class="text-[10px] uppercase font-bold text-pink-400 block mb-1">Products (₹)</label>
              <input type="number" min="0" placeholder="0" value="${record.productsSold || ''}" 
                onfocus="this.select()" onclick="this.select()"
                onchange="updateStaffSales('${staff.id}', 'productsSold', this.value)"
                class="w-28 bg-[#08080f] border border-[#202032] text-white text-xs font-bold rounded-2xl px-3 py-2.5 focus:border-[#ff2a85]">
            </div>
          </div>

        </div>
        `}

        <!-- Live Shift Progress & Overtime Timer Bar -->
        <div class="pt-3 border-t border-[#181826]/80">
          <div class="flex flex-wrap items-center justify-between gap-2 text-xs mb-1.5 font-medium">
            <div class="flex items-center gap-2">
              <span class="relative flex h-2 w-2">
                <span class="animate-ping absolute inline-flex h-full w-full rounded-full ${hasOt ? 'bg-amber-400 opacity-75' : (isShiftComplete ? 'bg-emerald-400 opacity-75' : 'bg-[#ff2a85] opacity-75')}"></span>
                <span class="relative inline-flex rounded-full h-2 w-2 ${hasOt ? 'bg-amber-400' : (isShiftComplete ? 'bg-emerald-400' : 'bg-[#ff2a85]')}"></span>
              </span>
              <span class="text-white font-bold text-[11px] sm:text-xs tracking-tight">${shiftTimerLabel}</span>
            </div>
            <div class="flex items-center gap-2 font-mono text-[11px]">
              ${isPresent ? `
                <span class="text-gray-400">${progressPct}% of shift</span>
                ${hasOt ? `<span class="px-2 py-0.5 rounded-full bg-amber-400/20 text-amber-300 font-extrabold border border-amber-400/40 animate-pulse text-[10px]">🔥 OT ACTIVE</span>` : ''}
              ` : `
                <span class="px-2 py-0.5 rounded-full text-[10px] font-bold border ${shiftBadgeClass}">${record.status}</span>
              `}
            </div>
          </div>
          ${isPresent ? `
          <div class="w-full h-1.5 bg-[#12121e] rounded-full overflow-hidden p-0.5 border border-[#1f1f32]">
            <div class="h-full rounded-full transition-all duration-500 ${hasOt ? 'bg-gradient-to-r from-emerald-500 via-[#ff2a85] to-amber-400' : (isShiftComplete ? 'bg-gradient-to-r from-emerald-500 to-teal-400' : 'bg-gradient-to-r from-[#ff2a85] via-purple-500 to-[#ff7eb3]')}" style="width: ${progressPct}%"></div>
          </div>
          ` : ''}
        </div>

      </div>
    `;
  });

  container.innerHTML = html;

  document.getElementById('kpiPresentCount').innerText = presentCount;
  document.getElementById('kpiWeeklyOffCount').innerText = weeklyOffCount;
  document.getElementById('kpiLeaveCount').innerText = leaveCount;
  document.getElementById('kpiOvertimePay').innerText = `₹${dailyOtPayTotal.toLocaleString('en-IN')}`;
  document.getElementById('kpiOvertimeHours').innerText = `${dailyOtHoursTotal} hrs logged`;
  document.getElementById('kpiServicesTotal').innerText = `₹${dailyServicesTotal.toLocaleString('en-IN')}`;
  document.getElementById('kpiProductsTotal').innerText = `₹${dailyProductsTotal.toLocaleString('en-IN')}`;

  saveAttendanceData();
}

function setAttendancePill(staffId, newStatus) {
  const dateKey = selectedDateStr;
  const isWeekend = isWeekendDay(dateKey);

  if (newStatus === 'Weekly Off' && isWeekend) {
    showToast("⚠️ Policy Alert: Weekly Off is only allowed Monday to Friday (1/week)! Saturday & Sunday are mandatory — absent staff is marked as Leave with Double Salary Cut (2x).", 4500);
    newStatus = 'Leave';
  }

  if (!attendanceData[dateKey]) attendanceData[dateKey] = {};
  if (!attendanceData[dateKey][staffId]) attendanceData[dateKey][staffId] = {};

  attendanceData[dateKey][staffId].status = newStatus;
  if (isWeekend && newStatus === 'Leave') {
    attendanceData[dateKey][staffId].weekendCut = true;
  }
  saveAttendanceData();
  renderDailyAttendance();
  showToast(`${getStaffName(staffId)} set to ${newStatus}${isWeekend && newStatus === 'Leave' ? ' (Double Cut 2x)' : ''}`);
}

function updateTimeDigit(staffId, field, val) {
  const dateKey = selectedDateStr;
  if (!attendanceData[dateKey]) attendanceData[dateKey] = {};
  if (!attendanceData[dateKey][staffId]) {
    attendanceData[dateKey][staffId] = { status: 'Present', inH: 10, inM: 0, inAmpm: 'AM', outH: 7, outM: 0 };
  }

  const intVal = parseInt(val, 10) || 0;
  attendanceData[dateKey][staffId][field] = intVal;

  // Whenever user enters 12 in the check-in slot, automatically set to PM!
  if (field === 'inH') {
    if (intVal === 12 || intVal === 1 || intVal === 2 || intVal === 3) {
      attendanceData[dateKey][staffId].inAmpm = 'PM';
    } else if (intVal >= 7 && intVal <= 11) {
      attendanceData[dateKey][staffId].inAmpm = 'AM';
    }
    attendanceData[dateKey][staffId].isOtManual = false;
  }
  if (field === 'outH' || field === 'inM' || field === 'outM') {
    attendanceData[dateKey][staffId].isOtManual = false;
  }

  saveAttendanceData();
  renderDailyAttendance();
}

function updateStaffOtHours(staffId, val) {
  const dateKey = selectedDateStr;
  if (!attendanceData[dateKey]) attendanceData[dateKey] = {};
  if (!attendanceData[dateKey][staffId]) {
    attendanceData[dateKey][staffId] = { status: 'Present', inH: 10, inM: 0, inAmpm: 'AM', outH: 7, outM: 0 };
  }

  const otVal = Math.max(0, parseFloat(val) || 0);
  const otRate = salonRules.otHourlyRate || 50;
  attendanceData[dateKey][staffId].otHours = otVal;
  attendanceData[dateKey][staffId].otPay = Math.round(otVal * otRate);
  attendanceData[dateKey][staffId].isOtManual = true;

  saveAttendanceData();
  renderDailyAttendance();
  showToast(`${getStaffName(staffId)} OT set to ${otVal} hrs (+â‚¹${attendanceData[dateKey][staffId].otPay})`);
}

function toggleAmPm(staffId) {
  const dateKey = selectedDateStr;
  if (!attendanceData[dateKey]) attendanceData[dateKey] = {};
  if (!attendanceData[dateKey][staffId]) {
    attendanceData[dateKey][staffId] = { status: 'Present', inH: 10, inM: 0, inAmpm: 'AM', outH: 7, outM: 0 };
  }

  const current = attendanceData[dateKey][staffId].inAmpm || 'AM';
  attendanceData[dateKey][staffId].inAmpm = (current === 'AM' ? 'PM' : 'AM');
  saveAttendanceData();
  renderDailyAttendance();
  showToast(`Check-in changed to ${attendanceData[dateKey][staffId].inAmpm}`);
}

function updateStaffSales(staffId, field, value) {
  const dateKey = selectedDateStr;
  if (!attendanceData[dateKey]) attendanceData[dateKey] = {};
  if (!attendanceData[dateKey][staffId]) attendanceData[dateKey][staffId] = {};

  attendanceData[dateKey][staffId][field] = parseFloat(value) || 0;
  saveAttendanceData();
  renderDailyAttendance();
}

function bulkMarkAllPresent() {
  const dateKey = selectedDateStr;
  if (!attendanceData[dateKey]) attendanceData[dateKey] = {};

  staffList.forEach(s => {
    attendanceData[dateKey][s.id] = {
      status: 'Present',
      inH: 10, inM: 0, inAmpm: 'AM',
      outH: 7, outM: 0,
      workedMinutes: 540,
      otHours: 0,
      shortfallHours: 0,
      otPay: 0,
      servicesDone: attendanceData[dateKey][s.id]?.servicesDone || 0,
      productsSold: attendanceData[dateKey][s.id]?.productsSold || 0
    };
  });

  saveAttendanceData();
  renderDailyAttendance();
  showToast('All 8 staff marked Present with standard 9h shift (10:00 AM - 7:00 PM)!');
}

function onDateChanged() {
  const input = document.getElementById('selectedDateInput');
  if (input && input.value) {
    selectedDateStr = input.value;
    renderDailyAttendance();
  }
}

function shiftDate(deltaDays) {
  const [y, m, d] = selectedDateStr.split('-').map(Number);
  const dateObj = new Date(y, m - 1, d);
  dateObj.setDate(dateObj.getDate() + deltaDays);
  selectedDateStr = formatDateKey(dateObj);
  
  const input = document.getElementById('selectedDateInput');
  if (input) input.value = selectedDateStr;
  renderDailyAttendance();

  const dayLabel = dateObj.toLocaleDateString('en-IN', { weekday: 'short', month: 'short', day: 'numeric' });
  showToast(`ðŸ“… Date: ${dayLabel}`);
}

function setTodayDate() {
  currentDate = new Date();
  selectedDateStr = formatDateKey(currentDate);
  const input = document.getElementById('selectedDateInput');
  if (input) input.value = selectedDateStr;
  renderDailyAttendance();
  showToast('ðŸ“… Switched to Today');
}

// ==========================================
// 6. VIEW 2: MONTHLY PAYROLL (PURE NUMBER IN LEAVES CUT)
// ==========================================

function renderMonthlyPayroll() {
  const tableBody = document.getElementById('payrollTableBody');
  const tableFoot = document.getElementById('payrollTableFoot');
  if (!tableBody || !tableFoot) return;

  const [yearStr, monthStr] = selectedMonthStr.split('-');
  const year = parseInt(yearStr, 10);
  const month = parseInt(monthStr, 10);
  const daysInMonth = getDaysInMonth(year, month);

  const monthName = new Date(year, month - 1, 1).toLocaleString('default', { month: 'long', year: 'numeric' });
  document.getElementById('payrollMonthBadge').innerText = monthName;

  let totalGrossBase = 0;
  let totalFoodAllowances = 0;
  let totalDeductions = 0;
  let totalNetOtPay = 0;
  let totalIncentives = 0;
  let totalAdvances = 0;
  let totalNetPayout = 0;
  let totalWeekendLeavesCount = 0;
  let totalWeekendDeductionSum = 0;

  let rowsHtml = '';

  staffList.forEach((staff) => {
    const p = calculateStaffMonthPayroll(staff, year, month);

    totalGrossBase += staff.baseSalary;
    totalFoodAllowances += p.foodAllowance;
    totalDeductions += p.leaveDeduction;
    totalNetOtPay += p.netOtPay;
    totalIncentives += p.totalIncentives;
    totalAdvances += (p.advanceTaken || 0);
    totalNetPayout += p.netPayable;
    totalWeekendLeavesCount += (p.weekendLeaves || 0);
    totalWeekendDeductionSum += (p.weekendCutAmount || 0);

    rowsHtml += `
      <tr class="hover:bg-[#12121e] transition-colors border-b border-[#181826]">
        <td class="py-3 px-3 whitespace-nowrap sticky-first-col">
          <div class="flex items-center gap-1.5">
            <span class="font-syne font-bold text-white text-xs sm:text-sm">${staff.name}</span>
            ${staff.isManager ? '<span class="text-[9px] px-1.5 py-0.2 rounded-full bg-[#ff2a85]/20 text-[#ff7eb3] font-bold">MGR</span>' : ''}
          </div>
          <div class="text-[10px] text-gray-400">${staff.role}</div>
        </td>

        <td class="py-3 px-2 font-mono font-semibold text-white whitespace-nowrap">
          ₹${staff.baseSalary.toLocaleString('en-IN')}
        </td>

        <td class="py-3 px-2 font-mono whitespace-nowrap">
          ${staff.foodAllowance > 0 ? 
            `<span class="text-emerald-400 font-semibold">+₹${staff.foodAllowance.toLocaleString('en-IN')}</span>` : 
            `<span class="text-gray-600">₹0</span>`
          }
        </td>

        <td class="py-3 px-2 font-mono text-gray-300 whitespace-nowrap">
          <div>₹${Math.round(p.perDaySalary)}</div>
          <span class="text-[9px] text-gray-500 font-sans">÷ ${daysInMonth}d</span>
        </td>

        <td class="py-3 px-2 text-center whitespace-nowrap">
          <div class="inline-flex items-center gap-1 font-mono text-xs">
            <span class="px-1.5 py-0.5 rounded-md bg-emerald-500/15 text-emerald-400 font-bold">${p.presentDays}P</span>
            <span class="px-1.5 py-0.5 rounded-md bg-indigo-500/15 text-indigo-400 font-bold">${p.weeklyOffs}WO</span>
          </div>
        </td>

        <!-- STRICTLY PURE NUMBER IN LEAVES CUT: Plus Weekend 2x cut tag if applicable -->
        <td class="py-3 px-2 text-center whitespace-nowrap">
          ${p.unpaidLeaves > 0 ? 
            `<div class="inline-flex flex-col items-center">
              <span class="inline-block px-2.5 py-0.5 rounded-lg bg-rose-500/20 text-rose-400 font-mono font-extrabold text-xs">${p.unpaidLeaves}</span>
              ${p.weekendLeaves > 0 ? `<span class="text-[9px] text-rose-300 font-bold block mt-0.5 tracking-tight font-sans">incl. ${p.weekendLeaves} Sat/Sun (2x)</span>` : ''}
            </div>` : 
            `<span class="text-gray-600 font-mono text-xs">0</span>`
          }
        </td>

        <td class="py-3 px-2 font-mono whitespace-nowrap">
          ${p.leaveDeduction > 0 ? 
            `<div>
              <span class="text-rose-400 font-bold">-₹${Math.round(p.leaveDeduction).toLocaleString('en-IN')}</span>
              ${p.weekendLeaves > 0 ? `<span class="text-[9px] text-rose-400/80 block font-sans">(-₹${Math.round(p.weekendCutAmount)} 2x)</span>` : ''}
            </div>` : 
            `<span class="text-gray-600">₹0</span>`
          }
        </td>

        <td class="py-3 px-2 font-mono text-center whitespace-nowrap">
          ${staff.isHousekeeping ? 
            `<span class="text-gray-600">0h</span>` : 
            `<span class="text-white font-bold">${p.netOtHours}h</span>
             ${p.totalShortfallHours > 0 ? `<span class="text-[9px] text-amber-400 block font-sans">-${p.totalShortfallHours}h</span>` : ''}`
          }
        </td>

        <td class="py-3 px-2 font-mono whitespace-nowrap">
          ${p.netOtPay > 0 ? 
            `<span class="text-[#ff7eb3] font-bold">+₹${p.netOtPay.toLocaleString('en-IN')}</span>` : 
            `<span class="text-gray-600">₹0</span>`
          }
        </td>

        <td class="py-3 px-2 font-mono whitespace-nowrap">
          ${p.totalIncentives > 0 ? 
            `<span class="text-purple-400 font-bold">+₹${p.totalIncentives.toLocaleString('en-IN')}</span>` : 
            `<span class="text-gray-600">₹0</span>`
          }
        </td>

        <!-- Salary Advance / Loan Input: Fixed strictly on one line, no wrapping -->
        <td class="py-3 px-2 font-mono text-center whitespace-nowrap">
          <div class="inline-flex items-center gap-1 justify-center whitespace-nowrap">
            <span class="text-rose-400 font-bold text-xs shrink-0 select-none whitespace-nowrap">-₹</span>
            <input type="number" min="0" step="500" value="${p.advanceTaken > 0 ? p.advanceTaken : ''}" placeholder="0"
              onchange="updateStaffAdvance('${staff.id}', this.value)"
              class="w-16 bg-[#161626] border border-[#27273d] focus:border-[#ff2a85] rounded-lg px-1.5 py-1 text-rose-300 font-mono text-xs font-bold text-right outline-none transition-colors"
              title="Enter mid-month salary advance or loan taken">
          </div>
        </td>

        <td class="py-3 px-3 font-mono font-extrabold text-sm text-[#ff2a85] text-right whitespace-nowrap">
          ₹${p.netPayable.toLocaleString('en-IN')}
        </td>

        <td class="py-3 px-3 text-center whitespace-nowrap">
          <button onclick="openPaySlipModal('${staff.id}')" 
            class="px-2.5 py-1 rounded-xl text-xs font-bold bg-[#141420] hover:bg-[#ff2a85] text-gray-300 hover:text-white transition-all border border-[#222234] hover:border-[#ff2a85] inline-flex items-center justify-center gap-1 shadow-sm">
            <i class="fa-solid fa-receipt text-[10px]"></i>
            <span>Slip</span>
          </button>
        </td>
      </tr>
    `;
  });

  tableBody.innerHTML = rowsHtml;

  tableFoot.innerHTML = `
    <tr>
      <td class="py-3 px-3 uppercase text-[11px] tracking-wider text-gray-300 whitespace-nowrap sticky-first-col">Total Salon Payroll</td>
      <td class="py-3 px-2 font-mono text-white whitespace-nowrap">₹${totalGrossBase.toLocaleString('en-IN')}</td>
      <td class="py-3 px-2 font-mono text-emerald-400 whitespace-nowrap">+₹${totalFoodAllowances.toLocaleString('en-IN')}</td>
      <td class="py-3 px-2 text-gray-500 text-[10px] font-sans whitespace-nowrap">÷ ${daysInMonth}d</td>
      <td class="py-3 px-2 text-center text-gray-400 whitespace-nowrap">--</td>
      <td class="py-3 px-2 text-center text-gray-400 whitespace-nowrap">--</td>
      <td class="py-3 px-2 font-mono text-rose-400 whitespace-nowrap">-₹${Math.round(totalDeductions).toLocaleString('en-IN')}</td>
      <td class="py-3 px-2 text-center text-gray-400 whitespace-nowrap">--</td>
      <td class="py-3 px-2 font-mono text-[#ff7eb3] whitespace-nowrap">+₹${totalNetOtPay.toLocaleString('en-IN')}</td>
      <td class="py-3 px-2 font-mono text-purple-400 whitespace-nowrap">+₹${totalIncentives.toLocaleString('en-IN')}</td>
      <td class="py-3 px-2 font-mono text-rose-400 font-bold text-center whitespace-nowrap">-₹${totalAdvances.toLocaleString('en-IN')}</td>
      <td class="py-3 px-3 font-mono font-extrabold text-base text-[#ff2a85] text-right whitespace-nowrap">₹${totalNetPayout.toLocaleString('en-IN')}</td>
      <td class="py-3 px-3 text-center text-gray-500 whitespace-nowrap">--</td>
    </tr>
  `;

  document.getElementById('summaryGrossBase').innerText = `₹${(totalGrossBase + totalFoodAllowances).toLocaleString('en-IN')}`;
  document.getElementById('summaryDeductions').innerText = `-₹${Math.round(totalDeductions + totalAdvances).toLocaleString('en-IN')}`;
  document.getElementById('summaryAdditions').innerText = `+₹${(totalNetOtPay + totalIncentives).toLocaleString('en-IN')}`;
  document.getElementById('summaryNetPayout').innerText = `₹${totalNetPayout.toLocaleString('en-IN')}`;
}

function onPayrollMonthChanged() {
  const input = document.getElementById('selectedMonthInput');
  if (input && input.value) {
    selectedMonthStr = input.value;
    renderMonthlyPayroll();
  }
}

function exportPayrollCSV() {
  const [yearStr, monthStr] = selectedMonthStr.split('-');
  const year = parseInt(yearStr, 10);
  const month = parseInt(monthStr, 10);
  const daysInMonth = getDaysInMonth(year, month);

  let csvContent = 'Staff Name,Role,Base Salary,Food Allowance,Per Day Rate,Present Days,Weekly Offs,Weekday Leaves,Weekend Leaves (2x Cut),Total Leave Deduction,Net OT Hours,OT Pay,Services Done,Products Sold,Incentives,Salary Advance,Net Payable Salary\n';

  staffList.forEach(staff => {
    const p = calculateStaffMonthPayroll(staff, year, month);
    csvContent += `"${staff.name}","${staff.role}",${staff.baseSalary},${p.foodAllowance},${p.perDaySalary.toFixed(2)},${p.presentDays},${p.weeklyOffs},${p.weekdayLeaves},${p.weekendLeaves},${Math.round(p.leaveDeduction)},${p.netOtHours},${p.netOtPay},${p.totalServicesDone},${p.totalProductsSold},${p.totalIncentives},${p.advanceTaken || 0},${p.netPayable}\n`;
  });

  const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
  const url = URL.createObjectURL(blob);
  const link = document.createElement('a');
  link.setAttribute('href', url);
  link.setAttribute('download', `Green_Trends_Kothapet_Payroll_${selectedMonthStr}.csv`);
  document.body.appendChild(link);
  link.click();
  document.body.removeChild(link);
  showToast(`Exported payroll CSV for ${selectedMonthStr}`);
}

function renderIncentivesView() {
  const container = document.getElementById('incentivesProgressContainer');
  const summaryBox = document.getElementById('incentivesSummaryHighlights');
  const leaderboardContainer = document.getElementById('stylistLeaderboardContainer');
  if (!container) return;

  const [yearStr, monthStr] = selectedMonthStr.split('-');
  const year = parseInt(yearStr, 10);
  const month = parseInt(monthStr, 10);

  // 1. Calculate overall salon statistics for this month
  const totalSalonRev = calculateTotalSalonServiceRevenue(year, month);
  const salonTarget = salonRules.salonMonthlyServiceTarget || 600000;
  const managerRate = salonRules.managerCommissionRate || 1;
  const managerAchieved = totalSalonRev >= salonTarget;
  const managerCommissionEarned = managerAchieved ? Math.round(totalSalonRev * (managerRate / 100)) : 0;

  let totalStylistCommissions = 0;
  let activeCommissionEarners = 0;
  let topServiceStylist = { name: 'None', amount: 0, commission: 0 };
  let topProductStylist = { name: 'None', amount: 0, commission: 0 };

  const stylistStats = [];
  let maxRetailAmount = 0;
  let retailChampionStaffId = null;

  staffList.forEach(staff => {
    if (staff.isManager || staff.isHousekeeping) return;
    const p = calculateStaffMonthPayroll(staff, year, month);
    totalStylistCommissions += p.totalIncentives;
    if (p.totalIncentives > 0) activeCommissionEarners++;

    if (p.totalServicesDone > topServiceStylist.amount) {
      topServiceStylist = { name: staff.name, amount: p.totalServicesDone, commission: p.serviceCommission };
    }
    if (p.totalProductsSold > topProductStylist.amount) {
      topProductStylist = { name: staff.name, amount: p.totalProductsSold, commission: p.productCommission };
    }

    if (p.totalProductsSold > maxRetailAmount) {
      maxRetailAmount = p.totalProductsSold;
      retailChampionStaffId = staff.id;
    }

    const servTarget = staff.serviceTarget || (staff.baseSalary * 5);
    const servPercent = Math.min(100, Math.round((p.totalServicesDone / servTarget) * 100));
    const servAchieved = p.totalServicesDone >= servTarget;

    stylistStats.push({
      staff,
      payroll: p,
      servicesDone: p.totalServicesDone,
      productsSold: p.totalProductsSold,
      serviceCommission: p.serviceCommission,
      productCommission: p.productCommission,
      totalIncentives: p.totalIncentives,
      target: servTarget,
      targetPercent: servPercent,
      targetAchieved: servAchieved
    });
  });

  // Rank stylists descending by services done, then products sold
  stylistStats.sort((a, b) => b.servicesDone - a.servicesDone || b.productsSold - a.productsSold);

  // Map each stylist's rank and badge metadata
  const stylistRankMeta = {};
  stylistStats.forEach((item, index) => {
    const rank = index + 1;
    const badges = [];

    if (rank === 1) {
      badges.push({ icon: 'ðŸ‘‘', label: '#1 Service Champion', border: 'border-amber-400/50 bg-amber-400/15 text-amber-300' });
    } else if (rank === 2) {
      badges.push({ icon: 'ðŸ¥ˆ', label: '#2 Silver Stylist', border: 'border-slate-300/40 bg-slate-400/15 text-slate-200' });
    } else if (rank === 3) {
      badges.push({ icon: 'ðŸ¥‰', label: '#3 Bronze Stylist', border: 'border-amber-700/40 bg-amber-700/15 text-orange-300' });
    }

    if (item.staff.id === retailChampionStaffId && item.productsSold > 0) {
      badges.push({ icon: 'ðŸ›ï¸', label: 'Retail Champion', border: 'border-pink-500/40 bg-pink-500/15 text-pink-300' });
    }

    if (item.targetAchieved) {
      badges.push({ icon: 'ðŸŽ¯', label: 'Target 100% Unlocked', border: 'border-emerald-500/40 bg-emerald-500/15 text-emerald-400' });
    } else if (item.targetPercent >= 75) {
      badges.push({ icon: 'ðŸš€', label: '75%+ Target Club', border: 'border-purple-500/40 bg-purple-500/15 text-purple-300' });
    }

    if (item.totalIncentives > 0) {
      badges.push({ icon: 'ðŸ’°', label: 'Incentives Active', border: 'border-[#ff2a85]/40 bg-[#ff2a85]/15 text-[#ff7eb3]' });
    }

    stylistRankMeta[item.staff.id] = {
      rank,
      badges,
      data: item
    };
  });

  // Render Top Highlights Summary Cards
  if (summaryBox) {
    const targetPct = Math.min(100, Math.round((totalSalonRev / salonTarget) * 100));
    summaryBox.innerHTML = `
      <!-- Card 1: Salon Target & Kalyan Manager 1% -->
      <div class="bg-[#0e0e18] p-4 rounded-2xl border border-[#232338] shadow-lg relative overflow-hidden">
        <div class="flex items-center justify-between text-xs text-gray-400 font-semibold">
          <span>Salon Target (Kalyan 1%)</span>
          <span class="px-2 py-0.5 rounded-full ${managerAchieved ? 'bg-emerald-500/20 text-emerald-400' : 'bg-purple-500/20 text-purple-300'} font-bold font-mono text-[10px]">
            ${targetPct}%
          </span>
        </div>
        <div class="mt-2">
          <div class="flex items-baseline justify-between">
            <span class="text-xl font-black font-heading text-white">â‚¹${totalSalonRev.toLocaleString('en-IN')}</span>
            <span class="text-[10px] text-gray-500 font-mono">/ â‚¹${salonTarget.toLocaleString('en-IN')}</span>
          </div>
          <div class="w-full bg-[#161628] h-1.5 rounded-full overflow-hidden mt-2">
            <div class="h-full ${managerAchieved ? 'bg-gradient-to-r from-purple-500 to-emerald-400' : 'bg-[#ff2a85]'} transition-all" style="width: ${targetPct}%"></div>
          </div>
          <span class="text-[10px] mt-1.5 block ${managerAchieved ? 'text-emerald-400 font-bold' : 'text-gray-400'}">
            ${managerAchieved ? `âœ“ Target Met! Kalyan 1% = +â‚¹${managerCommissionEarned.toLocaleString('en-IN')}` : `â‚¹${Math.max(0, salonTarget - totalSalonRev).toLocaleString('en-IN')} left to unlock 1%`}
          </span>
        </div>
      </div>

      <!-- Card 2: Total Stylist Commission Pool -->
      <div class="bg-[#0e0e18] p-4 rounded-2xl border border-[#232338] shadow-lg">
        <div class="flex items-center justify-between text-xs text-gray-400 font-semibold">
          <span>Total Commission Pool</span>
          <i class="fa-solid fa-coins text-[#ff7eb3] text-xs"></i>
        </div>
        <div class="mt-2">
          <span class="text-xl font-black font-heading text-[#ff7eb3]">â‚¹${totalStylistCommissions.toLocaleString('en-IN')}</span>
          <span class="text-[10px] text-gray-400 block mt-1">
            ${activeCommissionEarners} of ${staffList.filter(s => !s.isManager && !s.isHousekeeping).length} stylists earned incentives
          </span>
        </div>
      </div>

      <!-- Card 3: Top Service Performer -->
      <div class="bg-[#0e0e18] p-4 rounded-2xl border border-[#232338] shadow-lg">
        <div class="flex items-center justify-between text-xs text-gray-400 font-semibold">
          <span>Top Service Performer</span>
          <i class="fa-solid fa-trophy text-amber-400 text-xs"></i>
        </div>
        <div class="mt-2">
          <div class="flex items-center justify-between">
            <span class="text-base font-bold font-heading text-white truncate">${topServiceStylist.name}</span>
            <span class="text-xs font-mono font-bold text-purple-400">â‚¹${topServiceStylist.amount.toLocaleString('en-IN')}</span>
          </div>
          <span class="text-[10px] text-emerald-400 font-bold block mt-1">
            ${topServiceStylist.commission > 0 ? `+â‚¹${topServiceStylist.commission.toLocaleString('en-IN')} commission (5%)` : 'Target in progress'}
          </span>
        </div>
      </div>

      <!-- Card 4: Top Product Seller -->
      <div class="bg-[#0e0e18] p-4 rounded-2xl border border-[#232338] shadow-lg">
        <div class="flex items-center justify-between text-xs text-gray-400 font-semibold">
          <span>Top Product Retailer</span>
          <i class="fa-solid fa-bottle-droplet text-pink-400 text-xs"></i>
        </div>
        <div class="mt-2">
          <div class="flex items-center justify-between">
            <span class="text-base font-bold font-heading text-white truncate">${topProductStylist.name}</span>
            <span class="text-xs font-mono font-bold text-pink-400">â‚¹${topProductStylist.amount.toLocaleString('en-IN')}</span>
          </div>
          <span class="text-[10px] text-[#ff7eb3] font-bold block mt-1">
            ${topProductStylist.commission > 0 ? `+â‚¹${topProductStylist.commission.toLocaleString('en-IN')} commission` : 'Below min tier'}
          </span>
        </div>
      </div>
    `;
  }

  // 2. Render Live Stylist Leaderboard & Podium Showcase
  if (leaderboardContainer) {
    const top3 = stylistStats.slice(0, 3);
    const rest = stylistStats.slice(3);

    let podiumCardsHtml = '';
    top3.forEach((item, idx) => {
      const rank = idx + 1;
      const rankMeta = stylistRankMeta[item.staff.id];
      const isGold = rank === 1;
      const isSilver = rank === 2;
      const isBronze = rank === 3;

      const rankBadgeColor = isGold 
        ? 'from-amber-400 to-yellow-500 text-black shadow-amber-400/40' 
        : (isSilver 
          ? 'from-slate-200 to-slate-400 text-black shadow-slate-300/30' 
          : 'from-amber-700 to-orange-700 text-white shadow-orange-700/30');

      const cardBorder = isGold 
        ? 'border-amber-400/50 shadow-amber-500/15 ring-1 ring-amber-400/20 bg-gradient-to-b from-[#1b170c] via-[#0d0d18] to-[#0c0c16]' 
        : (isSilver 
          ? 'border-slate-400/30 bg-gradient-to-b from-[#141822] via-[#0d0d18] to-[#0c0c16]' 
          : 'border-amber-700/30 bg-gradient-to-b from-[#1c120c] via-[#0d0d18] to-[#0c0c16]');

      const crownOrMedal = isGold ? 'ðŸ‘‘' : (isSilver ? 'ðŸ¥ˆ' : 'ðŸ¥‰');
      const rankTitle = isGold ? '1ST PLACE â€¢ CHAMPION' : (isSilver ? '2ND PLACE' : '3RD PLACE');

      podiumCardsHtml += `
        <div class="relative rounded-3xl p-5 border ${cardBorder} shadow-xl flex flex-col justify-between transition-all hover:scale-[1.02]">
          <!-- Rank Pill Header -->
          <div class="flex items-center justify-between gap-2 border-b border-[#1e1e30] pb-3 mb-3.5">
            <div class="flex items-center gap-2">
              <span class="w-7 h-7 rounded-xl bg-gradient-to-tr ${rankBadgeColor} font-black text-xs flex items-center justify-center shadow-md">
                ${crownOrMedal}
              </span>
              <span class="text-[11px] font-mono font-extrabold uppercase tracking-wider ${isGold ? 'text-amber-300' : (isSilver ? 'text-slate-300' : 'text-orange-300')}">
                ${rankTitle}
              </span>
            </div>
            <span class="text-xs font-mono font-bold px-2 py-0.5 rounded-lg bg-[#141424] text-white">
              #${rank}
            </span>
          </div>

          <!-- Stylist Identity -->
          <div class="flex items-center gap-3 mb-4">
            <div class="w-12 h-12 rounded-2xl bg-gradient-to-tr ${isGold ? 'from-amber-500/30 to-yellow-300/20 border-amber-400/50' : 'from-[#1e1e32] to-[#252540] border-[#32324e]'} border flex items-center justify-center font-bold text-white text-base shrink-0 shadow-inner">
              ${item.staff.name.substring(0, 2).toUpperCase()}
            </div>
            <div class="min-w-0">
              <h4 class="font-syne font-bold text-base text-white truncate">${item.staff.name}</h4>
              <p class="text-xs text-gray-400 truncate">${item.staff.role}</p>
            </div>
          </div>

          <!-- Service Revenue & Target Bar -->
          <div class="space-y-1.5 text-xs mb-3 bg-[#080810]/70 p-3 rounded-2xl border border-[#1b1b2c]">
            <div class="flex items-center justify-between text-[11px]">
              <span class="text-gray-400">Services Revenue:</span>
              <span class="text-white font-mono font-bold">â‚¹${item.servicesDone.toLocaleString('en-IN')} <span class="text-gray-500 font-normal">/ â‚¹${item.target.toLocaleString('en-IN')}</span></span>
            </div>
            <div class="w-full bg-[#141422] h-2 rounded-full overflow-hidden">
              <div class="h-full rounded-full transition-all duration-500 ${item.targetAchieved ? 'bg-gradient-to-r from-purple-500 to-emerald-400' : 'bg-gradient-to-r from-[#ff2a85] to-purple-500'}" style="width: ${item.targetPercent}%"></div>
            </div>
            <div class="flex items-center justify-between text-[10px] text-gray-400">
              <span>Target Met: <strong class="${item.targetAchieved ? 'text-emerald-400' : 'text-gray-300'} font-mono">${item.targetPercent}%</strong></span>
              <span class="${item.targetAchieved ? 'text-emerald-400 font-bold' : 'text-gray-500'}">${item.targetAchieved ? 'âœ“ 5% Unlocked' : 'In Progress'}</span>
            </div>
          </div>

          <!-- Retail Sales & Commission Earned -->
          <div class="grid grid-cols-2 gap-2 text-xs mb-3 font-mono">
            <div class="bg-[#080810]/50 p-2.5 rounded-xl border border-[#181826]">
              <span class="text-[10px] text-gray-400 block font-sans">Retail Sales</span>
              <span class="font-bold text-pink-400">â‚¹${item.productsSold.toLocaleString('en-IN')}</span>
            </div>
            <div class="bg-[#080810]/50 p-2.5 rounded-xl border border-[#181826]">
              <span class="text-[10px] text-gray-400 block font-sans">Commission</span>
              <span class="font-bold ${item.totalIncentives > 0 ? 'text-[#ff7eb3]' : 'text-gray-500'}">â‚¹${item.totalIncentives.toLocaleString('en-IN')}</span>
            </div>
          </div>

          <!-- Dynamic Badges -->
          <div class="flex flex-wrap gap-1.5 pt-2 border-t border-[#181828]">
            ${rankMeta.badges.map(b => `
              <span class="px-2 py-0.5 rounded-lg text-[10px] font-bold border ${b.border} flex items-center gap-1">
                <span>${b.icon}</span>
                <span>${b.label}</span>
              </span>
            `).join('')}
          </div>
        </div>
      `;
    });

    let restHtml = '';
    if (rest.length > 0) {
      restHtml = `
        <div class="mt-4 pt-4 border-t border-[#1f1f34]">
          <h4 class="text-xs uppercase font-extrabold text-gray-400 tracking-wider mb-2.5 flex items-center gap-2">
            <i class="fa-solid fa-list-ol text-gray-500"></i>
            <span>Stylist Rankings (Positions 4+)</span>
          </h4>
          <div class="space-y-2">
            ${rest.map((item, idx) => {
              const rank = idx + 4;
              const meta = stylistRankMeta[item.staff.id];
              return `
                <div class="flex flex-col sm:flex-row sm:items-center justify-between gap-3 p-3.5 rounded-2xl bg-[#090912] border border-[#1a1a2b] hover:border-[#2e2e46] transition-all">
                  <div class="flex items-center gap-3">
                    <span class="w-7 h-7 rounded-xl bg-[#141424] border border-[#222238] text-gray-300 font-mono font-bold text-xs flex items-center justify-center">
                      #${rank}
                    </span>
                    <div>
                      <div class="flex items-center gap-2">
                        <span class="font-syne font-bold text-sm text-white">${item.staff.name}</span>
                        <span class="text-[10px] text-gray-400 font-medium">(${item.staff.role})</span>
                      </div>
                      <div class="flex flex-wrap gap-1 mt-1">
                        ${meta.badges.map(b => `<span class="px-1.5 py-0.2 rounded text-[9px] font-semibold border ${b.border}">${b.icon} ${b.label}</span>`).join('')}
                      </div>
                    </div>
                  </div>
                  <div class="flex items-center gap-4 text-xs font-mono justify-between sm:justify-end border-t sm:border-t-0 border-[#151522] pt-2 sm:pt-0">
                    <div>
                      <span class="text-[10px] text-gray-500 block font-sans">Services</span>
                      <span class="text-white font-bold">â‚¹${item.servicesDone.toLocaleString('en-IN')} <span class="text-[10px] text-gray-400">(${item.targetPercent}%)</span></span>
                    </div>
                    <div>
                      <span class="text-[10px] text-gray-500 block font-sans">Retail</span>
                      <span class="text-pink-400 font-bold">â‚¹${item.productsSold.toLocaleString('en-IN')}</span>
                    </div>
                    <div>
                      <span class="text-[10px] text-gray-500 block font-sans">Incentives</span>
                      <span class="font-bold ${item.totalIncentives > 0 ? 'text-[#ff7eb3]' : 'text-gray-500'}">+â‚¹${item.totalIncentives.toLocaleString('en-IN')}</span>
                    </div>
                  </div>
                </div>
              `;
            }).join('')}
          </div>
        </div>
      `;
    }

    leaderboardContainer.innerHTML = `
      <!-- Header -->
      <div class="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-[#1f1f34] pb-4">
        <div class="flex items-center gap-3.5">
          <div class="w-12 h-12 rounded-2xl bg-gradient-to-tr from-amber-400 via-yellow-500 to-amber-600 p-0.5 shadow-lg shadow-amber-500/20 flex items-center justify-center shrink-0">
            <div class="w-full h-full bg-[#0d0d18] rounded-[14px] flex items-center justify-center">
              <i class="fa-solid fa-trophy text-amber-400 text-lg"></i>
            </div>
          </div>
          <div>
            <div class="flex items-center gap-2">
              <h2 class="font-syne font-extrabold text-lg text-white">Live Stylist Leaderboard & Performance Badges</h2>
              <span class="text-[10px] font-bold font-mono px-2 py-0.5 rounded-full bg-amber-500/20 text-amber-300 border border-amber-500/30">RANKINGS</span>
            </div>
            <p class="text-xs text-gray-400 mt-0.5">Top-earning stylists for <span class="text-white font-semibold">${selectedMonthStr}</span> ranked by service revenue & retail targets.</p>
          </div>
        </div>
        <div class="flex items-center gap-2 bg-[#121220] px-3 py-1.5 rounded-2xl border border-[#202036]">
          <i class="fa-solid fa-medal text-amber-400 text-xs"></i>
          <span class="text-xs text-gray-400">Total Stylist Incentives:</span>
          <span class="text-xs font-bold font-mono text-[#ff7eb3]">â‚¹${totalStylistCommissions.toLocaleString('en-IN')}</span>
        </div>
      </div>

      <!-- Top 3 Podium Showcase -->
      <div class="grid grid-cols-1 md:grid-cols-3 gap-4 pt-1">
        ${podiumCardsHtml}
      </div>

      <!-- Positions 4+ -->
      ${restHtml}
    `;
  }

  // 3. Render Individual Staff Progress Cards with Dynamic Badges
  let html = '';

  staffList.forEach(staff => {
    const p = calculateStaffMonthPayroll(staff, year, month);

    if (staff.isManager) {
      const targetPercent = Math.min(100, Math.round((totalSalonRev / salonTarget) * 100));
      const achieved = totalSalonRev >= salonTarget;

      html += `
        <div class="bg-[#0d0d15] p-6 rounded-3xl border border-[#1f1f30] shadow-xl space-y-4">
          <div class="flex items-center justify-between border-b border-[#181826] pb-3">
            <div class="flex items-center gap-3">
              <div class="w-11 h-11 rounded-2xl bg-gradient-to-tr from-[#1f1024] to-[#2a102e] border border-[#ff2a85]/30 flex items-center justify-center font-bold text-white text-sm">
                KY
              </div>
              <div>
                <h3 class="font-heading font-bold text-white text-base">${staff.name}</h3>
                <p class="text-xs text-gray-400">Salon Manager (${salonRules.managerCommissionRate || 1}% Total Salon Revenue)</p>
              </div>
            </div>
            <div class="text-right">
              <span class="text-[10px] text-gray-400 uppercase tracking-wider block">Commission Earned</span>
              <span class="font-heading font-bold text-lg ${p.serviceCommission > 0 ? 'text-[#ff7eb3]' : 'text-gray-500'}">
                +â‚¹${p.serviceCommission.toLocaleString('en-IN')}
              </span>
            </div>
          </div>
          
          <div class="space-y-1.5 text-xs">
            <div class="flex items-center justify-between">
              <span class="text-gray-300">
                Salon Service Revenue: <strong class="text-white font-mono">â‚¹${totalSalonRev.toLocaleString('en-IN')}</strong> / â‚¹${salonTarget.toLocaleString('en-IN')}
              </span>
              ${achieved ? 
                `<span class="px-2 py-0.5 rounded-full bg-emerald-500/20 text-emerald-400 font-bold text-[10px]">Target Reached (${salonRules.managerCommissionRate || 1}% = â‚¹${p.serviceCommission})</span>` : 
                `<span class="text-gray-400 font-mono text-[10px]">${targetPercent}%</span>`
              }
            </div>
            <div class="w-full bg-[#131320] h-2.5 rounded-full overflow-hidden">
              <div class="h-full rounded-full transition-all duration-500 ${achieved ? 'bg-gradient-to-r from-purple-500 to-emerald-400' : 'bg-purple-500'}" style="width: ${targetPercent}%"></div>
            </div>
            <p class="text-[10px] text-gray-500 italic mt-1">* Kalyan receives ${salonRules.managerCommissionRate || 1}% on total salon service revenue only; no product commission.</p>
          </div>
        </div>
      `;
      return;
    }

    if (staff.isHousekeeping) {
      html += `
        <div class="bg-[#0d0d15] p-6 rounded-3xl border border-[#1f1f30] shadow-xl space-y-4">
          <div class="flex items-center justify-between border-b border-[#181826] pb-3">
            <div class="flex items-center gap-3">
              <div class="w-11 h-11 rounded-2xl bg-[#141420] border border-[#222234] flex items-center justify-center font-bold text-white text-sm">
                AN
              </div>
              <div>
                <h3 class="font-heading font-bold text-white text-base">${staff.name}</h3>
                <p class="text-xs text-gray-400">House Keeping</p>
              </div>
            </div>
            <span class="px-3 py-1 rounded-full bg-[#181826] text-gray-400 font-bold text-xs">
              FIXED SALARY
            </span>
          </div>
          <p class="text-xs text-gray-400 text-center py-2">House Keeping has no incentive targets or overtime.</p>
        </div>
      `;
      return;
    }

    const servTarget = staff.serviceTarget || (staff.baseSalary * 5);
    const servPercent = Math.min(100, Math.round((p.totalServicesDone / servTarget) * 100));
    const servAchieved = p.totalServicesDone >= servTarget;
    const servRate = staff.serviceCommissionRate || 5;

    const t1Min = staff.productTier1Min || 8000;
    const t1Rate = staff.productTier1Rate || 5;
    const t2Min = staff.productTier2Min || 15000;
    const t2Rate = staff.productTier2Rate || 8;
    const prodTierLabel = `${t1Rate}% above â‚¹${t1Min.toLocaleString('en-IN')}, ${t2Rate}% above â‚¹${t2Min.toLocaleString('en-IN')}`;

    const rankInfo = stylistRankMeta[staff.id];
    const rankNum = rankInfo ? rankInfo.rank : null;
    const rankBadgeClass = rankNum === 1 
      ? 'bg-amber-400/20 text-amber-300 border-amber-400/40' 
      : (rankNum === 2 
        ? 'bg-slate-300/20 text-slate-200 border-slate-300/40' 
        : (rankNum === 3 
          ? 'bg-orange-700/20 text-orange-300 border-orange-600/40' 
          : 'bg-[#181826] text-gray-400 border-[#28283a]'));
    const rankTitle = rankNum === 1 ? 'ðŸ‘‘ #1 Stylist' : (rankNum === 2 ? 'ðŸ¥ˆ #2 Stylist' : (rankNum === 3 ? 'ðŸ¥‰ #3 Stylist' : `#${rankNum}`));

    html += `
      <div class="bg-[#0d0d15] p-6 rounded-3xl border border-[#1f1f30] shadow-xl space-y-4">
        <div class="flex items-center justify-between border-b border-[#181826] pb-3">
          <div class="flex items-center gap-3">
            <div class="w-11 h-11 rounded-2xl bg-gradient-to-tr from-[#ff2a85]/20 to-purple-500/20 border border-[#ff2a85]/30 flex items-center justify-center font-bold text-white text-sm">
              ${staff.name.substring(0, 2).toUpperCase()}
            </div>
            <div>
              <div class="flex items-center gap-2">
                <h3 class="font-heading font-bold text-white text-base">${staff.name}</h3>
                ${rankNum ? `<span class="px-2 py-0.5 rounded-full font-mono text-[10px] font-bold border ${rankBadgeClass}">${rankTitle}</span>` : ''}
              </div>
              <p class="text-xs text-gray-400">${staff.role}</p>
              ${rankInfo && rankInfo.badges.length > 0 ? `
                <div class="flex flex-wrap gap-1 mt-1.5">
                  ${rankInfo.badges.map(b => `<span class="px-2 py-0.5 rounded-md text-[9px] font-semibold border ${b.border}">${b.icon} ${b.label}</span>`).join('')}
                </div>
              ` : ''}
            </div>
          </div>
          <div class="text-right">
            <span class="text-[10px] text-gray-400 uppercase tracking-wider block">Commissions Earned</span>
            <span class="font-heading font-bold text-lg ${p.totalIncentives > 0 ? 'text-[#ff7eb3]' : 'text-gray-500'}">
              +â‚¹${p.totalIncentives.toLocaleString('en-IN')}
            </span>
          </div>
        </div>

        <!-- Services Commission on Target -->
        <div class="space-y-1.5 text-xs">
          <div class="flex items-center justify-between">
            <span class="text-gray-300">
              Services (${servRate}% on Target): <strong class="text-white font-mono">â‚¹${p.totalServicesDone.toLocaleString('en-IN')}</strong> / â‚¹${servTarget.toLocaleString('en-IN')}
            </span>
            ${servAchieved ? 
              `<span class="px-2 py-0.5 rounded-full bg-emerald-500/20 text-emerald-400 font-bold text-[10px]">${servRate}% Earned (+â‚¹${p.serviceCommission.toLocaleString('en-IN')})</span>` : 
              `<span class="text-gray-400 font-mono text-[10px]">${servPercent}%</span>`
            }
          </div>
          <div class="w-full bg-[#131320] h-2.5 rounded-full overflow-hidden">
            <div class="h-full rounded-full transition-all duration-500 ${servAchieved ? 'bg-gradient-to-r from-purple-500 to-emerald-400' : 'bg-purple-500'}" style="width: ${servPercent}%"></div>
          </div>
        </div>

        <!-- Products Tiered Commission -->
        <div class="space-y-1.5 text-xs pt-2 border-t border-[#181826]">
          <div class="flex items-center justify-between">
            <span class="text-gray-300">
              Product Sales: <strong class="text-white font-mono">â‚¹${p.totalProductsSold.toLocaleString('en-IN')}</strong>
            </span>
            ${p.productCommission > 0 ? 
              `<span class="px-2 py-0.5 rounded-full bg-pink-500/20 text-pink-400 font-bold text-[10px]">Commission: +â‚¹${p.productCommission.toLocaleString('en-IN')}</span>` : 
              `<span class="text-gray-500 text-[10px] font-mono">Below â‚¹${t1Min.toLocaleString('en-IN')}</span>`
            }
          </div>
          <span class="text-[10px] text-gray-500 block">Rule: ${prodTierLabel}</span>
        </div>

        <!-- Quick Log Sales for This Staff Button -->
        <div class="pt-2 border-t border-[#181826] flex items-center justify-between">
          <span class="text-[10px] text-gray-500">Log daily billings for ${selectedDateStr}</span>
          <button type="button" onclick="openQuickSalesModal('${staff.id}')" 
            class="px-3 py-1.5 rounded-xl bg-[#171728] hover:bg-[#ff2a85]/20 text-gray-300 hover:text-[#ff7eb3] border border-[#2b2b40] hover:border-[#ff2a85]/40 text-xs font-bold transition-all flex items-center gap-1.5 cursor-pointer">
            <i class="fa-solid fa-plus-circle text-[#ff2a85]"></i>
            <span>Log Daily Sales</span>
          </button>
        </div>

      </div>
    `;
  });

  container.innerHTML = html;
}

/**
 * Quick Modal/Prompt for logging daily service and product sales directly from the Incentive Tracker
 */
function openQuickSalesModal(staffId) {
  const staff = staffList.find(s => s.id === staffId);
  if (!staff) return;

  const currentRecord = attendanceData[selectedDateStr]?.[staffId] || { servicesDone: 0, productsSold: 0 };
  const currentServ = currentRecord.servicesDone || 0;
  const currentProd = currentRecord.productsSold || 0;

  const servPrompt = prompt(`Enter Service Revenue for ${staff.name} on ${selectedDateStr} (in â‚¹):\n(Currently: â‚¹${currentServ})`, currentServ);
  if (servPrompt === null) return;

  const prodPrompt = prompt(`Enter Retail Products Sold by ${staff.name} on ${selectedDateStr} (in â‚¹):\n(Currently: â‚¹${currentProd})`, currentProd);
  if (prodPrompt === null) return;

  const newServ = Math.max(0, parseFloat(servPrompt) || 0);
  const newProd = Math.max(0, parseFloat(prodPrompt) || 0);

  if (!attendanceData[selectedDateStr]) attendanceData[selectedDateStr] = {};
  if (!attendanceData[selectedDateStr][staffId]) {
    attendanceData[selectedDateStr][staffId] = {
      status: 'Present',
      inH: 10, inM: 0, inAmpm: 'AM', outH: 7, outM: 0,
      workedMinutes: 540, otHours: 0, shortfallHours: 0, otPay: 0,
      servicesDone: newServ,
      productsSold: newProd
    };
  } else {
    attendanceData[selectedDateStr][staffId].servicesDone = newServ;
    attendanceData[selectedDateStr][staffId].productsSold = newProd;
  }

  saveAttendanceData();
  renderIncentivesView();
  renderDailyAttendance();
  showToast(`Updated ${staff.name}: Services â‚¹${newServ.toLocaleString('en-IN')}, Products â‚¹${newProd.toLocaleString('en-IN')}`);
}

// ==========================================
// 8. VIEW 4: SCHEDULE ROSTER IMAGE SCANNER (MULTI-IMAGE GALLERY & PRECISE PARSER)
// ==========================================

let rosterImages = [];

function renderRosterView() {
  const targetDateInput = document.getElementById('rosterTargetDate');
  if (targetDateInput && !targetDateInput.value) {
    targetDateInput.value = selectedDateStr;
  }
  renderRosterImageGallery();
  renderParsedRosterList();
}

/**
 * Handles multiple images chosen through the file picker
 */
function handleRosterMultipleImages(e) {
  const files = e.target.files;
  if (!files || files.length === 0) return;
  for (let i = 0; i < files.length; i++) {
    addRosterImageFile(files[i]);
  }
  e.target.value = '';
}

/**
 * Adds an individual file or blob to the rosterImages array and updates UI
 */
function addRosterImageFile(fileOrBlob) {
  const reader = new FileReader();
  reader.onload = function(evt) {
    const dataUrl = evt.target.result;
    rosterImages.push({
      id: 'img_' + Date.now() + '_' + Math.random().toString(36).substring(2, 7),
      dataUrl: dataUrl,
      name: fileOrBlob.name || `Photo ${rosterImages.length + 1}`
    });
    renderRosterImageGallery();
    showToast(`Added schedule image (${rosterImages.length} loaded)!`);
  };
  reader.readAsDataURL(fileOrBlob);
}

/**
 * Removes a photo from the roster scanner gallery
 */
function removeRosterImage(index) {
  if (index >= 0 && index < rosterImages.length) {
    rosterImages.splice(index, 1);
    renderRosterImageGallery();
    showToast('Removed photo from gallery.');
  }
}

/**
 * Clears all loaded roster photos
 */
function clearAllRosterImages() {
  rosterImages = [];
  parsedRosterBuffer = {};
  renderRosterImageGallery();
  renderParsedRosterList();
  showToast('Cleared all schedule photos.');
}

/**
 * Renders the multi-image thumbnail gallery, badge, and scan button state
 */
function renderRosterImageGallery() {
  const promptEl = document.getElementById('uploadPrompt');
  const galleryContainer = document.getElementById('rosterGalleryContainer');
  const galleryGrid = document.getElementById('rosterGalleryGrid');
  const badge = document.getElementById('rosterImageCountBadge');
  const clearBtn = document.getElementById('clearAllImagesBtn');
  const scanBtn = document.getElementById('scanRosterBtn');
  const scanBtnLabel = document.getElementById('scanBtnLabel');

  const count = rosterImages.length;
  if (badge) {
    badge.innerText = `${count} Pic${count === 1 ? '' : 's'}`;
  }

  if (count === 0) {
    if (promptEl) promptEl.classList.remove('hidden');
    if (galleryContainer) galleryContainer.classList.add('hidden');
    if (clearBtn) clearBtn.classList.add('hidden');
    if (scanBtn) {
      scanBtn.disabled = true;
      scanBtn.classList.add('opacity-50');
    }
    if (scanBtnLabel) scanBtnLabel.innerText = 'Scan Schedule Image with AI';
    return;
  }

  if (promptEl) promptEl.classList.add('hidden');
  if (galleryContainer) galleryContainer.classList.remove('hidden');
  if (clearBtn) clearBtn.classList.remove('hidden');
  if (scanBtn) {
    scanBtn.disabled = false;
    scanBtn.classList.remove('opacity-50');
  }
  if (scanBtnLabel) {
    scanBtnLabel.innerText = `Scan ${count} Schedule Photo${count === 1 ? '' : 's'} with AI`;
  }

  if (galleryGrid) {
    galleryGrid.innerHTML = rosterImages.map((img, idx) => `
      <div class="relative group rounded-2xl overflow-hidden border border-[#2d2d46] bg-[#0c0c16] aspect-[4/3] flex items-center justify-center shadow-md">
        <img src="${img.dataUrl}" class="w-full h-full object-cover">
        <div class="absolute inset-0 bg-black/60 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center gap-2">
          <button type="button" onclick="removeRosterImage(${idx})" class="p-2 rounded-xl bg-rose-600/90 hover:bg-rose-600 text-white text-xs shadow-lg transition-all" title="Remove Photo">
            <i class="fa-solid fa-trash-can"></i>
          </button>
        </div>
        <span class="absolute top-2 left-2 px-2 py-0.5 rounded-lg bg-black/80 text-white text-[10px] font-bold font-mono border border-white/20">
          #${idx + 1}
        </span>
      </div>
    `).join('');
  }
}

/**
 * Handles pasting image from clipboard (supports multiple pastes)
 */
async function pasteImageFromClipboard() {
  try {
    if (navigator.clipboard && navigator.clipboard.read) {
      const items = await navigator.clipboard.read();
      let found = false;
      for (const item of items) {
        const imageType = item.types.find(type => type.startsWith('image/'));
        if (imageType) {
          const blob = await item.getType(imageType);
          addRosterImageFile(blob);
          found = true;
        }
      }
      if (found) {
        showToast('Image pasted! You can paste more pics or click Scan.');
        return;
      }
      showToast('No image in clipboard. Copy a screenshot or press Ctrl+V directly.');
    } else {
      showToast('Please press Ctrl + V directly anywhere on the page to paste.');
    }
  } catch (err) {
    console.warn('Clipboard read error:', err);
    showToast('Clipboard permission denied. Please press Ctrl + V directly to paste.');
  }
}

/**
 * Preprocesses low-resolution or compressed WhatsApp images:
 * Upscaling, Grayscale Rec.601, and Binarization thresholding (> 160)
 */
function preprocessImageSource(dataUrl) {
  return new Promise((resolve) => {
    const img = new Image();
    img.crossOrigin = 'anonymous';
    img.onload = () => {
      try {
        const canvas = document.createElement('canvas');
        const ctx = canvas.getContext('2d');
        const scale = 2.5;
        canvas.width = (img.naturalWidth || img.width || 400) * scale;
        canvas.height = (img.naturalHeight || img.height || 300) * scale;
        ctx.imageSmoothingEnabled = true;
        ctx.drawImage(img, 0, 0, canvas.width, canvas.height);

        const imgData = ctx.getImageData(0, 0, canvas.width, canvas.height);
        const d = imgData.data;
        for (let i = 0; i < d.length; i += 4) {
          const avg = d[i] * 0.299 + d[i + 1] * 0.587 + d[i + 2] * 0.114;
          const v = avg > 160 ? 255 : 0;
          d[i] = v;
          d[i + 1] = v;
          d[i + 2] = v;
        }
        ctx.putImageData(imgData, 0, 0);
        resolve(canvas.toDataURL('image/png'));
      } catch (err) {
        console.warn('Canvas preprocess error:', err);
        resolve(dataUrl);
      }
    };
    img.onerror = () => resolve(dataUrl);
    img.src = dataUrl;
  });
}

/**
 * Sequential Multi-Image OCR Scanner with accurate overall progress tracking
 */
async function scanUploadedRoster() {
  if (!rosterImages || rosterImages.length === 0) {
    alert('Please paste (Ctrl+V) or upload at least one schedule image first.');
    return;
  }

  const pBox = document.getElementById('ocrProgressBox');
  const pBar = document.getElementById('ocrProgressBar');
  const pText = document.getElementById('ocrStatusText');
  const pPercent = document.getElementById('ocrPercent');
  const scanBtn = document.getElementById('scanRosterBtn');

  if (pBox) pBox.classList.remove('hidden');
  if (scanBtn) {
    scanBtn.disabled = true;
    scanBtn.classList.add('opacity-50');
  }

  if (typeof Tesseract === 'undefined') {
    if (pBox) pBox.classList.add('hidden');
    if (scanBtn) {
      scanBtn.disabled = false;
      scanBtn.classList.remove('opacity-50');
    }
    loadSampleUploadedRoster();
    return;
  }

  let aggregatedText = '';
  const totalImages = rosterImages.length;

  try {
    for (let i = 0; i < totalImages; i++) {
      const currentImg = rosterImages[i];
      if (pText) pText.innerText = `Enhancing & reading photo ${i + 1} of ${totalImages}...`;
      
      const cleanSource = await preprocessImageSource(currentImg.dataUrl);

      const result = await Tesseract.recognize(
        cleanSource,
        'eng',
        {
          logger: m => {
            if (m.status === 'recognizing text') {
              const currentImgPct = m.progress || 0;
              const overallPct = Math.round(((i + currentImgPct) / totalImages) * 100);
              if (pBar) pBar.style.width = overallPct + '%';
              if (pPercent) pPercent.innerText = overallPct + '%';
              if (pText) pText.innerText = `Reading photo ${i + 1} of ${totalImages} (${Math.round(currentImgPct * 100)}%)...`;
            }
          }
        }
      );

      aggregatedText += '\n' + (result.data?.text || '');
    }

    if (pBox) pBox.classList.add('hidden');
    if (scanBtn) {
      scanBtn.disabled = false;
      scanBtn.classList.remove('opacity-50');
    }

    parseRosterText(aggregatedText);
    const count = Object.keys(parsedRosterBuffer).length;
    showToast(`Scan complete! Identified ${count} staff schedules across ${totalImages} photos.`);
  } catch (err) {
    console.error('Multi-image OCR Error:', err);
    if (pBox) pBox.classList.add('hidden');
    if (scanBtn) {
      scanBtn.disabled = false;
      scanBtn.classList.remove('opacity-50');
    }
    if (aggregatedText.trim().length > 0) {
      parseRosterText(aggregatedText);
    } else {
      loadSampleUploadedRoster();
    }
  }
}

function loadSampleUploadedRoster() {
  const sampleOcrText = `DATE: 26-09-2026 SATURDAY
DAILY ROSTER
MALE STAFF
1 | SULEMAN | = 12:00 TO 9:00
2 | ISLAM | 9:00 TO 6:00
3 | IQRAM | LEAVE
FEMALE STAFF
1 | ARUNA | = 10:00 TO 7:00
2 | AFRIN | = 11:00 TO 8:00
3 | RESHMA | = 12:00 TO 9:00
NOTE: ANY LEAVE SAME DAY INFORMATION DOUBLE SALARY CUT`;

  parseRosterText(sampleOcrText);
  showToast('Loaded sample roster & verified schedule!');
}

/**
 * Strict Shift Extractor:
 * 1. WEEK OFF / DAY OFF: strictly mapped to 'Weekly Off' (entitled regular weekly off, â‚¹0 salary cut).
 *    Recognizes: DAY OFF, WEEK OFF, WEEKLY OFF, D.OFF, W.OFF, D/O, W/O, DO, WO, DAY-OFF, WEEK-OFF, OFF.
 * 2. LEAVE: strictly mapped to 'Leave' (unpaid leave, triggers daily salary deduction).
 *    Recognizes: LEAVE, EAVE, WEAVE, WEAV, LEAV, ABSENT, CASUAL LEAVE, SICK LEAVE, LV, LVE, CL, SL, PL, ABS.
 * 3. TIMINGS: 12:00 TO 9:00, 120070900, 900To600, 110070800, 1000T07:00, 10-7, etc.
 */
function extractShiftFromContext(line, nextLine = '', isManager = false) {
  const combined = (line + ' ' + (nextLine || '')).toUpperCase();

  // 1. Strict Week Off / Day Off Detection FIRST:
  const isWeekOff = 
    /\b(DAY\s*OFF|WEEK\s*OFF|WEEKLY\s*OFF|DAYOFF|WEEKOFF|D[.\s/_-]*OFF|W[.\s/_-]*OFF|DAY[._-]?OFF|WEEK[._-]?OFF|D\/O|W\/O|WK\s*OFF)\b/i.test(combined) ||
    /\b(DAY|WEEK|WEEKLY)[.\s/_-]*(?:OFF|QFF|CFF|UFF|0FF|EFF)\b/i.test(combined) ||
    /\b(DAY\s*QFF|WEEK\s*QFF|OFF\s*DAY)\b/i.test(combined) ||
    /(?:^|[\s|:=-])(?:DO|WO|D\.O|W\.O)(?:[\s|:=-]|$)/i.test(combined) ||
    (/(?:^|[\s|:=-])(OFF)(?:[\s|:=-]|$)/i.test(combined) && !combined.includes('COFFEE') && !combined.includes('OFFIC'));

  // 2. Strict Leave Detection (includes common OCR visual blur 'weave' / 'weav' for 'leave'):
  const isLeave = 
    /\b(LEAVE|EAVE|WEAVE|WEAV|LEAV|ABSENT|CASUAL\s*LEAVE|SICK\s*LEAVE|PAID\s*LEAVE|UNPAID\s*LEAVE)\b/i.test(combined) ||
    /(?:^|[\s|:=-])(?:WEAVE|WEAV|LEAVE|LEAV|EAVE|LV|LVE|CL|SL|PL|ABS)(?:[\s|:=-]|$)/i.test(combined);

  if (isWeekOff) {
    return { status: 'Weekly Off', inH: 10, inM: 0, inAmpm: 'AM', outH: 7, outM: 0 };
  }
  if (isLeave) {
    return { status: 'Leave', inH: 10, inM: 0, inAmpm: 'AM', outH: 7, outM: 0 };
  }

  // 3. High-precision Shift / Time Pattern Matching:
  // Handles:
  // - "12:00 TO 9:00", "10:00 TO 7:00", "9:00 TO 6:00", "11:00 TO 8:00"
  // - "1100710800" (OCR reads 11:00 TO 8:00 with TO as 710)
  // - "120010900" (OCR reads 12:00 TO 9:00 with TO as 10)
  // - "90070600" (OCR reads 9:00 TO 6:00 with TO as 70)
  // - "120070500" (OCR reads 12:00 TO 9:00 with 9 read as 5)
  // - "1000T07:00" (OCR reads 10:00 TO 7:00 with TO as T0)
  // - "10-7", "11-8", "12-9", "9-6"
  const shiftRegex = /(?:^|[^\d])(9|10|11|12)(?::|\.|00)?(\d{2})?\s*(?:TO|710|70|10|T0|T|UNTIL|-|[=\s])\s*([0-9]|1[0-2])(?::|\.|00)?(\d{2})?(?:[^\d]|$)/i;
  const match = combined.match(shiftRegex);
  if (match) {
    let inH = parseInt(match[1], 10);
    let inM = (match[2] && match[2].length === 2 && parseInt(match[2], 10) < 60 && parseInt(match[2], 10) !== 0) ? parseInt(match[2], 10) : 0;
    let outH = parseInt(match[3], 10);
    let outM = (match[4] && match[4].length === 2 && parseInt(match[4], 10) < 60 && parseInt(match[4], 10) !== 0) ? parseInt(match[4], 10) : 0;

    // Automatic OCR misread correction for standard salon shifts:
    // (e.g. 9 misread as 3, 5, or 0; 8 as 3 or 0; 7 as 1 or 0; 6 as 0 or 5)
    if (inH === 12 && (outH === 3 || outH === 5 || outH === 0)) {
      outH = 9; // 12:00 to 9:00 PM closing shift
    } else if (inH === 11 && (outH === 3 || outH === 0)) {
      outH = 8; // 11:00 to 8:00 PM shift
    } else if (inH === 10 && (outH === 1 || outH === 0)) {
      outH = 7; // 10:00 to 7:00 PM shift
    } else if (inH === 9 && (outH === 0 || outH === 5)) {
      outH = 6; // 9:00 to 6:00 PM shift
    }

    let startAmpm = (inH === 12 || inH === 1 || inH === 2 || inH === 3) ? 'PM' : 'AM';

    return {
      status: 'Present',
      inH: inH,
      inM: inM,
      inAmpm: startAmpm,
      outH: outH,
      outM: outM
    };
  }

  // 4. Secondary fallback time regex for general time patterns like "10:30-19:30":
  const fallbackMatch = combined.match(/(\d{3,4}|\d{1,2}(?::\d{2})?)\s*(?:TO|70|10|T0|-|UNTIL)\s*(\d{3,4}|\d{1,2}(?::\d{2})?)/i);
  if (fallbackMatch) {
    function parseTimeVal(str) {
      if (str.includes(':')) {
        const parts = str.split(':');
        return { h: parseInt(parts[0], 10), m: parseInt(parts[1], 10) || 0 };
      }
      const val = parseInt(str, 10);
      if (val >= 100) {
        return { h: Math.floor(val / 100), m: val % 100 };
      }
      return { h: val, m: 0 };
    }

    const start = parseTimeVal(fallbackMatch[1]);
    const end = parseTimeVal(fallbackMatch[2]);
    let inH = start.h || 10;
    let outH = end.h || 7;
    if (inH === 0) inH = 12;
    if (outH === 0) outH = 12;

    if (inH === 12 && (outH === 3 || outH === 5 || outH === 0)) outH = 9;
    else if (inH === 11 && (outH === 3 || outH === 0)) outH = 8;
    else if (inH === 10 && (outH === 1 || outH === 0)) outH = 7;
    else if (inH === 9 && (outH === 0 || outH === 5)) outH = 6;

    let startAmpm = (inH === 12 || inH === 1 || inH === 2 || inH === 3) ? 'PM' : 'AM';

    return {
      status: 'Present',
      inH: inH,
      inM: start.m || 0,
      inAmpm: startAmpm,
      outH: outH,
      outM: end.m || 0
    };
  }

  // Kalyan (Manager) standard scheduled shift: 12:00 PM â€“ 9:00 PM
  if (isManager) {
    return { status: 'Present', inH: 12, inM: 0, inAmpm: 'PM', outH: 9, outM: 0 };
  }

  // General Stylist fallback: 10:00 AM - 7:00 PM
  return { status: 'Present', inH: 10, inM: 0, inAmpm: 'AM', outH: 7, outM: 0 };
}

/**
 * Strict Roster Parser:
 * 1. Checks names strictly. If staff name is NOT in text, their data is NOT touched!
 * 2. Kalyan (Manager) and Anusha (Housekeeping) are excluded if not in roster.
 * 3. Inspects current line and lookahead line to catch schedules where name and time are on separate lines.
 * 4. Extracts date from image header.
 */
function parseRosterText(rawText) {
  window._lastParsedRawText = rawText;
  parsedRosterBuffer = {};

  if (!rawText) {
    renderParsedRosterList();
    return;
  }

  // 1. Detect Date
  const dateMatch = rawText.match(/(\d{1,2})[-/.](\d{1,2})[-/.](\d{2,4})/);
  if (dateMatch) {
    let day = dateMatch[1].padStart(2, '0');
    let month = dateMatch[2].padStart(2, '0');
    let year = dateMatch[3];
    if (year.length === 2) year = '20' + year;
    const detectedDateStr = `${year}-${month}-${day}`;
    
    const targetDateInput = document.getElementById('rosterTargetDate');
    if (targetDateInput) {
      targetDateInput.value = detectedDateStr;
    }
  }

  const lines = rawText.split('\n').map(l => l.trim()).filter(l => l.length > 0);

  let inMaleSection = false;
  let inFemaleSection = false;
  let arunaLineIdx = -1;
  let reshmaLineIdx = -1;

  const staffDefinitions = [
    {
      id: 'staff_1',
      name: 'KALYAN',
      isManager: true,
      aliases: ['KALYAN', 'MANAGER', 'KALAYAN', 'KALYANI', 'KALY', 'KALYN', 'KLYAN', 'CALYAN', 'KALIYAN', 'KLYN', 'KA1YAN', 'KAIYAN', 'KALVAN', 'KALYAM', 'KALLAN', 'KALLIAN', 'BM', 'MGR', 'MNGR', 'SALON MANAGER', 'STORE MANAGER', 'BRANCH MANAGER'],
      customMatcher: (line, upper, cleanUpper) => {
        if (/(?:^|[^A-Z0-9])(?:K[A4@][L1|!I]{1,2}[YV]?[A4@][NM]I?|KALYAN|KA1YAN|KAIYAN|KALVAN|KALYN|KLYAN|KALYAM|KALYANI|CALYAN|KALIYAN|KLYN)(?:[^A-Z0-9]|$)/i.test(line)) {
          return true;
        }
        if (/\b(MANAGER|BM|MGR|MNGR|BRANCH\s*MANAGER|STORE\s*MANAGER|SALON\s*MANAGER)\b/i.test(upper)) {
          return true;
        }
        return false;
      }
    },
    {
      id: 'staff_12',
      name: 'VARSHA',
      isManager: true,
      aliases: ['VARSHA', 'VARSHAA', 'WARSHA', 'VRSHA']
    },
    {
      id: 'staff_13',
      name: 'RAMESH',
      isManager: true,
      aliases: ['RAMESH', 'RAMES', 'RAMESHWAR', 'ASST MANAGER', 'ASST MGR']
    },
    {
      id: 'staff_4',
      name: 'SULEMAN',
      gender: 'male',
      sectionIndex: 1,
      aliases: ['SULEMAN', 'SUEMAN', 'SULMAN', 'SULIMAN', 'SUMAN', 'SULEMAAN', 'SOLEMAN', 'SULAIMAN', 'SLMN', 'SULEM', 'SULI', 'SUL', 'SUEM', 'SULAMAN']
    },
    {
      id: 'staff_2',
      name: 'ISLAM',
      gender: 'male',
      sectionIndex: 2,
      aliases: ['ISLAM', 'STAM', '1SLAM', 'SLAM', 'ISLM', 'ISLAAM', 'ASLAM', 'ISLLAM', 'ISLAMM', 'I-SLAM', 'SLM', '1SLM', 'TSLAM']
    },
    {
      id: 'staff_3',
      name: 'IQRAM',
      gender: 'male',
      sectionIndex: 3,
      aliases: ['IQRAM', 'IKRAM', 'ILARAM', 'RAM', 'ORAM', 'QRAM', 'ILARA', 'IKRM', 'IQRAAM', 'IKRAAM', 'ICRAM', 'IQRM', '1QRAM', 'GRAM', 'IORAM']
    },
    {
      id: 'staff_9',
      name: 'KARTHIK',
      gender: 'male',
      sectionIndex: 4,
      aliases: ['KARTHIK', 'KARTIK', 'KARTHICK', 'KARTHEEK', 'KARTHI']
    },
    {
      id: 'staff_7',
      name: 'Aruna',
      gender: 'female',
      sectionIndex: 1,
      aliases: ['ARUNA', 'ARUN', 'AARUNA', 'ARU', 'ARUNAA', 'AURNA', 'ARONA', 'ARNA'],
      customMatcher: (line, upper, cleanUpper, inMale, inFemale) => {
        if (/\b(?:ARUNA|AARUNA|ARUN|ARUNAA|AURNA)\b/i.test(upper)) return true;
        if (inFemale && /(?:^|[\s|(\[])1(?:[.\s|\-_)]|$)/.test(cleanUpper)) return true;
        return false;
      }
    },
    {
      id: 'staff_5',
      name: 'AFRIN',
      gender: 'female',
      sectionIndex: 2,
      aliases: ['AFRIN', 'AFREEN', 'AFREN', 'ATRIN', 'ATREEN', 'ATREN', 'APRIN', 'APREN', 'APHRIN', 'APHREN', 'AFRIM', 'AFREEM', 'AFFRIN', 'AFFREN', 'AFEEM', 'AFEEN', 'AERIN', 'AARIN', 'AFRN', 'APRN', 'ARFIN', 'AFRI', 'RIN', 'AFFIN', 'AHREEN', 'AHREN', 'ADRIN', 'ADREEN', 'AMN', 'ARN'],
      customMatcher: (line, upper, cleanUpper, inMale, inFemale) => {
        if (/(?:^|[^A-Z0-9])(?:A[FPHTBD4@][R1|!IL]?[E3I1!]{1,2}[NM]A?|AFRIN|AFREEN|AFREN|ATRIN|ATREEN|ATREN|APRIN|APREN|APHRIN|APHREN|AFRIM|AFREEM|AFFRIN|AFFREN|AFEEM|AFEEN|AERIN|AARIN|AFRN|APRN|ARFIN|ARIN)(?:[^A-Z0-9]|$)/i.test(line)) {
          return true;
        }
        if (inFemale) {
          if (/(?:^|[\s|(\[])2(?:[.\s|\-_)]|$)/.test(cleanUpper)) {
            return true;
          }
          if (/\b11(?::00)?\s*(?:TO|-|710|70)\s*8(?::00)?\b/i.test(upper)) {
            return true;
          }
        }
        return false;
      }
    },
    {
      id: 'staff_6',
      name: 'RESHMA',
      gender: 'female',
      sectionIndex: 3,
      aliases: ['RESHMA', 'RMESIMA', 'RMESAMA', 'RESHM', 'RISHMA', 'RESMA', 'RESHMAA', 'RESH', 'RSHMA', 'RESHMI', 'RESMHA', 'RSHM'],
      customMatcher: (line, upper, cleanUpper, inMale, inFemale) => {
        if (/\b(?:RESHMA|RMESIMA|RISHMA|RESMA|RESHM)\b/i.test(upper)) return true;
        if (inFemale && /(?:^|[\s|(\[])3(?:[.\s|\-_)]|$)/.test(cleanUpper)) return true;
        return false;
      }
    },
    {
      id: 'staff_10',
      name: 'BHARGAVI',
      gender: 'female',
      aliases: ['BHARGAVI', 'BHARGAWI', 'BHARGVI', 'BARGAVI', 'BHARG']
    },
    {
      id: 'staff_11',
      name: 'NAVANITHA',
      gender: 'female',
      aliases: ['NAVANITHA', 'NAVANITA', 'NAVANEETHA', 'NAVANEETA', 'NAVNEETHA', 'NAVANIT']
    }
  ];

  for (let i = 0; i < lines.length; i++) {
    const line = lines[i];
    const upper = line.toUpperCase();
    const cleanLine = line.replace(/[^A-Za-z0-9:\s]/g, ' ').replace(/\s+/g, ' ').trim();
    const cleanUpper = cleanLine.toUpperCase();

    // Check FEMALE FIRST because 'FEMALE' contains substring 'MALE'!
    const isFemaleHeader = /\b(FEMALE|PEMALE|FEMAL|FMALE|LADIES|WOMEN|GIRLS|BEAUTICIAN|BEAUTICIANS|BEAUTY|SKIN|F\s*STAFF|F\s*TEAM)\b/i.test(upper) || /^(?:F|FEM|FM)[\s:|-]/i.test(upper);
    const isMaleHeader = !isFemaleHeader && (/\b(MALE|MEN|BOYS|HAIR\s*STYLIST|HAIR|BARBER|M\s*STAFF|M\s*TEAM)\b/i.test(upper) || /^(?:M|ML)[\s:|-]/i.test(upper));

    if (isFemaleHeader) {
      inFemaleSection = true;
      inMaleSection = false;
      continue;
    } else if (isMaleHeader) {
      inMaleSection = true;
      inFemaleSection = false;
      continue;
    }

    for (const staffDef of staffDefinitions) {
      if (parsedRosterBuffer[staffDef.id]) continue;

      let matched = false;

      // 0. Custom matcher (highest priority for fuzzy OCR like Ka1yan or Atreen)
      if (staffDef.customMatcher && staffDef.customMatcher(line, upper, cleanUpper, inMaleSection, inFemaleSection)) {
        matched = true;
      }

      // 1. Alias matching (raw line and cleaned line)
      if (!matched) {
        for (const alias of staffDef.aliases) {
          if (alias.length <= 4) {
            const regex = new RegExp('(?:^|[\\s|0-9_.-])' + alias + '(?:[\\s|0-9_.-]|$)', 'i');
            if (regex.test(line) || regex.test(cleanLine)) {
              matched = true;
              break;
            }
          } else {
            if (upper.includes(alias) || cleanUpper.includes(alias)) {
              matched = true;
              break;
            }
          }
        }
      }

      // 2. Section + index matching
      if (!matched && staffDef.sectionIndex) {
        if ((inMaleSection && staffDef.gender === 'male') || (inFemaleSection && staffDef.gender === 'female')) {
          const indexRegex = new RegExp('(?:^|[\\s|(\\[])' + staffDef.sectionIndex + '[\\s|._)-]+', 'i');
          if (indexRegex.test(line) || indexRegex.test(cleanLine)) {
            matched = true;
          }
        }
      }

      if (matched) {
        if (staffDef.id === 'staff_7') arunaLineIdx = i;
        if (staffDef.id === 'staff_6') reshmaLineIdx = i;

        const staffObj = staffList.find(s => s.id === staffDef.id);
        if (staffObj) {
          // Lookahead to next line if next line does not match another staff member
          let nextLineText = '';
          if (i + 1 < lines.length) {
            const nextL = lines[i + 1].toUpperCase();
            const isNextStaff = staffDefinitions.some(sd => sd.aliases.some(a => nextL.includes(a)));
            const isHeader = nextL.includes('MALE') || nextL.includes('FEMALE') || nextL.includes('NOTE') || nextL.includes('DATE');
            if (!isNextStaff && !isHeader) {
              nextLineText = lines[i + 1];
            }
          }

          const shift = extractShiftFromContext(line, nextLineText, staffDef.isManager);
          parsedRosterBuffer[staffDef.id] = {
            staff: staffObj,
            status: shift.status,
            inH: shift.inH,
            inM: shift.inM,
            inAmpm: shift.inAmpm,
            outH: shift.outH,
            outM: shift.outM
          };
        }
        break;
      }
    }
  }

  // ==========================================
  // MULTI-PASS SAFETY FALLBACK FOR KALYAN & AFRIN
  // ==========================================

  // 1. Safety Fallback for KALYAN (Manager)
  if (!parsedRosterBuffer['staff_1']) {
    const kalyanRegex = /(?:^|[^A-Z0-9])(?:K[A4@][L1|!I]{1,2}[YV]?[A4@][NM]I?|KALYAN|KA1YAN|KAIYAN|KALVAN|KALYN|KLYAN|KALYAM|KALYANI|CALYAN|KALIYAN|KLYN|BM|MANAGER|MGR|MNGR)(?:[^A-Z0-9]|$)/i;
    for (let i = 0; i < lines.length; i++) {
      const line = lines[i];
      if (kalyanRegex.test(line)) {
        const nextLineText = (i + 1 < lines.length) ? lines[i + 1] : '';
        const shift = extractShiftFromContext(line, nextLineText, true);
        const staffObj = staffList.find(s => s.id === 'staff_1');
        if (staffObj) {
          parsedRosterBuffer['staff_1'] = {
            staff: staffObj,
            status: shift.status,
            inH: shift.inH || 12,
            inM: shift.inM || 0,
            inAmpm: shift.inAmpm || 'PM',
            outH: shift.outH || 9,
            outM: shift.outM || 0
          };
          break;
        }
      }
    }
  }

  // 2. Safety Fallback for AFRIN (Stylist #5)
  if (!parsedRosterBuffer['staff_5']) {
    const afrinRegex = /(?:^|[^A-Z0-9])(?:A[FPHTBD4@][R1|!IL]?[E3I1!]{1,2}[NM]A?|AFRIN|AFREEN|AFREN|ATRIN|ATREEN|ATREN|APRIN|APREN|APHRIN|APHREN|AFRIM|AFREEM|AFFRIN|AFFREN|AFEEM|AFEEN|AERIN|AARIN|AFRN|APRN|ARFIN|ARIN)(?:[^A-Z0-9]|$)/i;
    
    // Check line between Aruna and Reshma if available
    let foundLineIdx = -1;
    if (arunaLineIdx !== -1 && reshmaLineIdx !== -1 && reshmaLineIdx > arunaLineIdx + 1) {
      foundLineIdx = arunaLineIdx + 1;
    }

    if (foundLineIdx === -1) {
      for (let i = 0; i < lines.length; i++) {
        const line = lines[i];
        const cleanL = line.replace(/[^A-Za-z0-9:\s]/g, ' ').toUpperCase();
        if (afrinRegex.test(line) || (/(?:^|[\s|(\[])2(?:[.\s|\-_)]|$)/.test(cleanL) && (line.includes('11') || line.includes('8') || line.toUpperCase().includes('OFF') || line.toUpperCase().includes('LEAVE')))) {
          foundLineIdx = i;
          break;
        }
      }
    }

    if (foundLineIdx !== -1) {
      const line = lines[foundLineIdx];
      const nextLineText = (foundLineIdx + 1 < lines.length) ? lines[foundLineIdx + 1] : '';
      const shift = extractShiftFromContext(line, nextLineText, false);
      const staffObj = staffList.find(s => s.id === 'staff_5');
      if (staffObj) {
        let finalInH = shift.inH;
        let finalOutH = shift.outH;
        // Afrin standard scheduled shift is 11:00 AM - 8:00 PM if default 10-7 was applied without explicit 10
        if (shift.status === 'Present' && shift.inH === 10 && shift.outH === 7 && !line.includes('10')) {
          finalInH = 11;
          finalOutH = 8;
        }
        parsedRosterBuffer['staff_5'] = {
          staff: staffObj,
          status: shift.status,
          inH: finalInH,
          inM: shift.inM,
          inAmpm: shift.inAmpm,
          outH: finalOutH,
          outM: shift.outM
        };
      }
    }
  }

  renderParsedRosterList();
}

/**
 * Allows the owner to adjust detected status directly from the preview card
 */
function updateDetectedStaffStatus(staffId, newStatus) {
  if (parsedRosterBuffer[staffId]) {
    parsedRosterBuffer[staffId].status = newStatus;
    renderParsedRosterList();
    showToast(`Updated ${parsedRosterBuffer[staffId].staff.name} to ${newStatus}`);
  }
}

function renderParsedRosterList() {
  const container = document.getElementById('parsedRosterList');
  const countBadge = document.getElementById('detectedCountBadge');
  if (!container) return;

  const detectedStaffIds = Object.keys(parsedRosterBuffer);
  const detectedCount = detectedStaffIds.length;

  if (countBadge) {
    countBadge.innerText = `${detectedCount} Staff Found in Roster`;
  }

  if (detectedCount === 0) {
    container.innerHTML = `
      <div class="text-center py-14 text-xs text-gray-500">
        <i class="fa-solid fa-images text-3xl mb-2 text-gray-600 block"></i>
        <span>Paste 1, 2, or more schedule photos (Ctrl+V) or browse to scan.</span>
      </div>
    `;
    return;
  }

  let html = '<div class="space-y-2.5">';

  detectedStaffIds.forEach(id => {
    const item = parsedRosterBuffer[id];
    const s = item.staff;

    const isOff = item.status === 'Weekly Off' || item.status === 'Day Off';
    const isLeave = item.status === 'Leave';

    html += `
      <div class="p-3.5 bg-[#0a0a12] rounded-2xl border border-[#202030] flex flex-col sm:flex-row sm:items-center justify-between gap-2.5 text-xs">
        <div>
          <div class="flex items-center gap-2">
            <strong class="text-white font-heading text-sm">${s.name}</strong>
            <span class="text-[9px] px-2 py-0.5 rounded-full bg-[#ff2a85]/15 text-[#ff7eb3] uppercase font-bold border border-[#ff2a85]/30">In Roster</span>
          </div>
          <span class="text-[10px] text-gray-400 block mt-0.5">${s.role}</span>
        </div>

        <div class="flex items-center gap-2 justify-end">
          ${item.status === 'Present' ? 
            `<span class="px-3 py-1.5 rounded-xl bg-emerald-500/15 text-emerald-400 font-mono font-bold border border-emerald-500/30 flex items-center gap-1.5">
              <i class="fa-solid fa-clock text-xs"></i>
              ${item.inH}:${item.inM < 10 ? '0' + item.inM : item.inM} ${item.inAmpm} - ${item.outH}:${item.outM < 10 ? '0' + item.outM : item.outM} PM
             </span>` : 
            (isOff ? 
              `<span class="px-3 py-1.5 rounded-xl bg-indigo-500/20 text-indigo-300 font-bold border border-indigo-500/40 flex items-center gap-1.5">
                <i class="fa-solid fa-mug-hot text-xs"></i> DAY OFF (â‚¹0 CUT)
               </span>` : 
              `<span class="px-3 py-1.5 rounded-xl bg-rose-500/20 text-rose-400 font-bold border border-rose-500/40 flex items-center gap-1.5">
                <i class="fa-solid fa-user-xmark text-xs"></i> LEAVE (SALARY CUT)
               </span>`
            )
          }

          <!-- Quick status override dropdown -->
          <select onchange="updateDetectedStaffStatus('${id}', this.value)" 
            class="bg-[#141424] border border-[#27273e] text-gray-300 rounded-xl px-2 py-1 text-[11px] font-semibold focus:border-[#ff2a85] focus:outline-none">
            <option value="Present" ${item.status === 'Present' ? 'selected' : ''}>Present</option>
            <option value="Weekly Off" ${isOff ? 'selected' : ''}>Day Off (0 Cut)</option>
            <option value="Leave" ${isLeave ? 'selected' : ''}>Leave (Cut)</option>
          </select>
        </div>
      </div>
    `;
  });

  const unmentionedStaff = staffList.filter(s => !s.isHousekeeping && !parsedRosterBuffer[s.id]);
  if (unmentionedStaff.length > 0) {
    html += `
      <div class="p-3.5 rounded-2xl bg-[#0e0e18] border border-[#1d1d2b] text-xs text-gray-400 mt-3">
        <div class="flex items-center justify-between gap-2 flex-wrap mb-2">
          <span class="text-gray-300 font-bold flex items-center gap-1.5">
            <i class="fa-solid fa-shield-halved text-[#ff7eb3]"></i> 
            Not in this roster (${unmentionedStaff.length} stylists):
          </span>
          <button type="button" onclick="openQuickAddStaffToRoster()" 
            class="text-[11px] font-bold text-[#ff7eb3] hover:text-white transition-colors flex items-center gap-1 cursor-pointer">
            <i class="fa-solid fa-user-plus"></i> Manual Modal
          </button>
        </div>
        <p class="text-[11px] text-gray-500 mb-2.5">Untouched unless you 1-tap add below:</p>
        
        <div class="flex flex-wrap gap-2">
    `;

    unmentionedStaff.forEach(s => {
      const isMgr = s.id === 'staff_1';
      const isAfrin = s.id === 'staff_5';
      const defInH = isMgr ? 12 : (isAfrin ? 11 : 10);
      const defOutH = isMgr ? 9 : (isAfrin ? 8 : 7);
      const defAmpm = isMgr ? 'PM' : 'AM';
      const shiftLabel = `${defInH}-${defOutH}`;

      html += `
        <div class="inline-flex items-center gap-1 bg-[#141424] border border-[#27273e] rounded-xl p-1 pr-1.5 shadow-sm">
          <span class="font-bold text-white text-[11px] px-1.5">${s.name}</span>
          <button type="button" 
            onclick="quickAddStaffWithShift('${s.id}', 'Present', ${defInH}, 0, '${defAmpm}', ${defOutH}, 0)" 
            class="px-2 py-0.5 rounded-lg bg-[#ff2a85] hover:bg-[#ff4d9a] text-white font-bold text-[10px] cursor-pointer"
            title="Add ${s.name} (${shiftLabel})">
            + ${shiftLabel}
          </button>
          <button type="button" 
            onclick="quickAddStaffWithShift('${s.id}', 'Weekly Off', ${defInH}, 0, '${defAmpm}', ${defOutH}, 0)" 
            class="px-1.5 py-0.5 rounded-lg bg-indigo-500/20 hover:bg-indigo-500/40 text-indigo-300 font-bold text-[10px] border border-indigo-500/30 cursor-pointer"
            title="Mark ${s.name} Day Off">
            Off
          </button>
          <button type="button" 
            onclick="quickAddStaffWithShift('${s.id}', 'Leave', ${defInH}, 0, '${defAmpm}', ${defOutH}, 0)" 
            class="px-1.5 py-0.5 rounded-lg bg-rose-500/20 hover:bg-rose-500/40 text-rose-300 font-bold text-[10px] border border-rose-500/30 cursor-pointer"
            title="Mark ${s.name} Leave">
            Leave
          </button>
        </div>
      `;
    });

    html += `
        </div>
      </div>
    `;
  }

  html += '</div>';
  container.innerHTML = html;
}

/**
 * Opens quick modal allowing owner to manually add any stylist to the scanned roster
 */
function openQuickAddStaffToRoster() {
  const modal = document.getElementById('quickAddRosterModal');
  const container = document.getElementById('quickAddStaffList');
  if (!modal || !container) return;

  // Filter stylists (excluding housekeeping as Anusha has fixed schedule)
  const rosterStaffList = staffList.filter(s => !s.isHousekeeping);

  let html = '';
  rosterStaffList.forEach(s => {
    const isAlreadyIn = !!parsedRosterBuffer[s.id];
    const currentStatus = isAlreadyIn ? parsedRosterBuffer[s.id].status : 'Not Added';

    html += `
      <div class="p-3 bg-[#11111e] rounded-2xl border border-[#212135] flex items-center justify-between gap-2 text-xs">
        <div>
          <strong class="text-white font-bold block">${s.name}</strong>
          <span class="text-[10px] text-gray-400">${s.role}</span>
        </div>
        <div class="flex items-center gap-1.5">
          ${isAlreadyIn ? 
            `<span class="text-[10px] font-bold px-2 py-0.5 rounded-full bg-emerald-500/20 text-emerald-400 border border-emerald-500/30">Added (${currentStatus})</span>` :
            `<button type="button" onclick="quickAddStaffWithShift('${s.id}', 'Present', 10, 0, 'AM', 7, 0)" 
               class="px-2.5 py-1 rounded-xl bg-[#ff2a85] hover:bg-[#ff4d9a] text-white font-bold text-[11px] shadow-sm cursor-pointer">
               + 10-7 Shift
             </button>
             <button type="button" onclick="quickAddStaffWithShift('${s.id}', 'Weekly Off', 10, 0, 'AM', 7, 0)" 
               class="px-2 py-1 rounded-xl bg-indigo-600/30 hover:bg-indigo-600/50 text-indigo-300 font-bold text-[10px] border border-indigo-500/40 cursor-pointer">
               Day Off
             </button>
             <button type="button" onclick="quickAddStaffWithShift('${s.id}', 'Leave', 10, 0, 'AM', 7, 0)" 
               class="px-2 py-1 rounded-xl bg-rose-600/30 hover:bg-rose-600/50 text-rose-300 font-bold text-[10px] border border-rose-500/40 cursor-pointer">
               Leave
             </button>`
          }
        </div>
      </div>
    `;
  });

  container.innerHTML = html;
  modal.classList.remove('hidden');
}

function quickAddStaffWithShift(staffId, status, inH, inM, inAmpm, outH, outM) {
  const staffObj = staffList.find(s => s.id === staffId);
  if (!staffObj) return;

  parsedRosterBuffer[staffId] = {
    staff: staffObj,
    status: status,
    inH: inH,
    inM: inM,
    inAmpm: inAmpm,
    outH: outH,
    outM: outM
  };

  renderParsedRosterList();
  openQuickAddStaffToRoster(); // refresh modal state
  showToast(`Added ${staffObj.name} (${status}) to roster`);
}

function closeQuickAddStaffModal() {
  const modal = document.getElementById('quickAddRosterModal');
  if (modal) modal.classList.add('hidden');
}

/**
 * Applies shifts ONLY for staff found in the roster!
 * Staff not in the roster are completely untouched.
 */
function applyRosterToAttendance() {
  const targetDate = document.getElementById('rosterTargetDate').value;
  if (!targetDate) {
    alert('Please select a target date.');
    return;
  }

  const detectedStaffIds = Object.keys(parsedRosterBuffer);
  if (detectedStaffIds.length === 0) {
    alert('No staff names found in the roster. Please paste or scan a roster with staff names.');
    return;
  }

  if (!attendanceData[targetDate]) {
    attendanceData[targetDate] = {};
  }

  const isWeekend = isWeekendDay(targetDate);

  // Update ONLY detected staff!
  detectedStaffIds.forEach(id => {
    const item = parsedRosterBuffer[id];
    const s = item.staff;

    // Enforce Weekend Policy: No week offs on Sat/Sun!
    let finalStatus = item.status;
    let weekendCutFlag = false;
    if (isWeekend) {
      if (finalStatus === 'Weekly Off' || finalStatus === 'Day Off') {
        finalStatus = 'Leave';
        weekendCutFlag = true;
      } else if (finalStatus === 'Leave' || finalStatus === 'Absent') {
        weekendCutFlag = true;
      }
    }

    const calc = calculateShiftHoursParsed(item.inH, item.inM, item.inAmpm, item.outH, item.outM, s.isHousekeeping);

    attendanceData[targetDate][id] = {
      status: finalStatus,
      inH: item.inH,
      inM: item.inM,
      inAmpm: item.inAmpm,
      outH: item.outH,
      outM: item.outM,
      workedMinutes: finalStatus === 'Present' ? calc.workedMinutes : 0,
      otHours: finalStatus === 'Present' ? calc.otHours : 0,
      shortfallHours: finalStatus === 'Present' ? calc.shortfallHours : 0,
      otPay: finalStatus === 'Present' ? calc.otPay : 0,
      servicesDone: attendanceData[targetDate][id]?.servicesDone || 0,
      productsSold: attendanceData[targetDate][id]?.productsSold || 0,
      weekendCut: weekendCutFlag
    };
  });

  saveAttendanceData();
  selectedDateStr = targetDate;
  const input = document.getElementById('selectedDateInput');
  if (input) input.value = targetDate;

  navigateTo('attendance');
  showToast(`Updated attendance for ${detectedStaffIds.length} staff on ${targetDate}!${isWeekend ? ' (Weekend Double Salary Cut rule applied)' : ''}`);
}

function renderAdminView() {
  const container = document.getElementById('adminStaffList');
  if (!container) return;

  document.getElementById('adminShiftHours').value = salonRules.shiftHours || 9;
  document.getElementById('adminOtThreshold').value = salonRules.otGraceThresholdMinutes || 45;
  document.getElementById('adminOtRate').value = salonRules.otHourlyRate || 50;
  document.getElementById('adminSalonTarget').value = salonRules.salonMonthlyServiceTarget || 600000;
  document.getElementById('adminManagerRate').value = salonRules.managerCommissionRate || 1;

  const authCreds = getAuthCredentials();
  const authUserInput = document.getElementById('adminAuthUsername');
  const ownerAcc = (authCreds.accounts || []).find(a => a.username.toLowerCase().includes('kancherla') || (a.role && a.role.includes('Owner')));
  if (authUserInput) authUserInput.value = ownerAcc ? ownerAcc.username : (authCreds.username || 'kancherlavatsalsai@gmial.com');
  const authPassInput = document.getElementById('adminAuthPassword');
  if (authPassInput) authPassInput.value = '';

  const managerUserInput = document.getElementById('adminManagerUsername');
  const managerAcc = (authCreds.accounts || []).find(a => a.username.toLowerCase().includes('greentrendskothapet') || (a.role && a.role.includes('Manager')));
  if (managerUserInput) managerUserInput.value = managerAcc ? managerAcc.username : 'Greentrendskothapet@gmail.com';
  const managerPassInput = document.getElementById('adminManagerPassword');
  if (managerPassInput) managerPassInput.value = '';

  // Refresh Cloud Sync UI State
  const savedFb = localStorage.getItem(STORAGE_KEYS.FIREBASE);
  let activeCfg = null;
  if (savedFb && savedFb !== 'disabled') {
    try { activeCfg = JSON.parse(savedFb); } catch(e) {}
  }
  if (!activeCfg && savedFb !== 'disabled' && typeof DEFAULT_FIREBASE_CONFIG !== 'undefined' && DEFAULT_FIREBASE_CONFIG.apiKey) {
    activeCfg = { ...DEFAULT_FIREBASE_CONFIG };
  }

  const fbInput = document.getElementById('firebaseConfigInput');
  if (fbInput && activeCfg && !fbInput.value) {
    fbInput.value = JSON.stringify(activeCfg, null, 2);
  }

  if (activeCfg && firestoreDb) {
    updateCloudSyncUI('connected', activeCfg.projectId);
  } else {
    updateCloudSyncUI('local');
  }

  let html = '';

  staffList.forEach((staff, idx) => {
    html += `
      <div class="bg-[#11111c] p-5 rounded-2xl border border-[#202032] space-y-4 text-xs">
        <div class="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-[#181826] pb-3">
          <div class="flex items-center gap-3">
            <span class="w-8 h-8 rounded-xl bg-[#181826] text-[#ff7eb3] font-bold flex items-center justify-center font-mono">
              ${idx + 1}
            </span>
            <div>
              <input type="text" id="admin_name_${staff.id}" value="${staff.name}" 
                class="bg-[#181828] border border-[#26263a] rounded-xl px-3 py-1 text-white font-bold font-heading text-sm focus:border-[#ff2a85]">
              <input type="text" id="admin_role_${staff.id}" value="${staff.role}" 
                class="bg-transparent border-b border-[#222234] text-gray-400 text-xs mt-1 px-1 py-0.5 focus:border-[#ff2a85] block w-full">
            </div>
          </div>

          <div class="flex items-center gap-2">
            ${staff.isManager ? `<span class="px-2.5 py-1 rounded-full bg-[#ff2a85]/20 text-[#ff7eb3] font-bold text-[10px]">MANAGER (${salonRules.managerCommissionRate || 1}% SALON REVENUE)</span>` : ''}
            <button onclick="removeStaffMember('${staff.id}')" title="Delete Staff Member"
              class="p-2 rounded-xl bg-rose-500/10 hover:bg-rose-500/20 text-rose-400 border border-rose-500/20 transition-all cursor-pointer">
              <i class="fa-solid fa-trash text-xs"></i>
            </button>
          </div>
        </div>

        <!-- Row 1: Fixed Pay & Allowance -->
        <div class="grid grid-cols-2 sm:grid-cols-4 gap-3">
          <div>
            <label class="text-[10px] text-gray-400 uppercase font-semibold block mb-1">Base Salary (â‚¹)</label>
            <input type="number" id="admin_salary_${staff.id}" value="${staff.baseSalary}" 
              onfocus="this.select()"
              class="w-full bg-[#181828] border border-[#26263a] rounded-xl px-2.5 py-1.5 text-white font-mono font-bold focus:border-[#ff2a85]">
          </div>

          <div>
            <label class="text-[10px] text-gray-400 uppercase font-semibold block mb-1">Food Allowance (â‚¹)</label>
            <input type="number" id="admin_food_${staff.id}" value="${staff.foodAllowance || 0}" 
              onfocus="this.select()"
              class="w-full bg-[#181828] border border-[#26263a] rounded-xl px-2.5 py-1.5 text-emerald-400 font-mono font-bold focus:border-[#ff2a85]">
          </div>

          ${staff.isManager ? `
            <div class="col-span-2 p-2.5 rounded-xl bg-[#090910] border border-[#1b1b2a] text-gray-400 text-[11px] flex items-center">
              Kalyan earns ${salonRules.managerCommissionRate || 1}% on total salon service revenue when salon target is met.
            </div>
          ` : (staff.isHousekeeping ? `
            <div class="col-span-2 p-2.5 rounded-xl bg-[#090910] border border-[#1b1b2a] text-gray-400 text-[11px] flex items-center">
              House Keeping has fixed salary. No OT or percentage commission rules apply.
            </div>
          ` : `
            <div>
              <label class="text-[10px] text-purple-400 uppercase font-semibold block mb-1">Service Comm. (%)</label>
              <input type="number" id="admin_serv_rate_${staff.id}" value="${staff.serviceCommissionRate || 5}" min="0" max="100" 
                onfocus="this.select()"
                class="w-full bg-[#181828] border border-[#26263a] rounded-xl px-2.5 py-1.5 text-purple-300 font-mono font-bold focus:border-[#ff2a85]">
            </div>

            <div>
              <label class="text-[10px] text-purple-400 uppercase font-semibold block mb-1">Service Target (â‚¹)</label>
              <input type="number" id="admin_serv_target_${staff.id}" value="${staff.serviceTarget || (staff.baseSalary * 5)}" 
                onfocus="this.select()"
                class="w-full bg-[#181828] border border-[#26263a] rounded-xl px-2.5 py-1.5 text-purple-300 font-mono font-bold focus:border-[#ff2a85]">
            </div>
          `)}
        </div>

        <!-- Row 2: Product Percentage Tiers (For Stylists) -->
        ${(!staff.isManager && !staff.isHousekeeping) ? `
          <div class="p-3 bg-[#0a0a14] rounded-xl border border-[#1e1e30] space-y-2">
            <span class="text-[10px] font-bold uppercase tracking-wider text-pink-400 block">
              <i class="fa-solid fa-bottle-droplet mr-1"></i> Retail Product Commission Percentage Rules
            </span>
            <div class="grid grid-cols-2 sm:grid-cols-4 gap-2.5">
              <div>
                <label class="text-[9px] text-gray-400 block mb-0.5">Tier 1 Comm (%)</label>
                <input type="number" id="admin_prod_tier1_rate_${staff.id}" value="${staff.productTier1Rate || 5}" min="0" max="100"
                  class="w-full bg-[#181828] border border-[#26263a] rounded-lg px-2 py-1 text-pink-300 font-mono text-xs font-bold focus:border-[#ff2a85]">
              </div>
              <div>
                <label class="text-[9px] text-gray-400 block mb-0.5">Tier 1 Min Sales (â‚¹)</label>
                <input type="number" id="admin_prod_tier1_min_${staff.id}" value="${staff.productTier1Min || 8000}" min="0"
                  class="w-full bg-[#181828] border border-[#26263a] rounded-lg px-2 py-1 text-white font-mono text-xs font-bold focus:border-[#ff2a85]">
              </div>
              <div>
                <label class="text-[9px] text-gray-400 block mb-0.5">Tier 2 Comm (%)</label>
                <input type="number" id="admin_prod_tier2_rate_${staff.id}" value="${staff.productTier2Rate || 8}" min="0" max="100"
                  class="w-full bg-[#181828] border border-[#26263a] rounded-lg px-2 py-1 text-pink-300 font-mono text-xs font-bold focus:border-[#ff2a85]">
              </div>
              <div>
                <label class="text-[9px] text-gray-400 block mb-0.5">Tier 2 Min Sales (â‚¹)</label>
                <input type="number" id="admin_prod_tier2_min_${staff.id}" value="${staff.productTier2Min || 15000}" min="0"
                  class="w-full bg-[#181828] border border-[#26263a] rounded-lg px-2 py-1 text-white font-mono text-xs font-bold focus:border-[#ff2a85]">
              </div>
            </div>
          </div>
        ` : ''}

      </div>
    `;
  });

  container.innerHTML = html;
  renderPettyCashLedger();
}

function saveAllStaffEdits() {
  staffList.forEach(staff => {
    const nameEl = document.getElementById(`admin_name_${staff.id}`);
    const roleEl = document.getElementById(`admin_role_${staff.id}`);
    const salaryEl = document.getElementById(`admin_salary_${staff.id}`);
    const foodEl = document.getElementById(`admin_food_${staff.id}`);

    if (nameEl) staff.name = nameEl.value.trim();
    if (roleEl) staff.role = roleEl.value.trim();
    if (salaryEl) staff.baseSalary = parseFloat(salaryEl.value) || 0;
    if (foodEl) staff.foodAllowance = parseFloat(foodEl.value) || 0;

    if (!staff.isManager && !staff.isHousekeeping) {
      const sTarg = document.getElementById(`admin_serv_target_${staff.id}`);
      const sRate = document.getElementById(`admin_serv_rate_${staff.id}`);
      const p1Rate = document.getElementById(`admin_prod_tier1_rate_${staff.id}`);
      const p1Min = document.getElementById(`admin_prod_tier1_min_${staff.id}`);
      const p2Rate = document.getElementById(`admin_prod_tier2_rate_${staff.id}`);
      const p2Min = document.getElementById(`admin_prod_tier2_min_${staff.id}`);

      if (sTarg) staff.serviceTarget = parseFloat(sTarg.value) || (staff.baseSalary * 5);
      if (sRate) staff.serviceCommissionRate = parseFloat(sRate.value) || 5;
      if (p1Rate) staff.productTier1Rate = parseFloat(p1Rate.value) || 5;
      if (p1Min) staff.productTier1Min = parseFloat(p1Min.value) || 8000;
      if (p2Rate) staff.productTier2Rate = parseFloat(p2Rate.value) || 8;
      if (p2Min) staff.productTier2Min = parseFloat(p2Min.value) || 15000;
    }
  });

  saveStaffList();
  renderIncentivesView();
  showToast('All staff salaries, targets & percentage commission rates saved!');
}

function saveSalonManagerTarget() {
  const target = parseFloat(document.getElementById('adminSalonTarget').value) || 600000;
  const rate = parseFloat(document.getElementById('adminManagerRate').value) || 1;

  salonRules.salonMonthlyServiceTarget = target;
  salonRules.managerCommissionRate = rate;

  saveSalonRules();
  showToast('Salon revenue target for Kalyan updated!');
}

function saveAdminShiftRules() {
  const shiftHours = parseFloat(document.getElementById('adminShiftHours').value) || 9;
  const otThreshold = parseFloat(document.getElementById('adminOtThreshold').value) || 45;
  const otRate = parseFloat(document.getElementById('adminOtRate').value) || 50;

  salonRules.shiftHours = shiftHours;
  salonRules.otGraceThresholdMinutes = otThreshold;
  salonRules.otHourlyRate = otRate;

  saveSalonRules();
  showToast('Shift and Overtime rules updated successfully!');
}

function openAddStaffModal() {
  document.getElementById('staffFormId').value = '';
  document.getElementById('staffFormName').value = '';
  document.getElementById('staffFormRole').value = '';
  document.getElementById('staffFormSalary').value = '';
  document.getElementById('staffFormFood').value = '0';
  document.getElementById('staffModalTitle').innerText = 'Add New Staff Member';
  document.getElementById('staffModal').classList.remove('hidden');
}

function closeStaffModal() {
  document.getElementById('staffModal').classList.add('hidden');
}

function handleStaffFormSubmit(e) {
  e.preventDefault();
  const name = document.getElementById('staffFormName').value.trim();
  const role = document.getElementById('staffFormRole').value.trim();
  const salary = parseFloat(document.getElementById('staffFormSalary').value) || 0;
  const food = parseFloat(document.getElementById('staffFormFood').value) || 0;

  const newStaff = {
    id: 'staff_' + Date.now(),
    name,
    role,
    gender: 'female',
    baseSalary: salary,
    foodAllowance: food,
    isManager: false,
    isHousekeeping: false,
    serviceTarget: salary * 5,
    serviceCommissionRate: 5,
    productTier1Min: 8000,
    productTier1Rate: 5,
    productTier2Min: 15000,
    productTier2Rate: 8
  };

  staffList.push(newStaff);
  saveStaffList();
  closeStaffModal();
  renderAdminView();
  showToast(`Added ${name} to Green Trends Kothapet!`);
}

function removeStaffMember(staffId) {
  const staff = staffList.find(s => s.id === staffId);
  if (!staff) return;

  if (confirm(`Remove ${staff.name} from the roster?`)) {
    staffList = staffList.filter(s => s.id !== staffId);
    saveStaffList();
    renderAdminView();
    showToast(`Removed ${staff.name}.`);
  }
}

function backupSystemData() {
  const data = {
    exportDate: new Date().toISOString(),
    salon: 'Green Trends Kothapet',
    staff: staffList,
    rules: salonRules,
    attendance: attendanceData
  };

  const blob = new Blob([JSON.stringify(data, null, 2)], { type: 'application/json' });
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = `Green_Trends_Kothapet_Backup_${formatDateKey(new Date())}.json`;
  document.body.appendChild(a);
  a.click();
  document.body.removeChild(a);
  showToast('Downloaded full system backup JSON!');
}

function restoreSystemData(event) {
  const file = event.target.files[0];
  if (!file) return;

  const reader = new FileReader();
  reader.onload = function(e) {
    try {
      const data = JSON.parse(e.target.result);
      if (data.staff) staffList = data.staff;
      if (data.rules) salonRules = data.rules;
      if (data.attendance) attendanceData = data.attendance;

      saveStaffList();
      saveSalonRules();
      saveAttendanceData();

      renderAdminView();
      showToast('System data restored successfully!');
    } catch (err) {
      alert('Invalid backup JSON file.');
    }
  };
  reader.readAsText(file);
}

function resetAllSalesAndIncentivesToZero(buttonElement) {
  for (const dateKey in attendanceData) {
    if (attendanceData[dateKey]) {
      for (const staffId in attendanceData[dateKey]) {
        if (attendanceData[dateKey][staffId]) {
          attendanceData[dateKey][staffId].servicesDone = 0;
          attendanceData[dateKey][staffId].productsSold = 0;
        }
      }
    }
  }
  saveAttendanceData();
  renderDailyAttendance();
  renderMonthlyPayroll();
  renderIncentivesView();
  showToast('âœ“ All sales and incentives have been reset to â‚¹0!');

  if (buttonElement && buttonElement.innerHTML) {
    const originalText = buttonElement.innerHTML;
    buttonElement.innerHTML = '<i class="fa-solid fa-check text-emerald-400"></i> <span class="text-emerald-300 font-bold">Reset to â‚¹0 Done!</span>';
    setTimeout(() => {
      buttonElement.innerHTML = originalText;
    }, 2500);
  }
}

function clearAllAttendanceDataToZero(buttonElement) {
  attendanceData = {};
  saveAttendanceData();
  renderDailyAttendance();
  renderMonthlyPayroll();
  renderIncentivesView();
  showToast('âœ“ All attendance and sales data cleared to a clean 0 slate!');

  if (buttonElement && buttonElement.innerHTML) {
    const originalText = buttonElement.innerHTML;
    buttonElement.innerHTML = '<i class="fa-solid fa-check text-emerald-400"></i> <span class="text-emerald-300 font-bold">Cleared to 0!</span>';
    setTimeout(() => {
      buttonElement.innerHTML = originalText;
    }, 2500);
  }
}

window.resetAllSalesAndIncentivesToZero = resetAllSalesAndIncentivesToZero;
window.clearAllAttendanceDataToZero = clearAllAttendanceDataToZero;

function confirmResetDefaults() {
  if (confirm('Reset Green Trends Kothapet to factory default settings?')) {
    staffList = [...DEFAULT_STAFF];
    salonRules = { ...DEFAULT_SALON_RULES };
    attendanceData = {};
    saveStaffList();
    saveSalonRules();
    saveAttendanceData();
    renderAdminView();
    updateViewFromHash();
    showToast('Reset system to factory default configurations!');
  }
}

// ==========================================
// 10. PAY SLIP MODAL & PRINTING
// ==========================================

function openPaySlipModal(staffId) {
  const staff = staffList.find(s => s.id === staffId);
  if (!staff) return;

  const [yearStr, monthStr] = selectedMonthStr.split('-');
  const year = parseInt(yearStr, 10);
  const month = parseInt(monthStr, 10);
  const p = calculateStaffMonthPayroll(staff, year, month);

  const monthName = new Date(year, month - 1, 1).toLocaleString('default', { month: 'short', year: 'numeric' }).toUpperCase();

  document.getElementById('psMonthYear').innerText = monthName;
  document.getElementById('psGeneratedDate').innerText = `Date: ${formatDateKey(new Date())}`;
  document.getElementById('psStaffName').innerText = staff.name;
  document.getElementById('psStaffRole').innerText = staff.role;
  document.getElementById('psMonthDays').innerText = `${p.daysInMonth} Days`;
  document.getElementById('psPerDayRate').innerText = `₹${p.perDaySalary.toFixed(2)}`;

  document.getElementById('psDaysPresent').innerText = `${p.presentDays} Days`;
  document.getElementById('psWeeklyOffs').innerText = `${p.weeklyOffs} Days (Mon-Fri)`;
  
  // Show detailed leaves: pure count + breakdown
  const leaveDetailsText = p.weekendLeaves > 0 ? 
    `${p.unpaidLeaves} (${p.weekdayLeaves} Wkday + ${p.weekendLeaves} W/End 2x Cut)` : 
    `${p.unpaidLeaves}`;
  document.getElementById('psUnpaidLeaves').innerText = leaveDetailsText;

  document.getElementById('psBaseSalary').innerText = `₹${staff.baseSalary.toLocaleString('en-IN')}`;

  const foodRow = document.getElementById('psFoodRow');
  if (staff.foodAllowance > 0) {
    foodRow.classList.remove('hidden');
    document.getElementById('psFoodAllowance').innerText = `₹${staff.foodAllowance.toLocaleString('en-IN')}`;
  } else {
    foodRow.classList.add('hidden');
  }

  document.getElementById('psOtHoursText').innerText = `${p.netOtHours}h`;
  document.getElementById('psOtPay').innerText = `₹${p.netOtPay.toLocaleString('en-IN')}`;
  
  if (staff.isManager) {
    document.getElementById('psServiceIncentiveLabel').innerText = 'Manager 1% Commission';
  } else {
    document.getElementById('psServiceIncentiveLabel').innerText = 'Services Commission (5%)';
  }
  document.getElementById('psServiceIncentive').innerText = `₹${p.serviceCommission.toLocaleString('en-IN')}`;
  document.getElementById('psProductIncentive').innerText = `₹${p.productCommission.toLocaleString('en-IN')}`;

  const shortfallRow = document.getElementById('psShortfallRow');
  if (p.totalShortfallHours > 0) {
    shortfallRow.classList.remove('hidden');
    document.getElementById('psShortfallText').innerText = `${p.totalShortfallHours}h short`;
  } else {
    shortfallRow.classList.add('hidden');
  }

  document.getElementById('psLeaveDeduction').innerText = `-₹${Math.round(p.leaveDeduction).toLocaleString('en-IN')}${p.weekendLeaves > 0 ? ` (incl. -₹${Math.round(p.weekendCutAmount)} 2x Cut)` : ''}`;

  const advRow = document.getElementById('psAdvanceRow');
  if (advRow) {
    if (p.advanceTaken > 0) {
      advRow.classList.remove('hidden');
      document.getElementById('psAdvanceDeduction').innerText = `-₹${p.advanceTaken.toLocaleString('en-IN')}`;
    } else {
      advRow.classList.add('hidden');
    }
  }

  document.getElementById('psNetPayable').innerText = `₹${p.netPayable.toLocaleString('en-IN')}`;

  document.getElementById('paySlipModal').classList.remove('hidden');
}

function closePaySlipModal() {
  document.getElementById('paySlipModal').classList.add('hidden');
}

function printPaySlip() {
  window.print();
}

// ==========================================
// 11. UTILITIES & TOAST ALERTS
// ==========================================

function getStaffName(staffId) {
  const s = staffList.find(x => x.id === staffId);
  return s ? s.name : 'Staff';
}

function formatDateKey(dateObj) {
  const y = dateObj.getFullYear();
  const m = String(dateObj.getMonth() + 1).padStart(2, '0');
  const d = String(dateObj.getDate()).padStart(2, '0');
  return `${y}-${m}-${d}`;
}

function formatMonthKey(dateObj) {
  const y = dateObj.getFullYear();
  const m = String(dateObj.getMonth() + 1).padStart(2, '0');
  return `${y}-${m}`;
}

function showToast(message) {
  const container = document.getElementById('toastContainer');
  if (!container) return;

  const toast = document.createElement('div');
  toast.className = 'bg-[#141420] text-white border border-[#ff2a85]/50 px-4 py-2.5 rounded-2xl shadow-2xl text-xs flex items-center gap-2 transform transition-all duration-300 pointer-events-auto';
  toast.innerHTML = `
    <i class="fa-solid fa-circle-check text-[#ff2a85]"></i>
    <span>${message}</span>
  `;

  container.appendChild(toast);

  setTimeout(() => {
    toast.style.opacity = '0';
    toast.style.transform = 'translateY(-10px)';
    setTimeout(() => toast.remove(), 300);
  }, 2800);
}

function saveAttendanceToast() {
  saveAttendanceData();
  showToast('Today\'s attendance and sales saved successfully!');
}

function startLiveClock() {
  function tick() {
    const now = new Date();
    const timeEl = document.getElementById('liveTime');
    const dateEl = document.getElementById('liveDate');
    if (timeEl) timeEl.innerText = now.toLocaleTimeString('en-US', { hour: 'numeric', minute: '2-digit', hour12: true });
    if (dateEl) dateEl.innerText = now.toLocaleDateString('en-US', { weekday: 'short', month: 'short', day: 'numeric' });

    // Kiosk Front Desk Digital Clock & Live Date
    const kioskTimeEl = document.getElementById('kioskDigitalClock');
    const kioskDateEl = document.getElementById('kioskLiveDate');
    if (kioskTimeEl) {
      kioskTimeEl.innerText = now.toLocaleTimeString('en-US', { hour: '2-digit', minute: '2-digit', second: '2-digit', hour12: true });
    }
    if (kioskDateEl) {
      kioskDateEl.innerText = now.toLocaleDateString('en-US', { weekday: 'short', year: 'numeric', month: 'short', day: 'numeric' });
    }
  }
  tick();
  setInterval(tick, 1000);
}

// ==========================================
// 12. BOOTSTRAP & GLOBAL EVENT LISTENERS
// ==========================================

window.addEventListener('DOMContentLoaded', () => {
  initStorage();
  initAuth();
  initFirebaseSync();

  const dateInput = document.getElementById('selectedDateInput');
  if (dateInput) dateInput.value = selectedDateStr;

  const monthInput = document.getElementById('selectedMonthInput');
  if (monthInput) monthInput.value = selectedMonthStr;

  const targetDateInput = document.getElementById('rosterTargetDate');
  if (targetDateInput) targetDateInput.value = selectedDateStr;

  window.addEventListener('hashchange', updateViewFromHash);

  // Global Clipboard Paste Listener (Ctrl + V for images - supports 1, 2, 3+ photos)
  window.addEventListener('paste', (e) => {
    const items = (e.clipboardData || window.clipboardData)?.items;
    if (!items) return;
    for (let i = 0; i < items.length; i++) {
      if (items[i].type && items[i].type.indexOf('image') !== -1) {
        const blob = items[i].getAsFile();
        if (blob) {
          if (window.location.hash !== '#roster') {
            navigateTo('roster');
          }
          addRosterImageFile(blob);
        }
      }
    }
  });

  // Drag and Drop support on #dropZone (supports multiple files dropped at once)
  const dropZone = document.getElementById('dropZone');
  if (dropZone) {
    dropZone.addEventListener('dragover', (e) => {
      e.preventDefault();
      dropZone.classList.add('border-[#ff2a85]', 'bg-[#150b1a]');
    });
    dropZone.addEventListener('dragleave', (e) => {
      e.preventDefault();
      dropZone.classList.remove('border-[#ff2a85]', 'bg-[#150b1a]');
    });
    dropZone.addEventListener('drop', (e) => {
      e.preventDefault();
      dropZone.classList.remove('border-[#ff2a85]', 'bg-[#150b1a]');
      if (e.dataTransfer && e.dataTransfer.files) {
        for (let i = 0; i < e.dataTransfer.files.length; i++) {
          addRosterImageFile(e.dataTransfer.files[i]);
        }
      }
    });
  }

  startLiveClock();
  updateViewFromHash();
});

// ==========================================
// 13. PWA & STANDALONE APP INSTALLATION
// ==========================================

let deferredInstallPrompt = null;
window.deferredInstallPrompt = null;

// Check if running in standalone mode (already installed on device home screen)
function checkIsStandalone() {
  return window.matchMedia('(display-mode: standalone)').matches || 
         window.navigator.standalone === true || 
         document.referrer.includes('android-app://');
}

function markAppAsInstalled() {
  const installBtn = document.getElementById('installPwaBtn');
  if (installBtn) {
    installBtn.innerHTML = '<i class="fa-solid fa-circle-check text-emerald-400 text-xs"></i> <span>Installed</span>';
    installBtn.title = 'âœ“ Green Trends App is installed on your Home Screen';
    installBtn.classList.remove('from-[#ff2a85]/20', 'to-purple-500/20', 'border-[#ff2a85]/40', 'text-[#ff7eb3]');
    installBtn.classList.add('bg-emerald-500/15', 'border-emerald-500/35', 'text-emerald-400');
  }
}

window.addEventListener('beforeinstallprompt', (e) => {
  // Prevent default mini-infobar on mobile Chrome
  e.preventDefault();
  // Stash the event so it can be triggered directly on click
  deferredInstallPrompt = e;
  window.deferredInstallPrompt = e;
  console.log('PWA beforeinstallprompt captured!');
  const installBtn = document.getElementById('installPwaBtn');
  if (installBtn) {
    installBtn.classList.remove('hidden');
  }
});

window.addEventListener('appinstalled', () => {
  deferredInstallPrompt = null;
  window.deferredInstallPrompt = null;
  showToast('ðŸŽ‰ Green Trends App successfully installed on your Home Screen!');
  markAppAsInstalled();
});

// Auto-check on startup if already running as installed standalone app
window.addEventListener('DOMContentLoaded', () => {
  if (checkIsStandalone()) {
    setTimeout(markAppAsInstalled, 300);
  }
});

async function promptPwaInstall() {
  if (checkIsStandalone()) {
    showToast('âœ“ Green Trends is already installed and running from your Home Screen!');
    return;
  }

  const promptEvt = deferredInstallPrompt || window.deferredInstallPrompt;
  // If Chrome/Edge beforeinstallprompt event is ready, trigger native installation directly!
  if (promptEvt && typeof promptEvt.prompt === 'function') {
    try {
      promptEvt.prompt();
      const choiceResult = await promptEvt.userChoice;
      if (choiceResult && choiceResult.outcome === 'accepted') {
        showToast('ðŸŽ‰ Green Trends App added to your Home Screen!');
        deferredInstallPrompt = null;
        window.deferredInstallPrompt = null;
        markAppAsInstalled();
      } else {
        showToast('Install cancelled. Tap Install anytime!');
      }
      return;
    } catch (err) {
      console.error('Install prompt error:', err);
    }
  }

  // If deferredInstallPrompt is not ready or user is on iOS:
  openPwaInstallHelpModal();
}

function openPwaInstallHelpModal() {
  const modal = document.getElementById('pwaModal');
  if (!modal) return;
  modal.classList.remove('hidden');
  modal.style.display = 'flex';

  const isIOS = /iphone|ipad|ipod/i.test(navigator.userAgent);
  const isAndroid = /android/i.test(navigator.userAgent);

  const bIos = document.getElementById('badgeIos');
  const bAndroid = document.getElementById('badgeAndroid');
  const bDesktop = document.getElementById('badgeDesktop');
  const stepIos = document.getElementById('pwaStepIos');
  const stepAndroid = document.getElementById('pwaStepAndroid');
  const stepDesktop = document.getElementById('pwaStepDesktop');
  const directBtnText = document.getElementById('pwaDirectInstallText');

  if (stepIos) stepIos.classList.remove('border-[#ff2a85]', 'bg-[#ff2a85]/10');
  if (stepAndroid) stepAndroid.classList.remove('border-emerald-500', 'bg-emerald-500/10');
  if (stepDesktop) stepDesktop.classList.remove('border-indigo-500', 'bg-indigo-500/10');

  const hasPrompt = !!(deferredInstallPrompt || window.deferredInstallPrompt);

  if (isIOS) {
    if (bIos) bIos.classList.remove('hidden');
    if (stepIos) stepIos.classList.add('border-[#ff2a85]', 'bg-[#ff2a85]/10');
    if (directBtnText) directBtnText.innerText = 'Got It (Share âž” Add)';
  } else if (isAndroid) {
    if (bAndroid) bAndroid.classList.remove('hidden');
    if (stepAndroid) stepAndroid.classList.add('border-emerald-500', 'bg-emerald-500/10');
    if (directBtnText) directBtnText.innerText = hasPrompt ? 'Install Now' : 'Got It (Menu âž” Install)';
  } else {
    if (bDesktop) bDesktop.classList.remove('hidden');
    if (stepDesktop) stepDesktop.classList.add('border-indigo-500', 'bg-indigo-500/10');
    if (directBtnText) directBtnText.innerText = hasPrompt ? 'Install Now' : 'Got It';
  }
}

function closePwaInstallModal() {
  const modal = document.getElementById('pwaModal');
  if (modal) {
    modal.classList.add('hidden');
    modal.style.display = 'none';
  }
}

function triggerNativeInstall() {
  closePwaInstallModal();
  const promptEvt = deferredInstallPrompt || window.deferredInstallPrompt;
  if (promptEvt && typeof promptEvt.prompt === 'function') {
    promptEvt.prompt();
    if (promptEvt.userChoice) {
      promptEvt.userChoice.then((choiceResult) => {
        if (choiceResult && choiceResult.outcome === 'accepted') {
          showToast('ðŸŽ‰ Green Trends App added to your Home Screen!');
          markAppAsInstalled();
        }
        deferredInstallPrompt = null;
        window.deferredInstallPrompt = null;
      });
    }
  } else {
    const isIOS = /iphone|ipad|ipod/i.test(navigator.userAgent);
    if (isIOS) {
      showToast('Tap Share [âŽ‹] below in Safari, then select "Add to Home Screen" âž•');
    } else {
      showToast('Tap browser menu (â‹®) âž” "Install app" or "Add to Home screen" ðŸ“²');
    }
  }
}

// Register PWA Service Worker
if ('serviceWorker' in navigator) {
  window.addEventListener('load', () => {
    navigator.serviceWorker.register('./sw.js').then((reg) => {
      console.log('Green Trends PWA Service Worker registered:', reg.scope);
    }).catch((err) => {
      console.log('PWA Service Worker registration note:', err);
    });
  });
}

// ==========================================
// 8. SALON PETTY CASH & DAILY EXPENSE TRACKER
// ==========================================

function renderPettyCashLedger() {
  const kpisContainer = document.getElementById('expenseKpis');
  const tbody = document.getElementById('expenseTableBody');
  const tfoot = document.getElementById('expenseTableFoot');
  if (!tbody) return;

  const targetMonth = selectedExpenseFilterMonth || selectedMonthStr;
  const filtered = salonExpenses.filter(e => !targetMonth || e.date.startsWith(targetMonth));

  // Sort latest first
  filtered.sort((a, b) => new Date(b.date) - new Date(a.date) || b.id.localeCompare(a.id));

  let totalAmount = 0;
  let salonAccountTotal = 0;
  let ownerAccountTotal = 0;
  const catTotals = {};

  filtered.forEach(e => {
    const amt = Number(e.amount) || 0;
    totalAmount += amt;
    if (e.paidBy === 'Owner Account' || e.paidBy === 'Owner Direct') {
      ownerAccountTotal += amt;
    } else {
      salonAccountTotal += amt;
    }

    catTotals[e.category] = (catTotals[e.category] || 0) + amt;
  });

  let topCat = 'None';
  let topCatAmt = 0;
  Object.entries(catTotals).forEach(([cat, sum]) => {
    if (sum > topCatAmt) {
      topCat = cat;
      topCatAmt = sum;
    }
  });

  // 1. Render Summary KPI Cards
  if (kpisContainer) {
    kpisContainer.innerHTML = `
      <div class="bg-[#10101c] p-4 rounded-2xl border border-amber-500/25 shadow-lg relative overflow-hidden">
        <div class="flex items-center justify-between text-xs text-gray-400 font-semibold">
          <span>Month Payouts</span>
          <i class="fa-solid fa-receipt text-amber-400"></i>
        </div>
        <div class="mt-2">
          <span class="text-xl font-black font-heading text-white">â‚¹${totalAmount.toLocaleString('en-IN')}</span>
          <span class="text-[10px] text-amber-400 block mt-0.5 font-mono">${filtered.length} entries for ${targetMonth}</span>
        </div>
      </div>

      <div class="bg-[#10101c] p-4 rounded-2xl border border-emerald-500/25 shadow-lg relative overflow-hidden">
        <div class="flex items-center justify-between text-xs text-gray-400 font-semibold">
          <span>Salon Account</span>
          <i class="fa-solid fa-store text-emerald-400"></i>
        </div>
        <div class="mt-2">
          <span class="text-xl font-black font-heading text-emerald-400">â‚¹${salonAccountTotal.toLocaleString('en-IN')}</span>
          <span class="text-[10px] text-gray-400 block mt-0.5 font-mono">Cash Drawer & Branch UPI</span>
        </div>
      </div>

      <div class="bg-[#10101c] p-4 rounded-2xl border border-amber-500/25 shadow-lg relative overflow-hidden">
        <div class="flex items-center justify-between text-xs text-gray-400 font-semibold">
          <span>Owner Account</span>
          <i class="fa-solid fa-crown text-amber-400"></i>
        </div>
        <div class="mt-2">
          <span class="text-xl font-black font-heading text-amber-300">â‚¹${ownerAccountTotal.toLocaleString('en-IN')}</span>
          <span class="text-[10px] text-gray-400 block mt-0.5 font-mono">Direct Owner Transfers</span>
        </div>
      </div>

      <div class="bg-[#10101c] p-4 rounded-2xl border border-sky-500/25 shadow-lg relative overflow-hidden">
        <div class="flex items-center justify-between text-xs text-gray-400 font-semibold">
          <span>Top Category</span>
          <i class="fa-solid fa-tag text-sky-400"></i>
        </div>
        <div class="mt-2">
          <span class="text-sm font-black font-heading text-sky-400 truncate block">${topCat}</span>
          <span class="text-[10px] text-gray-400 block mt-0.5 font-mono">â‚¹${topCatAmt.toLocaleString('en-IN')}</span>
        </div>
      </div>
    `;
  }

  // Helper Badge Renderers
  const getCatBadge = (cat) => {
    switch(cat) {
      case 'Towel Laundry': return '<span class="px-2.5 py-0.5 rounded-full bg-blue-500/15 text-blue-300 border border-blue-500/30 text-[10px] font-semibold flex items-center gap-1.5 w-fit"><i class="fa-solid fa-shirt"></i>Towel Laundry</span>';
      case 'Drinking Water': return '<span class="px-2.5 py-0.5 rounded-full bg-cyan-500/15 text-cyan-300 border border-cyan-500/30 text-[10px] font-semibold flex items-center gap-1.5 w-fit"><i class="fa-solid fa-bottle-water"></i>Drinking Water</span>';
      case 'Client Refreshments': return '<span class="px-2.5 py-0.5 rounded-full bg-amber-500/15 text-amber-300 border border-amber-500/30 text-[10px] font-semibold flex items-center gap-1.5 w-fit"><i class="fa-solid fa-mug-hot"></i>Refreshments</span>';
      case 'Cleaning & Housekeeping': return '<span class="px-2.5 py-0.5 rounded-full bg-emerald-500/15 text-emerald-300 border border-emerald-500/30 text-[10px] font-semibold flex items-center gap-1.5 w-fit"><i class="fa-solid fa-broom"></i>Cleaning</span>';
      case 'Salon Maintenance': return '<span class="px-2.5 py-0.5 rounded-full bg-purple-500/15 text-purple-300 border border-purple-500/30 text-[10px] font-semibold flex items-center gap-1.5 w-fit"><i class="fa-solid fa-wrench"></i>Maintenance</span>';
      default: return '<span class="px-2.5 py-0.5 rounded-full bg-gray-500/15 text-gray-300 border border-gray-500/30 text-[10px] font-semibold flex items-center gap-1.5 w-fit"><i class="fa-solid fa-box"></i>' + cat + '</span>';
    }
  };

  const getPaidByBadge = (pb) => {
    if (pb === 'Owner Account' || pb === 'Owner Direct') {
      return '<span class="px-2.5 py-0.5 rounded-full bg-amber-500/15 text-amber-300 border border-amber-500/30 font-semibold text-[10px] flex items-center gap-1 w-fit"><i class="fa-solid fa-crown text-amber-400"></i>Owner Account</span>';
    }
    return '<span class="px-2.5 py-0.5 rounded-full bg-emerald-500/15 text-emerald-400 border border-emerald-500/30 font-semibold text-[10px] flex items-center gap-1 w-fit"><i class="fa-solid fa-store text-emerald-400"></i>Salon Account</span>';
  };

  // 2. Render Table Rows
  if (filtered.length === 0) {
    tbody.innerHTML = `
      <tr>
        <td colspan="6" class="text-center py-10 text-gray-400">
          <i class="fa-solid fa-receipt text-3xl text-gray-600 mb-2 block"></i>
          <p class="font-bold text-sm">No petty cash expenses recorded for ${targetMonth}</p>
          <p class="text-xs text-gray-500 mt-1">Click "+ Add Daily Expense" above to record daily towel laundry, water cans, or cleaning supplies.</p>
        </td>
      </tr>
    `;
  } else {
    tbody.innerHTML = filtered.map(exp => `
      <tr class="hover:bg-[#141424] transition-colors">
        <td class="py-3 px-3 font-mono font-medium text-gray-300">${exp.date}</td>
        <td class="py-3 px-3">${getCatBadge(exp.category)}</td>
        <td class="py-3 px-3 text-white max-w-xs truncate" title="${exp.note || ''}">${exp.note || 'â€”'}</td>
        <td class="py-3 px-3">${getPaidByBadge(exp.paidBy)}</td>
        <td class="py-3 px-3 text-right font-mono font-bold text-amber-400 text-sm">â‚¹${Number(exp.amount || 0).toLocaleString('en-IN')}</td>
        <td class="py-3 px-3 text-center">
          <button type="button" onclick="deleteSalonExpense('${exp.id}')" class="w-7 h-7 rounded-lg bg-rose-500/10 hover:bg-rose-500 text-rose-400 hover:text-white transition-all flex items-center justify-center cursor-pointer mx-auto" title="Delete Expense">
            <i class="fa-solid fa-trash-can text-xs"></i>
          </button>
        </td>
      </tr>
    `).join('');
  }

  // 3. Render Totals in Table Footer
  if (tfoot) {
    tfoot.innerHTML = `
      <tr>
        <td colspan="4" class="py-3.5 px-3 uppercase text-[11px] tracking-wider text-gray-300">
          Total Operational Expenses for ${targetMonth} (${filtered.length} entries)
        </td>
        <td class="py-3.5 px-3 text-right text-base text-amber-400 font-mono">
          â‚¹${totalAmount.toLocaleString('en-IN')}
        </td>
        <td></td>
      </tr>
    `;
  }
}

function openAddExpenseModal() {
  const modal = document.getElementById('addExpenseModal');
  if (!modal) return;
  const dateInput = document.getElementById('expenseDateInput');
  const amountInput = document.getElementById('expenseAmountInput');
  const noteInput = document.getElementById('expenseNoteInput');

  if (dateInput) dateInput.value = selectedDateStr || new Date().toISOString().split('T')[0];
  if (amountInput) amountInput.value = '';
  if (noteInput) noteInput.value = '';

  modal.classList.remove('hidden');
  modal.style.display = 'flex';
  if (amountInput) setTimeout(() => amountInput.focus(), 120);
}

function closeAddExpenseModal() {
  const modal = document.getElementById('addExpenseModal');
  if (modal) {
    modal.classList.add('hidden');
    modal.style.display = 'none';
  }
}

function submitAddExpense(e) {
  if (e && e.preventDefault) e.preventDefault();

  const date = document.getElementById('expenseDateInput').value;
  const category = document.getElementById('expenseCategoryInput').value;
  const amount = parseFloat(document.getElementById('expenseAmountInput').value) || 0;
  const note = document.getElementById('expenseNoteInput').value.trim();
  const paidBy = document.getElementById('expensePaidByInput').value;

  if (!date) {
    alert("Please select a date for the expense.");
    return;
  }
  if (amount <= 0) {
    alert("Please enter a valid amount greater than â‚¹0.");
    return;
  }

  const finalPaidBy = paidBy === 'Owner Account' ? 'Owner Account' : 'Salon Account';

  const newExpense = {
    id: 'exp_' + Date.now() + '_' + Math.random().toString(36).substring(2, 6),
    date,
    category,
    amount,
    note: note || category,
    paidBy: finalPaidBy,
    createdAt: new Date().toISOString()
  };

  salonExpenses.unshift(newExpense);
  saveSalonExpenses();
  renderPettyCashLedger();
  closeAddExpenseModal();
  showToast(`âœ“ Added â‚¹${amount.toLocaleString('en-IN')} expense via ${finalPaidBy}`);
}

function deleteSalonExpense(id) {
  const exp = salonExpenses.find(e => e.id === id);
  if (!exp) return;
  if (!confirm(`Delete expense of â‚¹${Number(exp.amount).toLocaleString('en-IN')} for "${exp.category}"?`)) return;

  salonExpenses = salonExpenses.filter(e => e.id !== id);
  saveSalonExpenses();
  renderPettyCashLedger();
  showToast("Expense entry deleted");
}

function exportExpensesCSV() {
  const targetMonth = selectedExpenseFilterMonth || selectedMonthStr;
  const filtered = salonExpenses.filter(e => !targetMonth || e.date.startsWith(targetMonth));
  if (filtered.length === 0) {
    showToast("No expenses to export for " + targetMonth);
    return;
  }

  let csv = "Date,Category,Description / Note,Paid Via,Amount (INR)\n";
  filtered.forEach(e => {
    const cleanNote = (e.note || '').replace(/"/g, '""');
    csv += `"${e.date}","${e.category}","${cleanNote}","${e.paidBy}",${e.amount}\n`;
  });

  const blob = new Blob([csv], { type: 'text/csv;charset=utf-8;' });
  const url = URL.createObjectURL(blob);
  const link = document.createElement("a");
  link.setAttribute("href", url);
  link.setAttribute("download", `GreenTrends_Kothapet_Expenses_${targetMonth}.csv`);
  document.body.appendChild(link);
  link.click();
  document.body.removeChild(link);
  showToast(`Exported ${filtered.length} expense records to CSV`);
}

// ==========================================
// 9. FRONT DESK KIOSK MODE (1-TAP CHECK-IN / CHECK-OUT)
// ==========================================

function renderKioskView() {
  const grid = document.getElementById('kioskStaffGrid');
  const ticker = document.getElementById('kioskStatsTicker');
  if (!grid) return;

  const dateKey = selectedDateStr || new Date().toISOString().split('T')[0];
  const dayRecords = attendanceData[dateKey] || {};

  let presentCount = 0;
  let offCount = 0;
  let leaveCount = 0;
  let pendingCount = 0;

  staffList.forEach(s => {
    const rec = dayRecords[s.id];
    if (rec && rec.status === 'Present') presentCount++;
    else if (rec && rec.status === 'Weekly Off') offCount++;
    else if (rec && (rec.status === 'Leave' || rec.status === 'Absent')) leaveCount++;
    else pendingCount++;
  });

  if (ticker) {
    ticker.innerHTML = `
      <span class="px-2.5 py-1 rounded-xl bg-emerald-500/15 text-emerald-400 text-xs font-bold border border-emerald-500/30 flex items-center gap-1.5">
        <span class="w-2 h-2 rounded-full bg-emerald-400 animate-pulse"></span>
        <strong>${presentCount}</strong> On Duty
      </span>
      <span class="px-2.5 py-1 rounded-xl bg-indigo-500/15 text-indigo-300 text-xs font-bold border border-indigo-500/30 flex items-center gap-1.5">
        <i class="fa-solid fa-mug-hot text-xs"></i>
        <strong>${offCount}</strong> Weekly Off
      </span>
      <span class="px-2.5 py-1 rounded-xl bg-rose-500/15 text-rose-400 text-xs font-bold border border-rose-500/30 flex items-center gap-1.5">
        <i class="fa-solid fa-user-xmark text-xs"></i>
        <strong>${leaveCount}</strong> Leave
      </span>
      <span class="px-2.5 py-1 rounded-xl bg-amber-500/15 text-amber-300 text-xs font-bold border border-amber-500/30 flex items-center gap-1.5">
        <i class="fa-solid fa-user-clock text-xs"></i>
        <strong>${pendingCount}</strong> Pending
      </span>
    `;
  }

  grid.innerHTML = staffList.map(staff => {
    const rec = dayRecords[staff.id] || { status: 'Present', inH: 10, inM: 0, inAmpm: 'AM', outH: 7, outM: 0, outAmpm: 'PM' };
    const isPresent = rec.status === 'Present';
    const isOff = rec.status === 'Weekly Off';
    const isLeave = rec.status === 'Leave' || rec.status === 'Absent';

    const inTimeFormatted = `${rec.inH || 10}:${String(rec.inM || 0).padStart(2, '0')} ${rec.inAmpm || 'AM'}`;
    const outTimeFormatted = `${rec.outH || 7}:${String(rec.outM || 0).padStart(2, '0')} ${rec.outAmpm || 'PM'}`;

    const shiftCalc = calculateShiftHoursParsed(
      rec.inH || 10,
      rec.inM || 0,
      rec.inAmpm || 'AM',
      rec.outH || 7,
      rec.outM || 0,
      rec.outAmpm || 'PM',
      staff.isHousekeeping
    );

    let statusPill = '';
    let cardBorder = 'border-[#222236]';
    let glow = '';

    if (isPresent) {
      if ((rec.otHours || 0) > 0) {
        statusPill = `<span class="px-2.5 py-1 rounded-full bg-amber-500/20 text-amber-300 border border-amber-500/40 text-[10px] font-bold flex items-center gap-1">
          <i class="fa-solid fa-fire text-amber-400"></i> ${rec.otHours}h OT (+â‚¹${rec.otPay || 0})
        </span>`;
        cardBorder = 'border-amber-500/40';
        glow = 'shadow-amber-500/10';
      } else {
        statusPill = `<span class="px-2.5 py-1 rounded-full bg-emerald-500/20 text-emerald-400 border border-emerald-500/40 text-[10px] font-bold flex items-center gap-1">
          <span class="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse"></span> ON DUTY
        </span>`;
        cardBorder = 'border-emerald-500/35';
        glow = 'shadow-emerald-500/10';
      }
    } else if (isOff) {
      statusPill = `<span class="px-2.5 py-1 rounded-full bg-indigo-500/20 text-indigo-300 border border-indigo-500/40 text-[10px] font-bold flex items-center gap-1">
        <i class="fa-solid fa-mug-hot text-xs"></i> WEEKLY OFF
      </span>`;
      cardBorder = 'border-indigo-500/30';
    } else {
      statusPill = `<span class="px-2.5 py-1 rounded-full bg-rose-500/20 text-rose-300 border border-rose-500/40 text-[10px] font-bold flex items-center gap-1">
        <i class="fa-solid fa-xmark text-xs"></i> LEAVE
      </span>`;
      cardBorder = 'border-rose-500/30';
    }

    return `
      <div class="kiosk-card bg-[#0d0d18] ${cardBorder} p-5 rounded-3xl shadow-xl ${glow} flex flex-col justify-between space-y-4 hover:border-[#ff2a85]/50 transition-all">
        <!-- Card Header: Avatar & Info -->
        <div class="flex items-start justify-between gap-3">
          <div class="flex items-center gap-3">
            <div class="w-12 h-12 rounded-2xl bg-gradient-to-tr from-[#1f1025] to-[#2d1234] border border-[#ff2a85]/40 flex items-center justify-center font-syne font-black text-lg text-[#ff7eb3] shadow-md shadow-[#ff2a85]/20 shrink-0">
              ${staff.name.substring(0, 2).toUpperCase()}
            </div>
            <div>
              <h3 class="font-syne font-black text-base text-white leading-tight">${staff.name}</h3>
              <div class="flex items-center gap-1.5 mt-0.5">
                <span class="text-xs text-gray-400 font-medium">${staff.role}</span>
                ${staff.isManager ? '<span class="text-[9px] px-1.5 py-0.5 rounded bg-[#ff2a85]/20 text-[#ff7eb3] font-bold border border-[#ff2a85]/30">MANAGER</span>' : ''}
              </div>
            </div>
          </div>
          <div>${statusPill}</div>
        </div>

        <!-- Timesheet Badges -->
        <div class="bg-[#121222] p-3 rounded-2xl border border-[#202036] space-y-2">
          <div class="flex items-center justify-between text-xs font-mono">
            <span class="text-gray-400 flex items-center gap-1.5">
              <i class="fa-solid fa-arrow-right-to-bracket text-emerald-400"></i> Check In:
            </span>
            <span class="font-bold text-white">${isPresent ? inTimeFormatted : 'â€”'}</span>
          </div>
          <div class="flex items-center justify-between text-xs font-mono">
            <span class="text-gray-400 flex items-center gap-1.5">
              <i class="fa-solid fa-arrow-right-from-bracket text-rose-400"></i> Check Out:
            </span>
            <span class="font-bold text-white">${isPresent ? outTimeFormatted : 'â€”'}</span>
          </div>
          <div class="pt-1 border-t border-[#1c1c30] flex items-center justify-between text-[11px]">
            <span class="text-gray-400 font-medium">Shift Duration:</span>
            <span class="font-bold ${isPresent ? 'text-purple-300 font-mono' : 'text-gray-500'}">
              ${isPresent ? shiftCalc.formattedDuration : (isLeave ? 'Full Day Leave' : (isOff ? 'Scheduled Off' : 'Not clocked in'))}
            </span>
          </div>
        </div>

        <!-- 1-Tap Action Touch Targets -->
        <div class="space-y-2 pt-1">
          <div class="grid grid-cols-2 gap-2">
            <button type="button" onclick="kioskClockIn('${staff.id}')" 
              class="w-full py-3 rounded-2xl text-xs font-extrabold bg-gradient-to-r from-emerald-600 to-teal-500 hover:brightness-110 active:scale-95 text-white shadow-lg shadow-emerald-500/25 flex items-center justify-center gap-1.5 transition-all cursor-pointer"
              title="1-Tap Check-In with current time">
              <i class="fa-solid fa-stopwatch text-sm"></i>
              <span>1-Tap In</span>
            </button>

            <button type="button" onclick="kioskClockOut('${staff.id}')" 
              class="w-full py-3 rounded-2xl text-xs font-extrabold bg-gradient-to-r from-rose-600 to-pink-600 hover:brightness-110 active:scale-95 text-white shadow-lg shadow-rose-500/25 flex items-center justify-center gap-1.5 transition-all cursor-pointer"
              title="1-Tap Check-Out with current time">
              <i class="fa-solid fa-flag-checkered text-sm"></i>
              <span>1-Tap Out</span>
            </button>
          </div>

          <div class="grid grid-cols-2 gap-2">
            <button type="button" onclick="kioskMarkOff('${staff.id}')" 
              class="w-full py-2 rounded-xl text-[11px] font-bold bg-[#141424] hover:bg-[#1f1f34] text-indigo-300 border border-indigo-500/20 hover:border-indigo-500/40 flex items-center justify-center gap-1.5 transition-all cursor-pointer"
              title="Mark weekly scheduled off">
              <i class="fa-solid fa-mug-hot text-[11px]"></i>
              <span>Weekly Off</span>
            </button>

            <button type="button" onclick="kioskMarkLeave('${staff.id}')" 
              class="w-full py-2 rounded-xl text-[11px] font-bold bg-[#1e1017] hover:bg-[#2c1420] text-rose-300 border border-rose-500/20 hover:border-rose-500/40 flex items-center justify-center gap-1.5 transition-all cursor-pointer"
              title="Mark unpaid leave (salary deduction)">
              <i class="fa-solid fa-user-xmark text-[11px]"></i>
              <span>Mark Leave</span>
            </button>
          </div>
        </div>
      </div>
    `;
  }).join('');
}

function kioskClockIn(staffId) {
  const dateKey = selectedDateStr || new Date().toISOString().split('T')[0];
  const now = new Date();
  let hours24 = now.getHours();
  let minutes = now.getMinutes();
  let ampm = hours24 >= 12 ? 'PM' : 'AM';
  let hours12 = hours24 % 12;
  if (hours12 === 0) hours12 = 12;

  if (!attendanceData[dateKey]) attendanceData[dateKey] = {};
  if (!attendanceData[dateKey][staffId]) {
    attendanceData[dateKey][staffId] = {
      status: 'Present',
      inH: hours12,
      inM: minutes,
      inAmpm: ampm,
      outH: 7,
      outM: 0,
      outAmpm: 'PM',
      servicesDone: 0,
      productsSold: 0
    };
  } else {
    const rec = attendanceData[dateKey][staffId];
    rec.status = 'Present';
    rec.inH = hours12;
    rec.inM = minutes;
    rec.inAmpm = ampm;
    if (!rec.outH) {
      rec.outH = 7;
      rec.outM = 0;
      rec.outAmpm = 'PM';
    }
  }

  const staff = staffList.find(s => s.id === staffId);
  const rec = attendanceData[dateKey][staffId];
  if (staff) {
    const shiftCalc = calculateShiftHoursParsed(rec.inH, rec.inM, rec.inAmpm, rec.outH, rec.outM, rec.outAmpm || 'PM', staff.isHousekeeping);
    rec.workedMinutes = shiftCalc.workedMinutes;
    rec.otHours = shiftCalc.otHours;
    rec.shortfallHours = shiftCalc.shortfallHours;
    rec.otPay = shiftCalc.otPay;
  }

  saveAttendanceData();
  renderKioskView();

  const formattedTime = `${hours12}:${String(minutes).padStart(2, '0')} ${ampm}`;
  showKioskCelebration(
    staff ? staff.name : 'Stylist',
    'CHECK-IN CONFIRMED',
    `Clocked in at ${formattedTime}`,
    'Have a fabulous, productive shift at Green Trends Kothapet! âœ¨',
    'check'
  );
}

function kioskClockOut(staffId) {
  const dateKey = selectedDateStr || new Date().toISOString().split('T')[0];
  const now = new Date();
  let hours24 = now.getHours();
  let minutes = now.getMinutes();
  let ampm = hours24 >= 12 ? 'PM' : 'AM';
  let hours12 = hours24 % 12;
  if (hours12 === 0) hours12 = 12;

  if (!attendanceData[dateKey]) attendanceData[dateKey] = {};
  if (!attendanceData[dateKey][staffId]) {
    attendanceData[dateKey][staffId] = {
      status: 'Present',
      inH: 10,
      inM: 0,
      inAmpm: 'AM',
      outH: hours12,
      outM: minutes,
      outAmpm: 'PM',
      servicesDone: 0,
      productsSold: 0
    };
  } else {
    const rec = attendanceData[dateKey][staffId];
    rec.status = 'Present';
    rec.outH = hours12;
    rec.outM = minutes;
    rec.outAmpm = 'PM';
  }

  const staff = staffList.find(s => s.id === staffId);
  const rec = attendanceData[dateKey][staffId];
  let summaryMsg = 'Shift completed successfully!';
  if (staff) {
    const shiftCalc = calculateShiftHoursParsed(rec.inH, rec.inM, rec.inAmpm, rec.outH, rec.outM, rec.outAmpm || 'PM', staff.isHousekeeping);
    rec.workedMinutes = shiftCalc.workedMinutes;
    rec.otHours = shiftCalc.otHours;
    rec.shortfallHours = shiftCalc.shortfallHours;
    rec.otPay = shiftCalc.otPay;
    if (rec.otHours > 0) {
      summaryMsg = `ðŸ”¥ +${rec.otHours}h Overtime earned (+â‚¹${rec.otPay})! Outstanding work!`;
    } else if (rec.shortfallHours > 0) {
      summaryMsg = `Shift logged: ${shiftCalc.formattedDuration} (${rec.shortfallHours}h shortfall from 9h standard).`;
    } else {
      summaryMsg = `Standard 9-hour shift completed (${shiftCalc.formattedDuration})! Great work! ðŸ‘`;
    }
  }

  saveAttendanceData();
  renderKioskView();

  const formattedTime = `${hours12}:${String(minutes).padStart(2, '0')} ${ampm}`;
  showKioskCelebration(
    staff ? staff.name : 'Stylist',
    'CHECK-OUT CONFIRMED',
    `Clocked out at ${formattedTime}`,
    summaryMsg,
    'flag-checkered'
  );
}

function kioskMarkOff(staffId) {
  const dateKey = selectedDateStr || new Date().toISOString().split('T')[0];
  if (!attendanceData[dateKey]) attendanceData[dateKey] = {};
  if (!attendanceData[dateKey][staffId]) attendanceData[dateKey][staffId] = {};
  attendanceData[dateKey][staffId].status = 'Weekly Off';
  saveAttendanceData();
  renderKioskView();
  const staff = staffList.find(s => s.id === staffId);
  showToast(`${staff ? staff.name : 'Stylist'} marked on Weekly Off`);
}

function kioskMarkLeave(staffId) {
  const dateKey = selectedDateStr || new Date().toISOString().split('T')[0];
  const staff = staffList.find(s => s.id === staffId);
  const staffName = staff ? staff.name : 'Stylist';

  if (!attendanceData[dateKey]) attendanceData[dateKey] = {};
  if (!attendanceData[dateKey][staffId]) {
    attendanceData[dateKey][staffId] = {
      status: 'Leave',
      inH: 10,
      inM: 0,
      inAmpm: 'AM',
      outH: 7,
      outM: 0,
      outAmpm: 'PM',
      servicesDone: 0,
      productsSold: 0
    };
  } else {
    attendanceData[dateKey][staffId].status = 'Leave';
  }

  saveAttendanceData();
  renderKioskView();

  showKioskCelebration(
    staffName,
    'LEAVE RECORDED',
    `Marked Leave for ${dateKey}`,
    'Full day unpaid leave logged on the timesheet.',
    'user-xmark'
  );
}

function showKioskCelebration(name, badge, subtitle, message, iconType = 'check') {
  const modal = document.getElementById('kioskCelebrationModal');
  if (!modal) return;

  const titleEl = document.getElementById('kioskModalTitle');
  const badgeEl = document.getElementById('kioskModalBadge');
  const subEl = document.getElementById('kioskModalSubtitle');
  const msgEl = document.getElementById('kioskModalMessage');
  const iconEl = document.getElementById('kioskModalIcon');

  if (titleEl) titleEl.innerText = name;
  if (badgeEl) {
    badgeEl.innerText = badge;
    if (iconType === 'user-xmark') {
      badgeEl.className = 'px-2.5 py-0.5 rounded-full text-[10px] font-bold font-mono uppercase bg-rose-500/20 text-rose-400 border border-rose-500/30';
    } else {
      badgeEl.className = 'px-2.5 py-0.5 rounded-full text-[10px] font-bold font-mono uppercase bg-emerald-500/20 text-emerald-400 border border-emerald-500/30';
    }
  }
  if (subEl) subEl.innerText = subtitle;
  if (msgEl) msgEl.innerText = message;
  if (iconEl) {
    if (iconType === 'flag-checkered') {
      iconEl.className = 'fa-solid fa-flag-checkered text-2xl text-emerald-400';
    } else if (iconType === 'user-xmark') {
      iconEl.className = 'fa-solid fa-user-xmark text-2xl text-rose-400';
    } else {
      iconEl.className = 'fa-solid fa-check text-2xl text-emerald-400';
    }
  }

  modal.classList.remove('hidden');
  modal.style.display = 'flex';

  if (window._kioskCelebrationTimeout) clearTimeout(window._kioskCelebrationTimeout);
  window._kioskCelebrationTimeout = setTimeout(() => {
    closeKioskCelebration();
  }, 3200);
}

function closeKioskCelebration() {
  const modal = document.getElementById('kioskCelebrationModal');
  if (modal) {
    modal.classList.add('hidden');
    modal.style.display = 'none';
  }
}

function toggleKioskFullscreen() {
  if (!document.fullscreenElement) {
    if (document.documentElement.requestFullscreen) {
      document.documentElement.requestFullscreen().catch(err => {
        console.log('Fullscreen error:', err.message);
      });
    }
    const btn = document.getElementById('kioskFullscreenBtn');
    if (btn) btn.innerHTML = '<i class="fa-solid fa-compress text-purple-400"></i><span>Exit Fullscreen</span>';
  } else {
    if (document.exitFullscreen) {
      document.exitFullscreen();
    }
    const btn = document.getElementById('kioskFullscreenBtn');
    if (btn) btn.innerHTML = '<i class="fa-solid fa-expand text-purple-400"></i><span>Fullscreen Kiosk</span>';
  }
}

// Global window attachments
window.updateStaffAdvance = updateStaffAdvance;
window.saveAdvanceData = saveAdvanceData;
window.promptPwaInstall = promptPwaInstall;
window.openPwaInstallHelpModal = openPwaInstallHelpModal;
window.closePwaInstallModal = closePwaInstallModal;
window.triggerNativeInstall = triggerNativeInstall;
window.markAppAsInstalled = markAppAsInstalled;
window.checkIsStandalone = checkIsStandalone;

// Petty cash functions
window.openAddExpenseModal = openAddExpenseModal;
window.closeAddExpenseModal = closeAddExpenseModal;
window.submitAddExpense = submitAddExpense;
window.deleteSalonExpense = deleteSalonExpense;
window.exportExpensesCSV = exportExpensesCSV;
window.renderPettyCashLedger = renderPettyCashLedger;

// Kiosk mode functions
window.renderKioskView = renderKioskView;
window.kioskClockIn = kioskClockIn;
window.kioskClockOut = kioskClockOut;
window.kioskMarkOff = kioskMarkOff;
window.kioskMarkLeave = kioskMarkLeave;
window.showKioskCelebration = showKioskCelebration;
window.closeKioskCelebration = closeKioskCelebration;
window.toggleKioskFullscreen = toggleKioskFullscreen;

// Roster scanner & parser functions
window.parseRosterText = parseRosterText;
window.renderParsedRosterList = renderParsedRosterList;
window.updateDetectedStaffStatus = updateDetectedStaffStatus;
window.quickAddStaffWithShift = quickAddStaffWithShift;
window.openQuickAddStaffToRoster = openQuickAddStaffToRoster;
window.closeQuickAddStaffModal = closeQuickAddStaffModal;
window.applyRosterToAttendance = applyRosterToAttendance;
window.loadSampleUploadedRoster = loadSampleUploadedRoster;



